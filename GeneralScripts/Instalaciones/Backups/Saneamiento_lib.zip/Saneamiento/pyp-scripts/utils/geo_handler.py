import math
import os
import importlib.util
import NemAll_Python_Geometry as AllplanGeo
import NemAll_Python_BasisElements as AllplanBasisElements
import NemAll_Python_BaseElements as AllplanBaseElements
import NemAll_Python_Utility as PythonUtility

from typing import Any, List, Optional, Type

from .trim_config import (
    REDUCT_110_40_TRIM_IN_MM,
    REDUCT_110_40_TRIM_OUT_MM,
    TAPRED_40_25_TRIM_IN_MM,
    TAPRED_40_25_TRIM_OUT_MM,
)

# ---------------------------------------------------
# SANEAMIENTO 90° = 2x45° (25 mm) — ajustes globales
# ---------------------------------------------------
# Valores portados de Saneamiento_old para 25mm 2x45:
# ELBOW45_25MM_CODO1_PIVOT_(X,Y,Z) y ELBOW45_25MM_CODO2_PIVOT_(X,Y,Z)
DOUBLE45_AUTO_SEP_MM = 0.0
DOUBLE45_CODO1_OFFSET_X_MM = -33.0
DOUBLE45_CODO1_OFFSET_Y_MM = 20.0
DOUBLE45_CODO1_OFFSET_Z_MM = 0.0
DOUBLE45_CODO2_OFFSET_X_MM = 30.0
DOUBLE45_CODO2_OFFSET_Y_MM = 20.0
DOUBLE45_CODO2_OFFSET_Z_MM = 0.0
# Ajuste global para codo 90° de 25 mm (outer + inner).
CODO90_25_OFFSET_X_MM = -37.0
CODO90_25_OFFSET_Y_MM = 15.0
CODO90_25_OFFSET_Z_MM = 17.0
# Ajuste global para codo 45° individual de 25 mm (outer + inner).
CODO45_25_OFFSET_X_MM = -4.0
CODO45_25_OFFSET_Y_MM = 8.0
CODO45_25_OFFSET_Z_MM = 0.0
# ---------------------------------------------------
# SANEAMIENTO 90° = 2x45° (40 mm) — ajustes globales
# ---------------------------------------------------
DOUBLE45_40_AUTO_SEP_MM = 0.0
DOUBLE45_40_CODO1_OFFSET_X_MM = -45.0
DOUBLE45_40_CODO1_OFFSET_Y_MM = 30.0
DOUBLE45_40_CODO1_OFFSET_Z_MM = 0.0
DOUBLE45_40_CODO2_OFFSET_X_MM = 55.0
DOUBLE45_40_CODO2_OFFSET_Y_MM = 30.0
DOUBLE45_40_CODO2_OFFSET_Z_MM = 0.0
# Ajuste global para codo 90° de 40 mm (outer + inner).
CODO90_40_OFFSET_X_MM = -12.0
CODO90_40_OFFSET_Y_MM = -15.0
CODO90_40_OFFSET_Z_MM = 17.0
# Ajuste global para codo 45° individual de 40 mm (outer + inner).
CODO45_40_OFFSET_X_MM = 5.0
CODO45_40_OFFSET_Y_MM = 10.0
CODO45_40_OFFSET_Z_MM = 0.0
# Bifurcación Y45 Ø40 (TE 40-40-40, colocación BIF40 / Saneamiento_old): traslación extra en mm (ejes mundo).
BIF_Y40_PLACEMENT_OFFSET_X_MM = 0.0
BIF_Y40_PLACEMENT_OFFSET_Y_MM = 0.0
BIF_Y40_PLACEMENT_OFFSET_Z_MM = -40.0
# Recortes de tubo en nudo TE Y45 Ø40 (40-40-40), en mm (portado de Saneamiento_old BIF40_*).
# Se aplican a los tres brazos: troncal “entrada”, rama, troncal “salida” (ver vertex_utils.register_te_cuts_into).
BIF_Y40_TE_TRIM_MAIN_IN_MM = 30.0
BIF_Y40_TE_TRIM_MAIN_OUT_MM = 65.0
BIF_Y40_TE_TRIM_BRANCH_MM = 70.6
# Bifurcación Y Ø110 pluvial (TE 110-110-110, Derivacion110m_f_script + colocación D110-D110).
BIF_Y110_PLUVIAL_PLACEMENT_OFFSET_X_MM = 0.0
BIF_Y110_PLUVIAL_PLACEMENT_OFFSET_Y_MM = 0.0
BIF_Y110_PLUVIAL_PLACEMENT_OFFSET_Z_MM = 0.0
# Recortes nudo TE 110-110-110 solo pluvial (editar; fecal usa TE_TRIMS / otro script).
BIF_Y110_PLUVIAL_TE_TRIM_MAIN_IN_MM = 50.0
BIF_Y110_PLUVIAL_TE_TRIM_MAIN_OUT_MM = 147.0
BIF_Y110_PLUVIAL_TE_TRIM_BRANCH_MM = 148.0
# ---------------------------------------------------
# SANEAMIENTO 90° = 2x45° (110 mm) — ajustes globales
# ---------------------------------------------------
DOUBLE45_110_AUTO_SEP_MM = 0.0
DOUBLE45_110_CODO1_OFFSET_X_MM = -110.0
DOUBLE45_110_CODO1_OFFSET_Y_MM = 60.0
DOUBLE45_110_CODO1_OFFSET_Z_MM = 100.0
DOUBLE45_110_CODO2_OFFSET_X_MM = 80.0
DOUBLE45_110_CODO2_OFFSET_Y_MM = 60.0
DOUBLE45_110_CODO2_OFFSET_Z_MM = 100.0
# Ajuste global para codo 90° de 110 mm (outer + inner).
# Portado de Saneamiento_old (L1000_D87) para el codo 110/90-87.
CODO90_110_OFFSET_X_MM = 183.0
CODO90_110_OFFSET_Y_MM = 68.0
CODO90_110_OFFSET_Z_MM = 0.0
# Codo 110mm 90° fecal (cambio de plano): copia explícita de offsets.
# Se mantiene independiente por nombre para separar fecal/pluvial.
CODO90_110_FECAL_OFFSET_X_MM = CODO90_110_OFFSET_X_MM
CODO90_110_FECAL_OFFSET_Y_MM = CODO90_110_OFFSET_Y_MM
CODO90_110_FECAL_OFFSET_Z_MM = CODO90_110_OFFSET_Z_MM
# Ajuste global para codo 45° individual de 110 mm (outer + inner).
CODO45_110_OFFSET_X_MM = -15.0
CODO45_110_OFFSET_Y_MM = 22.0
CODO45_110_OFFSET_Z_MM = 100.0
# Ajuste global para Tap reductor 40<->25 (outer + inner), en eje local del fitting.
TAPRED_40_25_OFFSET_X_MM = 60.0
TAPRED_40_25_OFFSET_Y_MM = 12.5
TAPRED_40_25_OFFSET_Z_MM = 10.0
# Recortes TAPRED / 110↔40: editar valores en utils/trim_config.py (TAPRED_*_TRIM_*, REDUCT_*_TRIM_*).
# Reductor conjunto 110<->40 (Reduct_110_50_40_script), en ejes locales del fitting
# (bisectriz aproximada + binormal), mismo convenio que TAPRED_40_25.
# Tras editar: saneamiento_polyline re-enlaza PipelineProcessor al recargar el módulo.
REDUCT_110_40_OFFSET_X_MM = 0.0
REDUCT_110_40_OFFSET_Y_MM = 90.0
REDUCT_110_40_OFFSET_Z_MM = -55.0

_DERIV_Y45_D40_CLASS: Any = None
_DERIV_Y45_D40_LOAD_FAILED = False
_DERIV_Y110_D110_CLASS: Any = None
_DERIV_Y110_D110_LOAD_FAILED = False


def _get_derivacion_y45_d40_model_class() -> Optional[Type[Any]]:
    """Carga perezosa de DerivacionY45D40 para TE 40-40-40 en el pipeline."""
    global _DERIV_Y45_D40_CLASS, _DERIV_Y45_D40_LOAD_FAILED
    if _DERIV_Y45_D40_CLASS is not None:
        return _DERIV_Y45_D40_CLASS
    if _DERIV_Y45_D40_LOAD_FAILED:
        return None
    try:
        pyp_dir = os.path.dirname(os.path.dirname(__file__))
        path = os.path.join(pyp_dir, "DerivacionY45_script.py")
        if not os.path.isfile(path):
            _DERIV_Y45_D40_LOAD_FAILED = True
            return None
        spec = importlib.util.spec_from_file_location(
            "saneamiento_derivacion_y45_d40_runtime", path
        )
        if not spec or not spec.loader:
            _DERIV_Y45_D40_LOAD_FAILED = True
            return None
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        cls = getattr(mod, "DerivacionY45D40", None)
        if cls is None:
            _DERIV_Y45_D40_LOAD_FAILED = True
            return None
        _DERIV_Y45_D40_CLASS = cls
        return cls
    except Exception as ex:
        print(f"[SANEAMIENTO][TE-Y40] Error cargando DerivacionY45_script: {ex}")
        _DERIV_Y45_D40_LOAD_FAILED = True
        return None


def _get_derivacion_y110_d110_model_class() -> Optional[Type[Any]]:
    """Carga perezosa de DerivacionY110D110 (pluvial) para TE 110-110-110 en el pipeline."""
    global _DERIV_Y110_D110_CLASS, _DERIV_Y110_D110_LOAD_FAILED
    if _DERIV_Y110_D110_CLASS is not None:
        return _DERIV_Y110_D110_CLASS
    if _DERIV_Y110_D110_LOAD_FAILED:
        return None
    try:
        pyp_dir = os.path.dirname(os.path.dirname(__file__))
        path = os.path.join(pyp_dir, "Derivacion110m_f_script.py")
        if not os.path.isfile(path):
            _DERIV_Y110_D110_LOAD_FAILED = True
            return None
        spec = importlib.util.spec_from_file_location(
            "saneamiento_derivacion_y110_pluvial_runtime", path
        )
        if not spec or not spec.loader:
            _DERIV_Y110_D110_LOAD_FAILED = True
            return None
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        cls = getattr(mod, "DerivacionY110D110", None)
        if cls is None:
            _DERIV_Y110_D110_LOAD_FAILED = True
            return None
        _DERIV_Y110_D110_CLASS = cls
        return cls
    except Exception as ex:
        print(f"[SANEAMIENTO][TE-Y110-P] Error cargando Derivacion110m_f_script: {ex}")
        _DERIV_Y110_D110_LOAD_FAILED = True
        return None


# Recortes extra para codo_45 individual (25 mm):
# - TRIM_IN: recorta el tramo entrante al codo_45
# - TRIM_OUT: recorta el tramo saliente del codo_45
CODO45_25_TRIM_IN_MM = 30.0
CODO45_25_TRIM_OUT_MM = 20.0
# Recortes extra para codo_45 individual (40 mm):
# - TRIM_IN: recorta el tramo entrante al codo_45
# - TRIM_OUT: recorta el tramo saliente del codo_45
CODO45_40_TRIM_IN_MM = 30.0
CODO45_40_TRIM_OUT_MM = 20.0
# Recortes extra para codo_90 real (25 mm):
# - TRIM_IN: recorta el tramo entrante al codo_90
# - TRIM_OUT: recorta el tramo saliente del codo_90
CODO90_25_TRIM_IN_MM = 30.0
CODO90_25_TRIM_OUT_MM = 30.0
# Recortes extra para codo_90 real (40 mm):
# - TRIM_IN: recorta el tramo entrante al codo_90
# - TRIM_OUT: recorta el tramo saliente del codo_90
CODO90_40_TRIM_IN_MM = 30.0
CODO90_40_TRIM_OUT_MM = 45.0
# Recortes extra para codo_45 individual (110 mm):
# - TRIM_IN: recorta el tramo entrante al codo_45
# - TRIM_OUT: recorta el tramo saliente del codo_45
CODO45_110_TRIM_IN_MM = 40.0
CODO45_110_TRIM_OUT_MM = 50.0
# Recortes extra para codo_90 real (110 mm):
# - TRIM_IN: recorta el tramo entrante al codo_90
# - TRIM_OUT: recorta el tramo saliente del codo_90
# Valores de Saneamiento_old para codo rígido 110mm/90° (L1000_D87).
CODO90_110_TRIM_IN_MM = 82.0
CODO90_110_TRIM_OUT_MM = 150.0
# Codo 110mm 90° fecal (cambio de plano): copia explícita de trims.
# Se mantiene independiente por nombre para separar fecal/pluvial.
CODO90_110_FECAL_TRIM_IN_MM = CODO90_110_TRIM_IN_MM
CODO90_110_FECAL_TRIM_OUT_MM = CODO90_110_TRIM_OUT_MM
# Recortes extra para 2x45 (25 mm):
# - TRIM_IN: acorta la entrada al primer codo
# - TRIM_OUT: acorta la salida del segundo codo
DOUBLE45_TRIM_IN_MM = 50.0
DOUBLE45_TRIM_OUT_MM = 50.0
# Recortes extra para 2x45 (40 mm):
# - TRIM_IN: acorta la entrada al primer codo
# - TRIM_OUT: acorta la salida del segundo codo
DOUBLE45_40_TRIM_IN_MM = 70.0
DOUBLE45_40_TRIM_OUT_MM = 70.0
# Recortes extra para 2x45 (110 mm):
# - TRIM_IN: acorta la entrada al primer codo
# - TRIM_OUT: acorta la salida del segundo codo
DOUBLE45_110_TRIM_IN_MM = 150.0
DOUBLE45_110_TRIM_OUT_MM = 150.0


def _reduct_110_40_offsets_mm():
    """Offsets 110↔40: leer siempre del módulo cargado (coherente tras importlib.reload)."""
    import sys

    m = sys.modules.get(__name__)
    if m is None:
        return (70.0, 0.0, 0.0)
    return (
        float(getattr(m, "REDUCT_110_40_OFFSET_X_MM", 70.0)),
        float(getattr(m, "REDUCT_110_40_OFFSET_Y_MM", 0.0)),
        float(getattr(m, "REDUCT_110_40_OFFSET_Z_MM", 0.0)),
    )


def _manguito_bisector_offset_point(pos_base, seg, next_seg, off_x_mm, off_y_mm, off_z_mm):
    """
    Punto desplazado desde pos_base según offsets en marco local al nudo:
    X ~ bisectriz de las direcciones de tramo, Y/Z ~ referencia cruzada (igual que Tap 40-25).
    """
    v_in = getattr(seg, "vector_normalizado", AllplanGeo.Vector3D(0.0, 0.0, 0.0))
    v_out = getattr(next_seg, "vector_normalizado", AllplanGeo.Vector3D(0.0, 0.0, 0.0))

    def _norm(v):
        n = math.sqrt(v.X * v.X + v.Y * v.Y + v.Z * v.Z)
        if n <= 1e-9:
            return AllplanGeo.Vector3D(0.0, 0.0, 0.0)
        return AllplanGeo.Vector3D(v.X / n, v.Y / n, v.Z / n)

    def _cross(a, b):
        return AllplanGeo.Vector3D(
            a.Y * b.Z - a.Z * b.Y,
            a.Z * b.X - a.X * b.Z,
            a.X * b.Y - a.Y * b.X,
        )

    x_local = _norm(AllplanGeo.Vector3D(v_in.X + v_out.X, v_in.Y + v_out.Y, v_in.Z + v_out.Z))
    if abs(x_local.X) < 1e-9 and abs(x_local.Y) < 1e-9 and abs(x_local.Z) < 1e-9:
        x_local = _norm(v_out)
    z_local = _norm(_cross(v_in, v_out))
    if abs(z_local.X) < 1e-9 and abs(z_local.Y) < 1e-9 and abs(z_local.Z) < 1e-9:
        z_local = AllplanGeo.Vector3D(0.0, 0.0, 1.0)
    y_local = _norm(_cross(z_local, x_local))
    if abs(y_local.X) < 1e-9 and abs(y_local.Y) < 1e-9 and abs(y_local.Z) < 1e-9:
        y_local = AllplanGeo.Vector3D(1.0, 0.0, 0.0)

    return AllplanGeo.Point3D(
        pos_base.X
        + (x_local.X * off_x_mm)
        + (y_local.X * off_y_mm)
        + (z_local.X * off_z_mm),
        pos_base.Y
        + (x_local.Y * off_x_mm)
        + (y_local.Y * off_y_mm)
        + (z_local.Y * off_z_mm),
        pos_base.Z
        + (x_local.Z * off_x_mm)
        + (y_local.Z * off_y_mm)
        + (z_local.Z * off_z_mm),
    )


class GeometryHandler:
    def center_and_connect_models_v10(
        self,
        data_list,
        conducto_width=75,
        color=None,
        point_role=None,
        point_side=None,
        debug=True,
    ):
        """
        Versión v11.

        REGLA SIMPLIFICADA — solo el segmento FRONTERA rota en la transición:
        ──────────────────────────────────────────────────────────────────────
        Dado un cambio de plano entre dos segmentos consecutivos:

          ... XZ[n-1]  XZ[n]  |  XY[n+1]  XY[n+2] ...
                          ↑ frontera fin

          ... XY[n-1]  XY[n]  |  XZ[n+1]  XZ[n+2] ...
                                       ↑ frontera inicio

        Solo el segmento inmediatamente adyacente a la transición recibe
        el adjacent_xy_roll del segmento XY contiguo.
        El resto del grupo XZ/YZ solo recibe el extra_roll de +90°.

        Además, el segmento frontera se recorta TRIM_BOUNDARY mm para
        evitar solapamiento en la unión.

        Tabla de resultados para los 6 segmentos del documento:
          line_1 (XZ) → roll=90°  (solo +view, no es frontera)
          line_2 (XZ) → roll=90°  (solo +view, no es frontera)
          line_3 (XZ) → roll=135° (+view+45°, ES frontera con line_4) + trim 10mm
          line_4 (XY) → roll=0°   (plano XY normal)
          line_5 (XY) → roll=0°
          line_6 (XY) → roll=0°
        """
        elementos_transformados = []
        last_real_end_point = None
        last_segment = None

        TRIM_BOUNDARY = 20.0  # mm de recorte en el segmento frontera

        def get_dot_product(v1, v2):
            if not v1 or not v2:
                return 1.0
            return v1.X * v2.X + v1.Y * v2.Y + v1.Z * v2.Z

        def same_direction(seg1, seg2, tol_deg=1):
            if not seg1 or not seg2:
                return False
            diff = abs((seg1.data.angulo_xy - seg2.data.angulo_xy + 180) % 360 - 180)
            return diff < tol_deg

        CONDUCTO_WIDTH = conducto_width
        TIPOS_ACCESORIOS = ["manguito", "codo_45", "codo_90", "conexion", "difusor"]
        UMBRAL_Z = 0.1

        if debug:
            print(f"\n{'#'*70}")
            print(f"# PROCESANDO DATA LIST: {len(data_list)}")
            print(f"{'#'*70}")

        # =====================================================================
        # PASO 1: recopilar view_mode y angulo_xy
        # =====================================================================
        seg_view_modes = []
        seg_angulo_xy = []
        for item in data_list:
            seg = item.get("segment")
            if seg:
                seg_view_modes.append(getattr(seg, "view_mode", "XY"))
                seg_angulo_xy.append(getattr(seg.data, "angulo_xy", 0.0))
            else:
                seg_view_modes.append("XY")
                seg_angulo_xy.append(0.0)

        # =====================================================================
        # PASO 2: detectar grupos por view_mode
        # =====================================================================
        grupos = []
        if data_list:
            vm_actual = seg_view_modes[0]
            idx_inicio = 0
            for idx in range(1, len(data_list)):
                if seg_view_modes[idx] != vm_actual:
                    grupos.append((vm_actual, list(range(idx_inicio, idx))))
                    vm_actual = seg_view_modes[idx]
                    idx_inicio = idx
            grupos.append((vm_actual, list(range(idx_inicio, len(data_list)))))

        if debug:
            print(f"\n--- Grupos detectados por view_mode ---")
            for g_vm, g_idx in grupos:
                names = [
                    getattr(data_list[k].get("segment"), "name", f"Seg_{k}")
                    for k in g_idx
                    if data_list[k].get("segment")
                ]
                print(f"  [{g_vm}] indices={g_idx} → {names}")
            print()

        # =====================================================================
        # PASO 3: effective_yaw  (dirección de viaje propia)
        #
        # · Grupo XY   → propio angulo_xy con herencia delta_z interna
        # · Grupo XZ/YZ → propio angulo_xy individual de cada segmento
        # =====================================================================
        effective_yaw = [0.0] * len(data_list)
        for g_vm, g_idx in grupos:
            if g_vm == "XY":
                last_xy_angle = None
                for k in g_idx:
                    seg = data_list[k].get("segment")
                    if not seg:
                        effective_yaw[k] = (
                            last_xy_angle if last_xy_angle is not None else 0.0
                        )
                        continue
                    dz = abs(getattr(seg.data, "delta_z", 0.0))
                    if dz < UMBRAL_Z:
                        last_xy_angle = getattr(seg.data, "angulo_xy", 0.0)
                        effective_yaw[k] = last_xy_angle
                    else:
                        effective_yaw[k] = (
                            last_xy_angle if last_xy_angle is not None else 0.0
                        )
            else:
                for k in g_idx:
                    seg = data_list[k].get("segment")
                    effective_yaw[k] = (
                        getattr(seg.data, "angulo_xy", 0.0) if seg else 0.0
                    )

        # =====================================================================
        # PASO 4: extra_roll_by_view (+90° solo para XZ/YZ)
        # =====================================================================
        extra_roll_by_view = [
            90.0 if seg_view_modes[i] in ("XZ", "YZ") else 0.0
            for i in range(len(data_list))
        ]

        # =====================================================================
        # PASO 5: adjacent_xy_roll  +  boundary_trim
        #
        # Solo el segmento FRONTERA (inmediatamente en la transición) recibe
        # el ángulo del grupo XY adyacente.
        # Todos los demás segmentos del grupo XZ/YZ → 0°.
        #
        # Frontera FIN   → último  segmento del grupo XZ/YZ antes de un XY
        #                  toma angulo_xy del PRIMER segmento del grupo XY siguiente
        # Frontera INICIO → primer segmento del grupo XZ/YZ después de un XY
        #                   toma angulo_xy del ÚLTIMO segmento del grupo XY anterior
        #
        # boundary_trim[i] = True si ese segmento es frontera y debe recortarse.
        # =====================================================================
        adjacent_xy_roll = [0.0] * len(data_list)
        boundary_trim = [False] * len(data_list)

        for g_num, (g_vm, g_idx) in enumerate(grupos):
            if g_vm == "XY":
                continue

            # ── Frontera FIN: XZ/YZ → XY ─────────────────────────────────────
            # Buscar grupo XY inmediatamente siguiente
            for g2_vm, g2_idx in grupos[g_num + 1 :]:
                if g2_vm == "XY" and g2_idx:
                    frontera_idx = g_idx[-1]  # último del grupo XZ/YZ
                    ref_angle = seg_angulo_xy[g2_idx[0]]
                    adjacent_xy_roll[frontera_idx] = ref_angle
                    boundary_trim[frontera_idx] = True
                    if debug:
                        fn = getattr(
                            data_list[frontera_idx].get("segment"),
                            "name",
                            f"Seg_{frontera_idx}",
                        )
                        rn = getattr(
                            data_list[g2_idx[0]].get("segment"),
                            "name",
                            f"Seg_{g2_idx[0]}",
                        )
                        print(
                            f"  Frontera FIN  [{frontera_idx}]{fn} "
                            f"← angulo_xy de [{g2_idx[0]}]{rn} = {ref_angle:.2f}°  "
                            f"(trim={TRIM_BOUNDARY}mm)"
                        )
                break  # solo el grupo XY inmediatamente siguiente

            # ── Frontera INICIO: XY → XZ/YZ ──────────────────────────────────
            # Buscar grupo XY inmediatamente anterior
            for g2_vm, g2_idx in reversed(grupos[:g_num]):
                if g2_vm == "XY" and g2_idx:
                    frontera_idx = g_idx[0]  # primero del grupo XZ/YZ
                    ref_angle = seg_angulo_xy[g2_idx[-1]]
                    adjacent_xy_roll[frontera_idx] = ref_angle
                    boundary_trim[frontera_idx] = True
                    if debug:
                        fn = getattr(
                            data_list[frontera_idx].get("segment"),
                            "name",
                            f"Seg_{frontera_idx}",
                        )
                        rn = getattr(
                            data_list[g2_idx[-1]].get("segment"),
                            "name",
                            f"Seg_{g2_idx[-1]}",
                        )
                        print(
                            f"  Frontera INI  [{frontera_idx}]{fn} "
                            f"← angulo_xy de [{g2_idx[-1]}]{rn} = {ref_angle:.2f}°  "
                            f"(trim={TRIM_BOUNDARY}mm)"
                        )
                break  # solo el grupo XY inmediatamente anterior

        # =====================================================================
        # DEBUG — tabla resumen
        # =====================================================================
        if debug:
            print(f"\n--- Tabla de rotaciones por segmento (v11) ---")
            print(
                f"  {'i':<3} {'nombre':<12} {'vm':<4} {'ang_xy':>8} "
                f"{'yaw':>8} {'+view':>6} {'+adj':>6} {'roll':>7} {'trim':>5}"
            )
            print(f"  {'-'*68}")
            for idx, item in enumerate(data_list):
                seg = item.get("segment")
                name = getattr(seg, "name", f"Seg_{idx}") if seg else f"Item_{idx}"
                vm = seg_view_modes[idx]
                ang = seg_angulo_xy[idx]
                yaw = effective_yaw[idx]
                ev = extra_roll_by_view[idx]
                ar = adjacent_xy_roll[idx]
                seg_ar = getattr(seg.data, "angulo_rotacion", 0) if seg else 0
                total_r = seg_ar + ev + ar
                trim = f"{TRIM_BOUNDARY:.0f}mm" if boundary_trim[idx] else "—"
                print(
                    f"  {idx:<3} {name:<12} {vm:<4} {ang:>8.2f}° "
                    f"{yaw:>8.2f}° {ev:>5.0f}° {ar:>5.0f}° {total_r:>6.1f}° {trim:>5}"
                )
            print()

        # =====================================================================
        # LOOP PRINCIPAL
        # =====================================================================
        for i, item in enumerate(data_list):
            try:
                segment = item.get("segment")
                if not segment:
                    continue
                data = segment.data
                item_name = getattr(segment, "name", f"Segment_{i}")
                start_point = getattr(data, "start", None)
                if start_point is None:
                    continue
                tipo_str = item.get("type", "")
                is_dinamic = tipo_str not in TIPOS_ACCESORIOS

                vec_curr = getattr(data, "vector_normalizado", None)
                if vec_curr is None:
                    vec_curr = AllplanGeo.Vector3D(
                        getattr(data, "delta_x", 0),
                        getattr(data, "delta_y", 0),
                        getattr(data, "delta_z", 0),
                    )
                    vec_curr.Normalize()

                if (
                    last_real_end_point is not None
                    and last_segment is not None
                    and same_direction(last_segment, segment)
                ):
                    start_point = last_real_end_point

                extension_inicio = 0.0
                extension_final = 0.0

                # ── Extensiones en uniones (solo tubos dinámicos) ─────────────
                if is_dinamic:
                    MIN_ANGLE_RAD = 0.0175
                    MAX_ANGLE_RAD = math.pi - 0.0175

                    if i > 0:
                        prev_item = data_list[i - 1]
                        prev_tipo_s = prev_item.get("type", "")
                        prev_tipo_s = (
                            prev_tipo_s
                            if isinstance(prev_tipo_s, str)
                            else (prev_tipo_s[0] if prev_tipo_s else "")
                        )
                        if prev_tipo_s == "manguito":
                            extension_inicio = 0.0
                            if debug:
                                print(
                                    f"  {item_name} – manguito anterior → ext_inicio=0"
                                )
                        else:
                            p_data = prev_item["segment"].data
                            vec_prev = AllplanGeo.Vector3D(
                                p_data.delta_x, p_data.delta_y, p_data.delta_z
                            )
                            vec_prev.Normalize()
                            dot = max(
                                -1.0, min(1.0, get_dot_product(vec_prev, vec_curr))
                            )
                            a_rad = math.acos(dot)
                            if MIN_ANGLE_RAD < a_rad < MAX_ANGLE_RAD:
                                extension_inicio = (CONDUCTO_WIDTH / 2.0) * math.tan(
                                    a_rad / 2.0
                                )
                                if debug:
                                    print(
                                        f"  {item_name} – ext_inicio: {math.degrees(a_rad):.1f}° → {extension_inicio:.2f}mm"
                                    )

                    if i < len(data_list) - 1:
                        next_item = data_list[i + 1]
                        next_tipo_s = next_item.get("type", "")
                        next_tipo_s = (
                            next_tipo_s
                            if isinstance(next_tipo_s, str)
                            else (next_tipo_s[0] if next_tipo_s else "")
                        )
                        if next_tipo_s == "manguito":
                            extension_final = 0.0
                            if debug:
                                print(
                                    f"  {item_name} – manguito siguiente → ext_final=0"
                                )
                        else:
                            n_data = next_item["segment"].data
                            vec_next = AllplanGeo.Vector3D(
                                n_data.delta_x, n_data.delta_y, n_data.delta_z
                            )
                            vec_next.Normalize()
                            dot = max(
                                -1.0, min(1.0, get_dot_product(vec_curr, vec_next))
                            )
                            a_rad = math.acos(dot)
                            if MIN_ANGLE_RAD < a_rad < MAX_ANGLE_RAD:
                                extension_final = (CONDUCTO_WIDTH / 2.0) * math.tan(
                                    a_rad / 2.0
                                )
                                if debug:
                                    print(
                                        f"  {item_name} – ext_final: {math.degrees(a_rad):.1f}° → {extension_final:.2f}mm"
                                    )

                longitud_original = getattr(data, "longitud_3d", 0.0)

                # ── Recorte de 10mm si es segmento frontera ───────────────────
                if boundary_trim[i] and is_dinamic:
                    longitud_original = max(0.0, longitud_original - TRIM_BOUNDARY)
                    if debug:
                        print(
                            f"  {item_name} [FRONTERA] longitud recortada "
                            f"{TRIM_BOUNDARY}mm → {longitud_original:.2f}mm"
                        )

                longitud_total = longitud_original + extension_inicio + extension_final

                if debug and is_dinamic:
                    print(f"\n{item_name}")
                    print(
                        f"  long_orig={longitud_original:.2f} | ext_i={extension_inicio:.2f} | "
                        f"ext_f={extension_final:.2f} | total={longitud_total:.2f}"
                    )

                list_elem_3d = item.get("element3d", [])
                lista_elem_3d_modified = []
                if is_dinamic:
                    for elem in list_elem_3d:
                        lista_elem_3d_modified.append(
                            self.modificar_dimensiones_brep(elem, longitud_total)
                        )
                else:
                    lista_elem_3d_modified = list_elem_3d

                segment_brep = None
                for e, elem_3d in enumerate(lista_elem_3d_modified):
                    prop = elem_3d.GetCommonProperties()
                    if is_dinamic and color:
                        prop.Color = color

                    brep = elem_3d.GetGeometryObject()
                    _, verts = brep.GetVertices()

                    pmx = (start_point.X + data.end.X) / 2.0
                    pmy = (start_point.Y + data.end.Y) / 2.0
                    pmz = (start_point.Z + data.end.Z) / 2.0
                    if verts:
                        pmx = sum(v.X for v in verts) / len(verts)
                        pmy = sum(v.Y for v in verts) / len(verts)
                        pmz = sum(v.Z for v in verts) / len(verts)

                    nuevo_brep = None

                    # ──────────────────────────────────────────────────────────
                    # CASO 1 – MANGUITO
                    # ──────────────────────────────────────────────────────────
                    if tipo_str == "manguito":
                        segment_brep = None
                        if e == 0:
                            _, vp = brep.GetVertices()
                            if vp:
                                cx = sum(v.X for v in vp) / len(vp)
                                cy = sum(v.Y for v in vp) / len(vp)
                                cz = sum(v.Z for v in vp) / len(vp)
                            else:
                                cx, cy, cz = pmx, pmy, pmz
                            if not hasattr(self, "_temp_manguito_center"):
                                self._temp_manguito_center = {}
                            self._temp_manguito_center[i] = (cx, cy, cz)
                        else:
                            cx, cy, cz = self._temp_manguito_center.get(i, (0, 0, 0))

                        brep = AllplanGeo.Move(
                            brep,
                            AllplanGeo.Vector3D(
                                -cx + (longitud_original / 2.0), -cy, -cz
                            ),
                        )

                        rot_xy = effective_yaw[i]
                        rot_pitch = math.degrees(
                            math.atan2(data.delta_z, getattr(data, "longitud_xy", 0))
                        )
                        total_roll_m = (
                            getattr(data, "angulo_rotacion", 0)
                            + extra_roll_by_view[i]
                            + adjacent_xy_roll[i]
                        )

                        if debug:
                            print(
                                f"  {item_name} [manguito] "
                                f"vm={seg_view_modes[i]} | yaw={rot_xy:.2f}° | "
                                f"pitch={rot_pitch:.2f}° | roll={total_roll_m:.1f}°"
                            )

                        if abs(total_roll_m) > 0.001:
                            m = AllplanGeo.Matrix3D()
                            m.Rotation(
                                AllplanGeo.Line3D(0, 0, 0, 1, 0, 0),
                                AllplanGeo.Angle.FromDeg(total_roll_m),
                            )
                            brep = AllplanGeo.Transform(brep, m)

                        m = AllplanGeo.Matrix3D()
                        m.Rotation(
                            AllplanGeo.Line3D(0, 0, 0, 0, 0, 1),
                            AllplanGeo.Angle.FromDeg(rot_xy),
                        )
                        brep = AllplanGeo.Transform(brep, m)

                        if abs(rot_pitch) > 0.1:
                            rad_xy = math.radians(rot_xy)
                            axis = AllplanGeo.Line3D(
                                0, 0, 0, math.sin(rad_xy), -math.cos(rad_xy), 0
                            )
                            m = AllplanGeo.Matrix3D()
                            m.Rotation(axis, AllplanGeo.Angle.FromDeg(rot_pitch))
                            brep = AllplanGeo.Transform(brep, m)

                        nuevo_brep = AllplanGeo.Move(
                            brep,
                            AllplanGeo.Vector3D(
                                (start_point.X + data.end.X) / 2.0,
                                (start_point.Y + data.end.Y) / 2.0,
                                (start_point.Z + data.end.Z) / 2.0,
                            ),
                        )
                        elementos_transformados.append(
                            {
                                "index": i,
                                "element_type": tipo_str,
                                "element": AllplanBasisElements.ModelElement3D(
                                    prop, nuevo_brep
                                ),
                            }
                        )

                    # ──────────────────────────────────────────────────────────
                    # CASO 2 – DIFUSOR
                    # ──────────────────────────────────────────────────────────
                    elif tipo_str == "difusor":
                        move_offset = 0
                        if point_side == 0:
                            move_offset = CONDUCTO_WIDTH / 2
                        elif point_side == 2:
                            move_offset = -CONDUCTO_WIDTH / 2
                        ang_int = int(data.angulo_xy)

                        if debug:
                            print(
                                f"  start_point: ({start_point.X:.1f}, {start_point.Y:.1f}, {start_point.Z:.1f})"
                            )

                        if point_role == "inicial":
                            punto_inicio_real = start_point
                            for j in range(i + 1, len(data_list)):
                                ni = data_list[j]
                                nt_s = ni.get("type", "")
                                nt_s = (
                                    nt_s
                                    if isinstance(nt_s, str)
                                    else (nt_s[0] if nt_s else "")
                                )
                                if nt_s not in TIPOS_ACCESORIOS:
                                    punto_inicio_real = getattr(
                                        ni["segment"].data, "start", start_point
                                    )
                                    break
                            _, vd = brep.GetVertices()
                            if vd:
                                brep = AllplanGeo.Move(
                                    brep,
                                    AllplanGeo.Vector3D(
                                        -sum(v.X for v in vd) / len(vd),
                                        -sum(v.Y for v in vd) / len(vd),
                                        -sum(v.Z for v in vd) / len(vd),
                                    ),
                                )
                            if ang_int != 0:
                                mr = AllplanGeo.Matrix3D()
                                mr.Rotation(
                                    AllplanGeo.Line3D(0, 0, 0, 0, 0, 1),
                                    AllplanGeo.Angle.FromDeg(data.angulo_xy),
                                )
                                brep = AllplanGeo.Transform(brep, mr)
                            w_cubo = -60 if ang_int in [0, 90, 89] else 60
                            offset_x = punto_inicio_real.X + w_cubo
                            offset_y = punto_inicio_real.Y + (
                                move_offset if ang_int in [0, 180, 178, 179] else w_cubo
                            )
                            nuevo_brep = AllplanGeo.Move(
                                brep,
                                AllplanGeo.Vector3D(
                                    offset_x, offset_y - 1, punto_inicio_real.Z + 11
                                ),
                            )

                        elif point_role == "final":
                            punto_final_real = getattr(
                                data,
                                "end",
                                AllplanGeo.Point3D(
                                    start_point.X + data.delta_x,
                                    start_point.Y + data.delta_y,
                                    start_point.Z + data.delta_z,
                                ),
                            )
                            if i < len(data_list) - 1:
                                for j in range(len(data_list) - 1, i, -1):
                                    ni = data_list[j]
                                    nt_s = ni.get("type", "")
                                    nt_s = (
                                        nt_s
                                        if isinstance(nt_s, str)
                                        else (nt_s[0] if nt_s else "")
                                    )
                                    if nt_s not in TIPOS_ACCESORIOS:
                                        punto_final_real = getattr(
                                            ni["segment"].data, "end", punto_final_real
                                        )
                                        break
                            cdz = 0
                            _, vd = brep.GetVertices()
                            if vd:
                                cdz = sum(v.Z for v in vd) / len(vd)
                                brep = AllplanGeo.Move(
                                    brep,
                                    AllplanGeo.Vector3D(
                                        -sum(v.X for v in vd) / len(vd),
                                        -sum(v.Y for v in vd) / len(vd),
                                        -cdz,
                                    ),
                                )
                            rot_diff = (
                                180
                                if ang_int == 0
                                else (
                                    0
                                    if ang_int in [180, 179, 178]
                                    else (
                                        -data.angulo_xy
                                        if ang_int in [-90, 89, 90, -89]
                                        else 0
                                    )
                                )
                            )
                            mr = AllplanGeo.Matrix3D()
                            mr.Rotation(
                                AllplanGeo.Line3D(0, 0, 0, 0, 0, 1),
                                AllplanGeo.Angle.FromDeg(rot_diff),
                            )
                            brep = AllplanGeo.Transform(brep, mr)
                            padding = 60
                            ltc = AllplanGeo.CalcLength(
                                AllplanGeo.Line3D(
                                    (
                                        data_list[0]["segment"].data.start
                                        if data_list[0].get("type", "")
                                        not in TIPOS_ACCESORIOS
                                        else start_point
                                    ),
                                    punto_final_real,
                                )
                            )
                            if ang_int in [0, 180, 179, 178]:
                                factor = -1 if ang_int in [180, 179, 178] else 1
                                nuevo_brep = AllplanGeo.Move(
                                    brep,
                                    AllplanGeo.Vector3D(
                                        punto_final_real.X + (padding * factor),
                                        punto_final_real.Y + move_offset,
                                        punto_final_real.Z - cdz + 11,
                                    ),
                                )
                            else:
                                factor = -1 if ang_int in [-90, -89] else 1
                                nuevo_brep = AllplanGeo.Move(
                                    brep,
                                    AllplanGeo.Vector3D(
                                        punto_final_real.X + move_offset,
                                        punto_final_real.Y + (padding * factor),
                                        punto_final_real.Z - cdz + 11,
                                    ),
                                )
                        else:
                            nuevo_brep = AllplanGeo.Move(
                                brep, AllplanGeo.Vector3D(pmx, pmy, pmz)
                            )

                        elementos_transformados.append(
                            {
                                "index": i,
                                "element_type": tipo_str,
                                "element": AllplanBasisElements.ModelElement3D(
                                    prop, nuevo_brep
                                ),
                            }
                        )

                    # ──────────────────────────────────────────────────────────
                    # CASO 3 – TUBOS DINÁMICOS
                    # ──────────────────────────────────────────────────────────
                    else:
                        nx = sum(v.X for v in verts) / len(verts) if verts else 0
                        ny = sum(v.Y for v in verts) / len(verts) if verts else 0
                        nz = sum(v.Z for v in verts) / len(verts) if verts else 0
                        brep = AllplanGeo.Move(brep, AllplanGeo.Vector3D(-nx, -ny, -nz))

                        rot_xy = effective_yaw[i]
                        long_xy_seg = getattr(data, "longitud_xy", 0.0)
                        rot_pitch = math.degrees(math.atan2(data.delta_z, long_xy_seg))
                        total_roll_t = (
                            getattr(data, "angulo_rotacion", 0)
                            + extra_roll_by_view[i]
                            + adjacent_xy_roll[i]
                        )

                        if debug:
                            frontera_tag = " [FRONTERA]" if boundary_trim[i] else ""
                            print(
                                f"  {item_name}{frontera_tag} "
                                f"[vm={seg_view_modes[i]}] "
                                f"yaw={rot_xy:.2f}° | pitch={rot_pitch:.2f}° | "
                                f"roll={total_roll_t:.1f}° "
                                f"(+view={extra_roll_by_view[i]:.0f}° "
                                f"+adj={adjacent_xy_roll[i]:.0f}°)"
                            )

                        # 1) Roll total
                        if abs(total_roll_t) > 0.001:
                            m = AllplanGeo.Matrix3D()
                            m.Rotation(
                                AllplanGeo.Line3D(0, 0, 0, 1, 0, 0),
                                AllplanGeo.Angle.FromDeg(total_roll_t),
                            )
                            brep = AllplanGeo.Transform(brep, m)

                        # 2) Yaw
                        m = AllplanGeo.Matrix3D()
                        m.Rotation(
                            AllplanGeo.Line3D(0, 0, 0, 0, 0, 1),
                            AllplanGeo.Angle.FromDeg(rot_xy),
                        )
                        brep = AllplanGeo.Transform(brep, m)

                        # 3) Pitch
                        if abs(rot_pitch) > 0.001:
                            rad_xy = math.radians(rot_xy)
                            axis = AllplanGeo.Line3D(
                                0, 0, 0, math.sin(rad_xy), -math.cos(rad_xy), 0
                            )
                            m = AllplanGeo.Matrix3D()
                            m.Rotation(axis, AllplanGeo.Angle.FromDeg(rot_pitch))
                            brep = AllplanGeo.Transform(brep, m)

                        desplazamiento_neto = (
                            longitud_original / 2.0
                            + (extension_final - extension_inicio) / 2.0
                        )
                        mid_x = start_point.X + vec_curr.X * desplazamiento_neto
                        mid_y = start_point.Y + vec_curr.Y * desplazamiento_neto
                        mid_z = start_point.Z + vec_curr.Z * desplazamiento_neto

                        nuevo_brep = AllplanGeo.Move(
                            brep, AllplanGeo.Vector3D(mid_x, mid_y, mid_z)
                        )
                        segment_brep = {
                            "index": i,
                            "element_type": tipo_str,
                            "element": AllplanBasisElements.ModelElement3D(
                                prop, nuevo_brep
                            ),
                        }
                        elementos_transformados.append(segment_brep)

            except Exception as ex:
                if debug:
                    print(f"ERROR CRÍTICO en elemento {i} ({tipo_str}): {ex}")

        if debug:
            print(f"\n{'='*70}")
            print(f"COMPLETADO: {len(elementos_transformados)} elementos procesados")
            print(f"{'='*70}\n")

        return elementos_transformados

    def center_and_connect_models_v9(
        self,
        data_list,
        conducto_width=75,
        color=None,
        point_role=None,
        point_side=None,
        debug=True,
    ):
        """
        Versión v9.

        SEPARACIÓN EXPLÍCITA DE YAW y ROLL DE SECCIÓN TRANSVERSAL:
        ────────────────────────────────────────────────────────────
        En v8 el ángulo del grupo XY adyacente se usaba como YAW para los
        segmentos XZ/YZ, lo que provocaba que line_2 y line_3 viajaran en el
        plano equivocado (su eje de pitch quedaba rotado 45° mal).

        Solución v9: dos tablas independientes.

        ① effective_yaw[i]
           · Grupo XY  → propio angulo_xy (con herencia delta_z interna).
           · Grupo XZ/YZ → propio angulo_xy de CADA segmento (0° en el
             ejemplo: line_1/2/3 viajan en el plano XZ).
           Se usa exclusivamente para la rotación de YAW (alrededor de Z)
           y para el eje del PITCH.

        ② adjacent_xy_roll[i]
           · Grupo XY  → 0°.
           · Grupo XZ/YZ → angulo_xy del primer segmento del grupo XY
             siguiente (forward) o del último del grupo XY anterior
             (backward).  0° si no hay grupo XY adyacente.
           Se suma al roll total para orientar la sección transversal
           en la dirección del conducto XY al que se conecta.

        Roll total = angulo_rotacion + extra_roll_by_view + adjacent_xy_roll
                                        (90° si XZ/YZ)

        Ejemplo con los segmentos del documento:
          line_1 (XZ, Δz=0)    → yaw=0°   | roll=0+90+45=135° | pitch=0°
          line_2 (XZ, Δz≠0)    → yaw=0°   | roll=0+90+45=135° | pitch=45°
          line_3 (XZ, vertical) → yaw=0°   | roll=0+90+45=135° | pitch=90°
          line_4 (XY, 45°)      → yaw=45°  | roll=0            | pitch=0°
          line_5 (XY, 90°)      → yaw=90°  | roll=0            | pitch=0°
          line_6 (XY, 180°)     → yaw=180° | roll=0            | pitch=0°
        """
        elementos_transformados = []
        last_real_end_point = None
        last_segment = None

        def get_dot_product(v1, v2):
            if not v1 or not v2:
                return 1.0
            return v1.X * v2.X + v1.Y * v2.Y + v1.Z * v2.Z

        def same_direction(seg1, seg2, tol_deg=1):
            if not seg1 or not seg2:
                return False
            diff = abs((seg1.data.angulo_xy - seg2.data.angulo_xy + 180) % 360 - 180)
            return diff < tol_deg

        CONDUCTO_WIDTH = conducto_width
        TIPOS_ACCESORIOS = ["manguito", "codo_45", "codo_90", "conexion", "difusor"]
        UMBRAL_Z = 0.1  # mm

        if debug:
            print(f"\n{'#'*70}")
            print(f"# PROCESANDO DATA LIST: {len(data_list)}")
            print(f"{'#'*70}")

        # =========================================================================
        # PRE-PROCESADO PASO 1: recopilar view_mode y angulo_xy por segmento
        # =========================================================================
        seg_view_modes = []
        seg_angulo_xy = []
        for item in data_list:
            seg = item.get("segment")
            if seg:
                seg_view_modes.append(getattr(seg, "view_mode", "XY"))
                seg_angulo_xy.append(getattr(seg.data, "angulo_xy", 0.0))
            else:
                seg_view_modes.append("XY")
                seg_angulo_xy.append(0.0)

        # =========================================================================
        # PRE-PROCESADO PASO 2: detectar grupos por view_mode
        # =========================================================================
        grupos = []
        if data_list:
            vm_actual = seg_view_modes[0]
            idx_inicio = 0
            for idx in range(1, len(data_list)):
                if seg_view_modes[idx] != vm_actual:
                    grupos.append((vm_actual, list(range(idx_inicio, idx))))
                    vm_actual = seg_view_modes[idx]
                    idx_inicio = idx
            grupos.append((vm_actual, list(range(idx_inicio, len(data_list)))))

        if debug:
            print(f"\n--- Grupos detectados por view_mode ---")
            for g_vm, g_idx in grupos:
                names = [
                    getattr(data_list[k].get("segment"), "name", f"Seg_{k}")
                    for k in g_idx
                    if data_list[k].get("segment")
                ]
                print(f"  {g_vm}: indices={g_idx} → {names}")
            print()

        # =========================================================================
        # PRE-PROCESADO PASO 3: effective_yaw  (solo para la rotación de viaje)
        #
        # · Grupo XY  → propio angulo_xy con herencia delta_z interna.
        # · Grupo XZ/YZ → propio angulo_xy de CADA segmento individual.
        #   (NO hereda del grupo XY adyacente — eso va en adjacent_xy_roll)
        # =========================================================================
        effective_yaw = [0.0] * len(data_list)

        for g_vm, g_idx in grupos:
            if g_vm == "XY":
                # Herencia delta_z dentro del grupo XY
                last_xy_angle = None
                for k in g_idx:
                    seg = data_list[k].get("segment")
                    if not seg:
                        effective_yaw[k] = (
                            last_xy_angle if last_xy_angle is not None else 0.0
                        )
                        continue
                    dz = abs(getattr(seg.data, "delta_z", 0.0))
                    if dz < UMBRAL_Z:
                        last_xy_angle = getattr(seg.data, "angulo_xy", 0.0)
                        effective_yaw[k] = last_xy_angle
                    else:
                        effective_yaw[k] = (
                            last_xy_angle if last_xy_angle is not None else 0.0
                        )
            else:
                # XZ / YZ: cada segmento usa su propio angulo_xy
                for k in g_idx:
                    seg = data_list[k].get("segment")
                    effective_yaw[k] = (
                        getattr(seg.data, "angulo_xy", 0.0) if seg else 0.0
                    )

        # =========================================================================
        # PRE-PROCESADO PASO 4: adjacent_xy_roll
        #
        # Para grupos XZ/YZ: ángulo del primer segmento XY adyacente.
        # Se aplica como ROLL adicional para orientar la sección transversal
        # de manera que coincida con la cara del conducto XY contiguo.
        # Grupos XY → 0° (no necesitan corrección).
        # =========================================================================
        adjacent_xy_roll = [0.0] * len(data_list)

        for g_num, (g_vm, g_idx) in enumerate(grupos):
            if g_vm == "XY":
                continue  # grupos XY no necesitan roll adicional

            ref_angle = None

            # Buscar hacia adelante: primer grupo XY posterior
            for g2_vm, g2_idx in grupos[g_num + 1 :]:
                if g2_vm == "XY" and g2_idx:
                    ref_angle = seg_angulo_xy[g2_idx[0]]
                    if debug:
                        ref_name = getattr(
                            data_list[g2_idx[0]].get("segment"),
                            "name",
                            f"Seg_{g2_idx[0]}",
                        )
                        print(
                            f"  Grupo {g_vm} {g_idx}: adjacent_xy_roll FORWARD → "
                            f"{ref_name} angulo_xy={ref_angle:.2f}°"
                        )
                    break

            # Si no hay XY adelante, buscar hacia atrás
            if ref_angle is None:
                for g2_vm, g2_idx in reversed(grupos[:g_num]):
                    if g2_vm == "XY" and g2_idx:
                        ref_angle = seg_angulo_xy[g2_idx[-1]]
                        if debug:
                            ref_name = getattr(
                                data_list[g2_idx[-1]].get("segment"),
                                "name",
                                f"Seg_{g2_idx[-1]}",
                            )
                            print(
                                f"  Grupo {g_vm} {g_idx}: adjacent_xy_roll BACKWARD → "
                                f"{ref_name} angulo_xy={ref_angle:.2f}°"
                            )
                        break

            if ref_angle is None:
                ref_angle = 0.0
                if debug:
                    print(f"  Grupo {g_vm} {g_idx}: sin ref XY → adjacent_xy_roll=0°")

            for k in g_idx:
                adjacent_xy_roll[k] = ref_angle

        # =========================================================================
        # PRE-PROCESADO PASO 5: extra_roll_by_view  (+90° para XZ/YZ)
        # =========================================================================
        extra_roll_by_view = [
            90.0 if seg_view_modes[idx] in ("XZ", "YZ") else 0.0
            for idx in range(len(data_list))
        ]

        if debug:
            print(f"\n--- Tabla de rotaciones por segmento (v9) ---")
            print(
                f"  {'idx':<4} {'nombre':<12} {'vm':<4} {'ang_xy':>8} "
                f"{'yaw':>8} {'+view':>6} {'+adj':>6} {'roll_total':>10}"
            )
            print(f"  {'-'*70}")
            for idx, item in enumerate(data_list):
                seg = item.get("segment")
                name = getattr(seg, "name", f"Seg_{idx}") if seg else f"Item_{idx}"
                vm = seg_view_modes[idx]
                ang = seg_angulo_xy[idx]
                yaw = effective_yaw[idx]
                ev = extra_roll_by_view[idx]
                ar = adjacent_xy_roll[idx]
                seg_ar = getattr(seg.data, "angulo_rotacion", 0) if seg else 0
                total_r = seg_ar + ev + ar
                print(
                    f"  {idx:<4} {name:<12} {vm:<4} {ang:>8.2f}° "
                    f"{yaw:>8.2f}° {ev:>5.0f}° {ar:>5.0f}° {total_r:>9.1f}°"
                )
            print()
        # =========================================================================

        for i, item in enumerate(data_list):
            try:
                segment = item.get("segment")
                if not segment:
                    continue
                data = segment.data
                item_name = getattr(segment, "name", f"Segment_{i}")
                start_point = getattr(data, "start", None)
                if start_point is None:
                    continue
                tipo_str = item.get("type", "")
                is_dinamic = tipo_str not in TIPOS_ACCESORIOS

                vec_curr = getattr(data, "vector_normalizado", None)
                if vec_curr is None:
                    vec_curr = AllplanGeo.Vector3D(
                        getattr(data, "delta_x", 0),
                        getattr(data, "delta_y", 0),
                        getattr(data, "delta_z", 0),
                    )
                    vec_curr.Normalize()

                if (
                    last_real_end_point is not None
                    and last_segment is not None
                    and same_direction(last_segment, segment)
                ):
                    start_point = last_real_end_point

                extension_inicio = 0.0
                extension_final = 0.0

                # ── Extensiones en uniones (solo tubos dinámicos) ────────────────
                if is_dinamic:
                    MIN_ANGLE_RAD = 0.0175
                    MAX_ANGLE_RAD = math.pi - 0.0175

                    if i > 0:
                        prev_item = data_list[i - 1]
                        prev_tipo_s = prev_item.get("type", "")
                        prev_tipo_s = (
                            prev_tipo_s
                            if isinstance(prev_tipo_s, str)
                            else (prev_tipo_s[0] if prev_tipo_s else "")
                        )
                        if prev_tipo_s == "manguito":
                            extension_inicio = 0.0
                            if debug:
                                print(
                                    f"  {item_name} – manguito anterior → ext_inicio=0"
                                )
                        else:
                            p_data = prev_item["segment"].data
                            vec_prev = AllplanGeo.Vector3D(
                                p_data.delta_x, p_data.delta_y, p_data.delta_z
                            )
                            vec_prev.Normalize()
                            dot = max(
                                -1.0, min(1.0, get_dot_product(vec_prev, vec_curr))
                            )
                            a_rad = math.acos(dot)
                            if MIN_ANGLE_RAD < a_rad < MAX_ANGLE_RAD:
                                extension_inicio = (CONDUCTO_WIDTH / 2.0) * math.tan(
                                    a_rad / 2.0
                                )
                                if debug:
                                    print(
                                        f"  {item_name} – ext_inicio: {math.degrees(a_rad):.1f}° → {extension_inicio:.2f}mm"
                                    )

                    if i < len(data_list) - 1:
                        next_item = data_list[i + 1]
                        next_tipo_s = next_item.get("type", "")
                        next_tipo_s = (
                            next_tipo_s
                            if isinstance(next_tipo_s, str)
                            else (next_tipo_s[0] if next_tipo_s else "")
                        )
                        if next_tipo_s == "manguito":
                            extension_final = 0.0
                            if debug:
                                print(
                                    f"  {item_name} – manguito siguiente → ext_final=0"
                                )
                        else:
                            n_data = next_item["segment"].data
                            vec_next = AllplanGeo.Vector3D(
                                n_data.delta_x, n_data.delta_y, n_data.delta_z
                            )
                            vec_next.Normalize()
                            dot = max(
                                -1.0, min(1.0, get_dot_product(vec_curr, vec_next))
                            )
                            a_rad = math.acos(dot)
                            if MIN_ANGLE_RAD < a_rad < MAX_ANGLE_RAD:
                                extension_final = (CONDUCTO_WIDTH / 2.0) * math.tan(
                                    a_rad / 2.0
                                )
                                if debug:
                                    print(
                                        f"  {item_name} – ext_final: {math.degrees(a_rad):.1f}° → {extension_final:.2f}mm"
                                    )

                longitud_original = getattr(data, "longitud_3d", 0.0)
                longitud_total = longitud_original + extension_inicio + extension_final

                if debug and is_dinamic:
                    print(f"\n{item_name}")
                    print(
                        f"  long_orig={longitud_original:.2f} | ext_i={extension_inicio:.2f} | "
                        f"ext_f={extension_final:.2f} | total={longitud_total:.2f}"
                    )

                list_elem_3d = item.get("element3d", [])
                lista_elem_3d_modified = []
                if is_dinamic:
                    for elem in list_elem_3d:
                        lista_elem_3d_modified.append(
                            self.modificar_dimensiones_brep(elem, longitud_total)
                        )
                else:
                    lista_elem_3d_modified = list_elem_3d

                segment_brep = None
                for e, elem_3d in enumerate(lista_elem_3d_modified):
                    prop = elem_3d.GetCommonProperties()
                    if is_dinamic and color:
                        prop.Color = color

                    brep = elem_3d.GetGeometryObject()
                    _, verts = brep.GetVertices()

                    # Punto medio geométrico
                    pmx = (start_point.X + data.end.X) / 2.0
                    pmy = (start_point.Y + data.end.Y) / 2.0
                    pmz = (start_point.Z + data.end.Z) / 2.0
                    if verts:
                        pmx = sum(v.X for v in verts) / len(verts)
                        pmy = sum(v.Y for v in verts) / len(verts)
                        pmz = sum(v.Z for v in verts) / len(verts)

                    nuevo_brep = None

                    # ──────────────────────────────────────────────────────────
                    # CASO 1 – MANGUITO
                    # ──────────────────────────────────────────────────────────
                    if tipo_str == "manguito":
                        segment_brep = None
                        if e == 0:
                            _, vp = brep.GetVertices()
                            if vp:
                                cx = sum(v.X for v in vp) / len(vp)
                                cy = sum(v.Y for v in vp) / len(vp)
                                cz = sum(v.Z for v in vp) / len(vp)
                            else:
                                cx, cy, cz = pmx, pmy, pmz
                            if not hasattr(self, "_temp_manguito_center"):
                                self._temp_manguito_center = {}
                            self._temp_manguito_center[i] = (cx, cy, cz)
                        else:
                            cx, cy, cz = self._temp_manguito_center.get(i, (0, 0, 0))

                        brep = AllplanGeo.Move(
                            brep,
                            AllplanGeo.Vector3D(
                                -cx + (longitud_original / 2.0), -cy, -cz
                            ),
                        )

                        rot_xy = effective_yaw[i]
                        rot_pitch = math.degrees(
                            math.atan2(data.delta_z, getattr(data, "longitud_xy", 0))
                        )
                        total_roll_m = (
                            getattr(data, "angulo_rotacion", 0)
                            + extra_roll_by_view[i]
                            + adjacent_xy_roll[i]
                        )

                        if debug:
                            print(
                                f"  {item_name} [manguito] "
                                f"vm={seg_view_modes[i]} | yaw={rot_xy:.2f}° | "
                                f"pitch={rot_pitch:.2f}° | roll_total={total_roll_m:.1f}°"
                            )

                        # 1) Roll total alrededor del eje X local (antes del yaw)
                        if abs(total_roll_m) > 0.001:
                            m = AllplanGeo.Matrix3D()
                            m.Rotation(
                                AllplanGeo.Line3D(0, 0, 0, 1, 0, 0),
                                AllplanGeo.Angle.FromDeg(total_roll_m),
                            )
                            brep = AllplanGeo.Transform(brep, m)

                        # 2) Yaw alrededor de Z
                        m = AllplanGeo.Matrix3D()
                        m.Rotation(
                            AllplanGeo.Line3D(0, 0, 0, 0, 0, 1),
                            AllplanGeo.Angle.FromDeg(rot_xy),
                        )
                        brep = AllplanGeo.Transform(brep, m)

                        # 3) Pitch
                        if abs(rot_pitch) > 0.1:
                            rad_xy = math.radians(rot_xy)
                            axis = AllplanGeo.Line3D(
                                0, 0, 0, math.sin(rad_xy), -math.cos(rad_xy), 0
                            )
                            m = AllplanGeo.Matrix3D()
                            m.Rotation(axis, AllplanGeo.Angle.FromDeg(rot_pitch))
                            brep = AllplanGeo.Transform(brep, m)

                        nuevo_brep = AllplanGeo.Move(
                            brep,
                            AllplanGeo.Vector3D(
                                (start_point.X + data.end.X) / 2.0,
                                (start_point.Y + data.end.Y) / 2.0,
                                (start_point.Z + data.end.Z) / 2.0,
                            ),
                        )
                        elementos_transformados.append(
                            {
                                "index": i,
                                "element_type": tipo_str,
                                "element": AllplanBasisElements.ModelElement3D(
                                    prop, nuevo_brep
                                ),
                            }
                        )

                    # ──────────────────────────────────────────────────────────
                    # CASO 2 – DIFUSOR
                    # ──────────────────────────────────────────────────────────
                    elif tipo_str == "difusor":
                        move_offset = 0
                        if point_side == 0:
                            move_offset = CONDUCTO_WIDTH / 2
                        elif point_side == 2:
                            move_offset = -CONDUCTO_WIDTH / 2
                        ang_int = int(data.angulo_xy)

                        if debug:
                            print(
                                f"  start_point: ({start_point.X:.1f}, {start_point.Y:.1f}, {start_point.Z:.1f})"
                            )

                        if point_role == "inicial":
                            punto_inicio_real = start_point
                            for j in range(i + 1, len(data_list)):
                                ni = data_list[j]
                                nt_s = ni.get("type", "")
                                nt_s = (
                                    nt_s
                                    if isinstance(nt_s, str)
                                    else (nt_s[0] if nt_s else "")
                                )
                                if nt_s not in TIPOS_ACCESORIOS:
                                    punto_inicio_real = getattr(
                                        ni["segment"].data, "start", start_point
                                    )
                                    break
                            _, vd = brep.GetVertices()
                            if vd:
                                brep = AllplanGeo.Move(
                                    brep,
                                    AllplanGeo.Vector3D(
                                        -sum(v.X for v in vd) / len(vd),
                                        -sum(v.Y for v in vd) / len(vd),
                                        -sum(v.Z for v in vd) / len(vd),
                                    ),
                                )
                            if ang_int != 0:
                                mr = AllplanGeo.Matrix3D()
                                mr.Rotation(
                                    AllplanGeo.Line3D(0, 0, 0, 0, 0, 1),
                                    AllplanGeo.Angle.FromDeg(data.angulo_xy),
                                )
                                brep = AllplanGeo.Transform(brep, mr)
                            w_cubo = -60 if ang_int in [0, 90, 89] else 60
                            offset_x = punto_inicio_real.X + w_cubo
                            offset_y = punto_inicio_real.Y + (
                                move_offset if ang_int in [0, 180, 178, 179] else w_cubo
                            )
                            nuevo_brep = AllplanGeo.Move(
                                brep,
                                AllplanGeo.Vector3D(
                                    offset_x, offset_y - 1, punto_inicio_real.Z + 11
                                ),
                            )

                        elif point_role == "final":
                            punto_final_real = getattr(
                                data,
                                "end",
                                AllplanGeo.Point3D(
                                    start_point.X + data.delta_x,
                                    start_point.Y + data.delta_y,
                                    start_point.Z + data.delta_z,
                                ),
                            )
                            if i < len(data_list) - 1:
                                for j in range(len(data_list) - 1, i, -1):
                                    ni = data_list[j]
                                    nt_s = ni.get("type", "")
                                    nt_s = (
                                        nt_s
                                        if isinstance(nt_s, str)
                                        else (nt_s[0] if nt_s else "")
                                    )
                                    if nt_s not in TIPOS_ACCESORIOS:
                                        punto_final_real = getattr(
                                            ni["segment"].data, "end", punto_final_real
                                        )
                                        break
                            cdz = 0
                            _, vd = brep.GetVertices()
                            if vd:
                                cdz = sum(v.Z for v in vd) / len(vd)
                                brep = AllplanGeo.Move(
                                    brep,
                                    AllplanGeo.Vector3D(
                                        -sum(v.X for v in vd) / len(vd),
                                        -sum(v.Y for v in vd) / len(vd),
                                        -cdz,
                                    ),
                                )
                            rot_diff = (
                                180
                                if ang_int == 0
                                else (
                                    0
                                    if ang_int in [180, 179, 178]
                                    else (
                                        -data.angulo_xy
                                        if ang_int in [-90, 89, 90, -89]
                                        else 0
                                    )
                                )
                            )
                            mr = AllplanGeo.Matrix3D()
                            mr.Rotation(
                                AllplanGeo.Line3D(0, 0, 0, 0, 0, 1),
                                AllplanGeo.Angle.FromDeg(rot_diff),
                            )
                            brep = AllplanGeo.Transform(brep, mr)
                            padding = 60
                            ltc = AllplanGeo.CalcLength(
                                AllplanGeo.Line3D(
                                    (
                                        data_list[0]["segment"].data.start
                                        if data_list[0].get("type", "")
                                        not in TIPOS_ACCESORIOS
                                        else start_point
                                    ),
                                    punto_final_real,
                                )
                            )
                            if ang_int in [0, 180, 179, 178]:
                                factor = -1 if ang_int in [180, 179, 178] else 1
                                nuevo_brep = AllplanGeo.Move(
                                    brep,
                                    AllplanGeo.Vector3D(
                                        punto_final_real.X + (padding * factor),
                                        punto_final_real.Y + move_offset,
                                        punto_final_real.Z - cdz + 11,
                                    ),
                                )
                            else:
                                factor = -1 if ang_int in [-90, -89] else 1
                                nuevo_brep = AllplanGeo.Move(
                                    brep,
                                    AllplanGeo.Vector3D(
                                        punto_final_real.X + move_offset,
                                        punto_final_real.Y + (padding * factor),
                                        punto_final_real.Z - cdz + 11,
                                    ),
                                )
                        else:
                            nuevo_brep = AllplanGeo.Move(
                                brep, AllplanGeo.Vector3D(pmx, pmy, pmz)
                            )

                        elementos_transformados.append(
                            {
                                "index": i,
                                "element_type": tipo_str,
                                "element": AllplanBasisElements.ModelElement3D(
                                    prop, nuevo_brep
                                ),
                            }
                        )

                    # ──────────────────────────────────────────────────────────
                    # CASO 3 – TUBOS DINÁMICOS
                    # ──────────────────────────────────────────────────────────
                    else:
                        nx = sum(v.X for v in verts) / len(verts) if verts else 0
                        ny = sum(v.Y for v in verts) / len(verts) if verts else 0
                        nz = sum(v.Z for v in verts) / len(verts) if verts else 0
                        brep = AllplanGeo.Move(brep, AllplanGeo.Vector3D(-nx, -ny, -nz))

                        # Ángulos para este segmento
                        rot_xy = effective_yaw[i]  # YAW: dirección de viaje
                        long_xy_seg = getattr(data, "longitud_xy", 0.0)
                        rot_pitch = math.degrees(math.atan2(data.delta_z, long_xy_seg))

                        # Roll total = angulo_rotacion + 90°(si XZ/YZ) + ángulo_XY_adyacente
                        total_roll_t = (
                            getattr(data, "angulo_rotacion", 0)
                            + extra_roll_by_view[i]
                            + adjacent_xy_roll[i]
                        )

                        if debug:
                            print(
                                f"  {item_name} [vm={seg_view_modes[i]}] "
                                f"ang_xy_propio={seg_angulo_xy[i]:.2f}° | "
                                f"yaw={rot_xy:.2f}° | pitch={rot_pitch:.2f}° | "
                                f"roll_total={total_roll_t:.1f}° "
                                f"(ar={getattr(data,'angulo_rotacion',0):.0f}° "
                                f"+view={extra_roll_by_view[i]:.0f}° "
                                f"+adj={adjacent_xy_roll[i]:.0f}°)"
                            )

                        # 1) Roll total alrededor del eje X local (BREP aún a lo largo de X)
                        if abs(total_roll_t) > 0.001:
                            m = AllplanGeo.Matrix3D()
                            m.Rotation(
                                AllplanGeo.Line3D(0, 0, 0, 1, 0, 0),
                                AllplanGeo.Angle.FromDeg(total_roll_t),
                            )
                            brep = AllplanGeo.Transform(brep, m)

                        # 2) Yaw alrededor de Z (dirección horizontal de viaje)
                        m = AllplanGeo.Matrix3D()
                        m.Rotation(
                            AllplanGeo.Line3D(0, 0, 0, 0, 0, 1),
                            AllplanGeo.Angle.FromDeg(rot_xy),
                        )
                        brep = AllplanGeo.Transform(brep, m)

                        # 3) Pitch: inclinación en el plano correcto según yaw
                        if abs(rot_pitch) > 0.001:
                            rad_xy = math.radians(rot_xy)
                            axis = AllplanGeo.Line3D(
                                0, 0, 0, math.sin(rad_xy), -math.cos(rad_xy), 0
                            )
                            m = AllplanGeo.Matrix3D()
                            m.Rotation(axis, AllplanGeo.Angle.FromDeg(rot_pitch))
                            brep = AllplanGeo.Transform(brep, m)

                        # Centro ajustado por extensiones
                        desplazamiento_neto = (
                            longitud_original / 2.0
                            + (extension_final - extension_inicio) / 2.0
                        )
                        mid_x = start_point.X + vec_curr.X * desplazamiento_neto
                        mid_y = start_point.Y + vec_curr.Y * desplazamiento_neto
                        mid_z = start_point.Z + vec_curr.Z * desplazamiento_neto

                        nuevo_brep = AllplanGeo.Move(
                            brep, AllplanGeo.Vector3D(mid_x, mid_y, mid_z)
                        )
                        segment_brep = {
                            "index": i,
                            "element_type": tipo_str,
                            "element": AllplanBasisElements.ModelElement3D(
                                prop, nuevo_brep
                            ),
                        }
                        elementos_transformados.append(segment_brep)

            except Exception as ex:
                if debug:
                    print(f"ERROR CRÍTICO en elemento {i} ({tipo_str}): {ex}")

        if debug:
            print(f"\n{'='*70}")
            print(f"COMPLETADO: {len(elementos_transformados)} elementos procesados")
            print(f"{'='*70}\n")

        return elementos_transformados

    # -- funciona bastante bien --
    def center_and_connect_models_v8(
        self,
        data_list,
        conducto_width=75,
        color=None,
        point_role=None,
        point_side=None,
        debug=True,
    ):
        """
        Versión v8.

        REGLA DE ROTACIÓN — effective_rot_xy por agrupación de view_mode:
        ─────────────────────────────────────────────────────────────────
        1. Se detectan grupos de segmentos consecutivos con el mismo view_mode.
        2. Los grupos XY usan su propio angulo_xy (con la herencia delta_z
           ya existente para segmentos inclinados dentro del grupo XY).
        3. Los grupos XZ/YZ usan el angulo_xy del PRIMER segmento XY
           en la transición adyacente:
             · XZ/YZ → XY : primer segmento del grupo XY siguiente
             · XY   → XZ/YZ : último segmento del grupo XY anterior
           Fallback: si no hay XY en ninguno de los dos lados → 0°.

        Ejemplo con los segmentos del documento:
          line_1 (XZ) ┐
          line_2 (XZ) ├─ grupo XZ → ref = line_4.angulo_xy = 45°
          line_3 (XZ) ┘
          line_4 (XY) ┐
          line_5 (XY) ├─ grupo XY → usan su propio angulo_xy
          line_6 (XY) ┘

        EXTRA ROLL — compensación de view_mode:
        ────────────────────────────────────────
        El BREP está modelado para viajar en el plano XY.
        Los segmentos XZ/YZ reciben +90° de roll alrededor del eje de
        viaje (antes del yaw) para corregir la sección transversal.
        Funciona en ambas direcciones: XY→XZ/YZ y XZ/YZ→XY.
        """
        elementos_transformados = []
        last_real_end_point = None
        last_segment = None

        def get_dot_product(v1, v2):
            if not v1 or not v2:
                return 1.0
            return v1.X * v2.X + v1.Y * v2.Y + v1.Z * v2.Z

        def same_direction(seg1, seg2, tol_deg=1):
            if not seg1 or not seg2:
                return False
            diff = abs((seg1.data.angulo_xy - seg2.data.angulo_xy + 180) % 360 - 180)
            return diff < tol_deg

        CONDUCTO_WIDTH = conducto_width
        TIPOS_ACCESORIOS = ["manguito", "codo_45", "codo_90", "conexion", "difusor"]
        UMBRAL_Z = 0.1  # mm – por debajo se considera "sin componente Z" (XY puro)

        if debug:
            print(f"\n{'#'*70}")
            print(f"# PROCESANDO DATA LIST: {len(data_list)}")
            print(f"{'#'*70}")

        # =========================================================================
        # PRE-PROCESADO PASO 1: recopilar view_mode y angulo_xy por segmento
        # =========================================================================
        seg_view_modes = []
        seg_angulo_xy = []
        for item in data_list:
            seg = item.get("segment")
            if seg:
                seg_view_modes.append(getattr(seg, "view_mode", "XY"))
                seg_angulo_xy.append(getattr(seg.data, "angulo_xy", 0.0))
            else:
                seg_view_modes.append("XY")
                seg_angulo_xy.append(0.0)

        # =========================================================================
        # PRE-PROCESADO PASO 2: detectar grupos por view_mode
        #
        # Genera lista de grupos: [(view_mode, [indices]), ...]
        # =========================================================================
        grupos = []
        if data_list:
            vm_actual = seg_view_modes[0]
            idx_inicio = 0
            for idx in range(1, len(data_list)):
                if seg_view_modes[idx] != vm_actual:
                    grupos.append((vm_actual, list(range(idx_inicio, idx))))
                    vm_actual = seg_view_modes[idx]
                    idx_inicio = idx
            grupos.append((vm_actual, list(range(idx_inicio, len(data_list)))))

        if debug:
            print(f"\n--- Grupos detectados por view_mode ---")
            for g_vm, g_idx in grupos:
                names = [
                    getattr(data_list[k].get("segment"), "name", f"Seg_{k}")
                    for k in g_idx
                    if data_list[k].get("segment")
                ]
                print(f"  {g_vm}: indices={g_idx} → {names}")
            print()

        # =========================================================================
        # PRE-PROCESADO PASO 3: effective_rot_xy
        #
        # · Grupos XY  → cada segmento usa su propio angulo_xy.
        #                Los segmentos con delta_z != 0 DENTRO del grupo XY
        #                heredan del último segmento XY puro del mismo grupo.
        # · Grupos XZ/YZ → todos los segmentos del grupo usan el angulo_xy
        #                  del primer segmento XY en la transición adyacente:
        #                  primero busca hacia adelante (grupo XY siguiente),
        #                  si no existe busca hacia atrás (grupo XY anterior).
        # =========================================================================
        effective_rot_xy = [0.0] * len(data_list)

        for g_num, (g_vm, g_idx) in enumerate(grupos):

            if g_vm == "XY":
                # Herencia delta_z dentro del grupo XY
                last_xy_angle = None
                for k in g_idx:
                    seg = data_list[k].get("segment")
                    if not seg:
                        effective_rot_xy[k] = (
                            last_xy_angle if last_xy_angle is not None else 0.0
                        )
                        continue
                    dz = abs(getattr(seg.data, "delta_z", 0.0))
                    if dz < UMBRAL_Z:
                        last_xy_angle = getattr(seg.data, "angulo_xy", 0.0)
                        effective_rot_xy[k] = last_xy_angle
                    else:
                        # segmento inclinado dentro del grupo XY → hereda
                        effective_rot_xy[k] = (
                            last_xy_angle if last_xy_angle is not None else 0.0
                        )

            else:
                # Grupo XZ o YZ → buscar referencia en grupos XY adyacentes
                ref_angle = None

                # Buscar hacia adelante: primer grupo XY posterior
                for g2_vm, g2_idx in grupos[g_num + 1 :]:
                    if g2_vm == "XY" and g2_idx:
                        first_xy_idx = g2_idx[0]
                        ref_angle = seg_angulo_xy[first_xy_idx]
                        if debug:
                            ref_name = getattr(
                                data_list[first_xy_idx].get("segment"),
                                "name",
                                f"Seg_{first_xy_idx}",
                            )
                            print(
                                f"  Grupo {g_vm} {g_idx}: ref FORWARD → "
                                f"{ref_name} angulo_xy={ref_angle:.2f}°"
                            )
                        break

                # Si no hay XY adelante, buscar hacia atrás
                if ref_angle is None:
                    for g2_vm, g2_idx in reversed(grupos[:g_num]):
                        if g2_vm == "XY" and g2_idx:
                            last_xy_idx = g2_idx[-1]
                            ref_angle = seg_angulo_xy[last_xy_idx]
                            if debug:
                                ref_name = getattr(
                                    data_list[last_xy_idx].get("segment"),
                                    "name",
                                    f"Seg_{last_xy_idx}",
                                )
                                print(
                                    f"  Grupo {g_vm} {g_idx}: ref BACKWARD → "
                                    f"{ref_name} angulo_xy={ref_angle:.2f}°"
                                )
                            break

                if ref_angle is None:
                    ref_angle = 0.0
                    if debug:
                        print(f"  Grupo {g_vm} {g_idx}: sin ref XY → fallback 0°")

                for k in g_idx:
                    effective_rot_xy[k] = ref_angle

        if debug:
            print(f"\n--- effective_rot_xy (v8: agrupación por view_mode) ---")
            for idx, item in enumerate(data_list):
                seg = item.get("segment")
                name = getattr(seg, "name", f"Seg_{idx}") if seg else f"Item_{idx}"
                tipo = item.get("type", "")
                vm = seg_view_modes[idx]
                print(
                    f"  [{idx}] {name} ({tipo or 'tubo'}) | view_mode={vm} | "
                    f"angulo_xy_propio={seg_angulo_xy[idx]:.2f}° → "
                    f"effective={effective_rot_xy[idx]:.2f}°"
                )
            print()
        # =========================================================================

        # =========================================================================
        # PRE-PROCESADO PASO 4: extra_roll_by_view
        #
        # El BREP está modelado para el plano XY. Los segmentos XZ/YZ necesitan
        # +90° de roll alrededor del eje de viaje para corregir la sección.
        # =========================================================================
        extra_roll_by_view = [
            90.0 if seg_view_modes[idx] in ("XZ", "YZ") else 0.0
            for idx in range(len(data_list))
        ]

        if debug:
            print(f"--- extra_roll_by_view (XZ/YZ → +90°, XY → 0°) ---")
            for idx, item in enumerate(data_list):
                seg = item.get("segment")
                if seg:
                    name = getattr(seg, "name", f"Seg_{idx}")
                    print(
                        f"  [{idx}] {name} | view_mode={seg_view_modes[idx]} "
                        f"→ extra_roll={extra_roll_by_view[idx]:.0f}°"
                    )
            print()
        # =========================================================================
        OVERLAP_SEGURIDAD = 0  # 2mm de solape extra para asegurar contacto

        for i, item in enumerate(data_list):
            try:
                segment = item.get("segment")
                if not segment:
                    continue
                data = segment.data
                item_name = getattr(segment, "name", f"Segment_{i}")
                start_point = getattr(data, "start", None)
                if start_point is None:
                    continue
                tipo_str = item.get("type", "")
                is_dinamic = tipo_str not in TIPOS_ACCESORIOS

                vec_curr = getattr(data, "vector_normalizado", None)
                if vec_curr is None:
                    vec_curr = AllplanGeo.Vector3D(
                        getattr(data, "delta_x", 0),
                        getattr(data, "delta_y", 0),
                        getattr(data, "delta_z", 0),
                    )
                    vec_curr.Normalize()

                if (
                    last_real_end_point is not None
                    and last_segment is not None
                    and same_direction(last_segment, segment)
                ):
                    start_point = last_real_end_point

                extension_inicio = 0.0
                extension_final = 0.0

                # ── Extensiones en uniones (solo tubos dinámicos) ────────────────
                if is_dinamic:
                    vec_curr = data.vector_normalizado
                    SAFE_MAX_ANGLE = math.radians(175.0)

                    # Tolerancia para detectar 135° (por si hay decimales como 134.99)
                    ANGULO_ESPECIAL_RAD = math.radians(135.0)
                    TOLERANCIA = math.radians(1.0)

                    # 1. Extensión al INICIO
                    extension_inicio = 0.0
                    if i > 0:
                        prev_item = data_list[i - 1]
                        if prev_item.get("type") != "manguito":
                            vec_prev = prev_item["segment"].data.vector_normalizado
                            dot = max(
                                -1.0, min(1.0, get_dot_product(vec_prev, vec_curr))
                            )
                            a_rad = math.acos(dot)

                            if 0.0001 < a_rad < SAFE_MAX_ANGLE:
                                # --- IF DISTINTO PARA 135° ---
                                if abs(a_rad - ANGULO_ESPECIAL_RAD) < TOLERANCIA:
                                    # En el inicio del segundo segmento del codo, recortamos
                                    extension_inicio = -15.4
                                    if debug:
                                        print(
                                            f"  {item_name} - Inicio: Detectado 135°, aplicando recorte -22.5"
                                        )
                                else:
                                    # Lógica inicial (Tangente)
                                    extension_teorica = (
                                        CONDUCTO_WIDTH / 2.0
                                    ) * math.tan(a_rad / 2.0)
                                    extension_inicio = (
                                        extension_teorica + OVERLAP_SEGURIDAD
                                    )

                    # 2. Extensión al FINAL
                    extension_final = 0.0
                    if i < len(data_list) - 1:
                        next_item = data_list[i + 1]
                        if next_item.get("type") != "manguito":
                            vec_next = next_item["segment"].data.vector_normalizado
                            dot = max(
                                -1.0, min(1.0, get_dot_product(vec_curr, vec_next))
                            )
                            a_rad = math.acos(dot)

                            if 0.0001 < a_rad < SAFE_MAX_ANGLE:
                                # --- IF DISTINTO PARA 135° ---
                                if abs(a_rad - ANGULO_ESPECIAL_RAD) < TOLERANCIA:
                                    # En el final del primer segmento del codo, alargamos
                                    extension_final = 15.4
                                    if debug:
                                        print(
                                            f"  {item_name} - Final: Detectado 135°, aplicando alargue 22.5"
                                        )
                                else:
                                    # Lógica inicial (Tangente)
                                    extension_teorica = (
                                        CONDUCTO_WIDTH / 2.0
                                    ) * math.tan(a_rad / 2.0)
                                    extension_final = (
                                        extension_teorica + OVERLAP_SEGURIDAD
                                    )

                    # 3. Aplicación de longitud
                    longitud_original = getattr(data, "longitud_3d", 0.0)
                    longitud_total = (
                        longitud_original + extension_inicio + extension_final
                    )

                if debug and is_dinamic:
                    print(f"\n{item_name}")
                    print(
                        f"  long_orig={longitud_original:.2f} | ext_i={extension_inicio:.2f} | "
                        f"ext_f={extension_final:.2f} | total={longitud_total:.2f}"
                    )

                list_elem_3d = item.get("element3d", [])
                lista_elem_3d_modified = []
                if is_dinamic:
                    for elem in list_elem_3d:
                        lista_elem_3d_modified.append(
                            self.modificar_dimensiones_brep(elem, longitud_total)
                        )
                else:
                    lista_elem_3d_modified = list_elem_3d

                segment_brep = None
                for e, elem_3d in enumerate(lista_elem_3d_modified):
                    prop = elem_3d.GetCommonProperties()
                    if is_dinamic and color:
                        prop.Color = color

                    brep = elem_3d.GetGeometryObject()
                    _, verts = brep.GetVertices()

                    # Punto medio geométrico
                    pmx = (start_point.X + data.end.X) / 2.0
                    pmy = (start_point.Y + data.end.Y) / 2.0
                    pmz = (start_point.Z + data.end.Z) / 2.0
                    if verts:
                        pmx = sum(v.X for v in verts) / len(verts)
                        pmy = sum(v.Y for v in verts) / len(verts)
                        pmz = sum(v.Z for v in verts) / len(verts)

                    nuevo_brep = None

                    # ──────────────────────────────────────────────────────────
                    # CASO 1 – MANGUITO
                    # ──────────────────────────────────────────────────────────
                    if tipo_str == "manguito":
                        segment_brep = None
                        if e == 0:
                            _, vp = brep.GetVertices()
                            if vp:
                                cx = sum(v.X for v in vp) / len(vp)
                                cy = sum(v.Y for v in vp) / len(vp)
                                cz = sum(v.Z for v in vp) / len(vp)
                            else:
                                cx, cy, cz = pmx, pmy, pmz
                            if not hasattr(self, "_temp_manguito_center"):
                                self._temp_manguito_center = {}
                            self._temp_manguito_center[i] = (cx, cy, cz)
                        else:
                            cx, cy, cz = self._temp_manguito_center.get(i, (0, 0, 0))

                        brep = AllplanGeo.Move(
                            brep,
                            AllplanGeo.Vector3D(
                                -cx + (longitud_original / 2.0), -cy, -cz
                            ),
                        )

                        rot_xy = effective_rot_xy[i]
                        rot_pitch = math.degrees(
                            math.atan2(data.delta_z, getattr(data, "longitud_xy", 0))
                        )

                        if debug:
                            print(
                                f"  {item_name} [manguito] "
                                f"view_mode={seg_view_modes[i]} | "
                                f"rot_xy={rot_xy:.2f}° | rot_pitch={rot_pitch:.2f}° | "
                                f"extra_roll={extra_roll_by_view[i]:.0f}° | "
                                f"angulo_rotacion={getattr(data, 'angulo_rotacion', 0):.1f}°"
                            )

                        # Roll: angulo_rotacion del dato + compensación por view_mode
                        total_roll_m = (
                            getattr(data, "angulo_rotacion", 0) + extra_roll_by_view[i]
                        )
                        if abs(total_roll_m) > 0.001:
                            m = AllplanGeo.Matrix3D()
                            m.Rotation(
                                AllplanGeo.Line3D(0, 0, 0, 1, 0, 0),
                                AllplanGeo.Angle.FromDeg(total_roll_m),
                            )
                            brep = AllplanGeo.Transform(brep, m)

                        # Yaw (planta) — ángulo efectivo de grupo
                        m = AllplanGeo.Matrix3D()
                        m.Rotation(
                            AllplanGeo.Line3D(0, 0, 0, 0, 0, 1),
                            AllplanGeo.Angle.FromDeg(rot_xy),
                        )
                        brep = AllplanGeo.Transform(brep, m)

                        if abs(rot_pitch) > 0.1:
                            rad_xy = math.radians(rot_xy)
                            axis = AllplanGeo.Line3D(
                                0, 0, 0, math.sin(rad_xy), -math.cos(rad_xy), 0
                            )
                            m = AllplanGeo.Matrix3D()
                            m.Rotation(axis, AllplanGeo.Angle.FromDeg(rot_pitch))
                            brep = AllplanGeo.Transform(brep, m)

                        nuevo_brep = AllplanGeo.Move(
                            brep,
                            AllplanGeo.Vector3D(
                                (start_point.X + data.end.X) / 2.0,
                                (start_point.Y + data.end.Y) / 2.0,
                                (start_point.Z + data.end.Z) / 2.0,
                            ),
                        )
                        elementos_transformados.append(
                            {
                                "index": i,
                                "element_type": tipo_str,
                                "element": AllplanBasisElements.ModelElement3D(
                                    prop, nuevo_brep
                                ),
                            }
                        )

                    # ──────────────────────────────────────────────────────────
                    # CASO 2 – DIFUSOR
                    # ──────────────────────────────────────────────────────────
                    elif tipo_str == "difusor":
                        move_offset = 0
                        if point_side == 0:
                            move_offset = CONDUCTO_WIDTH / 2
                        elif point_side == 2:
                            move_offset = -CONDUCTO_WIDTH / 2
                        ang_int = int(data.angulo_xy)

                        if debug:
                            print(
                                f"  start_point: ({start_point.X:.1f}, {start_point.Y:.1f}, {start_point.Z:.1f})"
                            )

                        if point_role == "inicial":
                            punto_inicio_real = start_point
                            for j in range(i + 1, len(data_list)):
                                ni = data_list[j]
                                nt_s = ni.get("type", "")
                                nt_s = (
                                    nt_s
                                    if isinstance(nt_s, str)
                                    else (nt_s[0] if nt_s else "")
                                )
                                if nt_s not in TIPOS_ACCESORIOS:
                                    punto_inicio_real = getattr(
                                        ni["segment"].data, "start", start_point
                                    )
                                    break
                            _, vd = brep.GetVertices()
                            if vd:
                                brep = AllplanGeo.Move(
                                    brep,
                                    AllplanGeo.Vector3D(
                                        -sum(v.X for v in vd) / len(vd),
                                        -sum(v.Y for v in vd) / len(vd),
                                        -sum(v.Z for v in vd) / len(vd),
                                    ),
                                )
                            if ang_int != 0:
                                mr = AllplanGeo.Matrix3D()
                                mr.Rotation(
                                    AllplanGeo.Line3D(0, 0, 0, 0, 0, 1),
                                    AllplanGeo.Angle.FromDeg(data.angulo_xy),
                                )
                                brep = AllplanGeo.Transform(brep, mr)
                            w_cubo = -60 if ang_int in [0, 90, 89] else 60
                            offset_x = punto_inicio_real.X + w_cubo
                            offset_y = punto_inicio_real.Y + (
                                move_offset if ang_int in [0, 180, 178, 179] else w_cubo
                            )
                            nuevo_brep = AllplanGeo.Move(
                                brep,
                                AllplanGeo.Vector3D(
                                    offset_x, offset_y - 1, punto_inicio_real.Z + 11
                                ),
                            )

                        elif point_role == "final":
                            punto_final_real = getattr(
                                data,
                                "end",
                                AllplanGeo.Point3D(
                                    start_point.X + data.delta_x,
                                    start_point.Y + data.delta_y,
                                    start_point.Z + data.delta_z,
                                ),
                            )
                            if i < len(data_list) - 1:
                                for j in range(len(data_list) - 1, i, -1):
                                    ni = data_list[j]
                                    nt_s = ni.get("type", "")
                                    nt_s = (
                                        nt_s
                                        if isinstance(nt_s, str)
                                        else (nt_s[0] if nt_s else "")
                                    )
                                    if nt_s not in TIPOS_ACCESORIOS:
                                        punto_final_real = getattr(
                                            ni["segment"].data, "end", punto_final_real
                                        )
                                        break
                            cdz = 0
                            _, vd = brep.GetVertices()
                            if vd:
                                cdz = sum(v.Z for v in vd) / len(vd)
                                brep = AllplanGeo.Move(
                                    brep,
                                    AllplanGeo.Vector3D(
                                        -sum(v.X for v in vd) / len(vd),
                                        -sum(v.Y for v in vd) / len(vd),
                                        -cdz,
                                    ),
                                )
                            rot_diff = (
                                180
                                if ang_int == 0
                                else (
                                    0
                                    if ang_int in [180, 179, 178]
                                    else (
                                        -data.angulo_xy
                                        if ang_int in [-90, 89, 90, -89]
                                        else 0
                                    )
                                )
                            )
                            mr = AllplanGeo.Matrix3D()
                            mr.Rotation(
                                AllplanGeo.Line3D(0, 0, 0, 0, 0, 1),
                                AllplanGeo.Angle.FromDeg(rot_diff),
                            )
                            brep = AllplanGeo.Transform(brep, mr)
                            padding = 60
                            ltc = AllplanGeo.CalcLength(
                                AllplanGeo.Line3D(
                                    (
                                        data_list[0]["segment"].data.start
                                        if data_list[0].get("type", "")
                                        not in TIPOS_ACCESORIOS
                                        else start_point
                                    ),
                                    punto_final_real,
                                )
                            )
                            if ang_int in [0, 180, 179, 178]:
                                factor = -1 if ang_int in [180, 179, 178] else 1
                                nuevo_brep = AllplanGeo.Move(
                                    brep,
                                    AllplanGeo.Vector3D(
                                        punto_final_real.X + (padding * factor),
                                        punto_final_real.Y + move_offset,
                                        punto_final_real.Z - cdz + 11,
                                    ),
                                )
                            else:
                                factor = -1 if ang_int in [-90, -89] else 1
                                nuevo_brep = AllplanGeo.Move(
                                    brep,
                                    AllplanGeo.Vector3D(
                                        punto_final_real.X + move_offset,
                                        punto_final_real.Y + (padding * factor),
                                        punto_final_real.Z - cdz + 11,
                                    ),
                                )
                        else:
                            nuevo_brep = AllplanGeo.Move(
                                brep, AllplanGeo.Vector3D(pmx, pmy, pmz)
                            )

                        elementos_transformados.append(
                            {
                                "index": i,
                                "element_type": tipo_str,
                                "element": AllplanBasisElements.ModelElement3D(
                                    prop, nuevo_brep
                                ),
                            }
                        )

                    # ──────────────────────────────────────────────────────────
                    # CASO 3 – TUBOS DINÁMICOS
                    # ──────────────────────────────────────────────────────────
                    else:
                        nx = sum(v.X for v in verts) / len(verts) if verts else 0
                        ny = sum(v.Y for v in verts) / len(verts) if verts else 0
                        nz = sum(v.Z for v in verts) / len(verts) if verts else 0
                        brep = AllplanGeo.Move(brep, AllplanGeo.Vector3D(-nx, -ny, -nz))

                        # ─── ROT_XY efectivo (por grupo de view_mode) ─────────
                        rot_xy = effective_rot_xy[i]
                        long_xy_seg = getattr(data, "longitud_xy", 0.0)
                        rot_pitch = math.degrees(math.atan2(data.delta_z, long_xy_seg))

                        if debug:
                            print(
                                f"  {item_name} [view_mode={seg_view_modes[i]}] "
                                f"angulo_xy_propio={seg_angulo_xy[i]:.2f}° | "
                                f"effective_rot_xy={rot_xy:.2f}° | "
                                f"rot_pitch={rot_pitch:.2f}° | "
                                f"extra_roll={extra_roll_by_view[i]:.0f}°"
                            )

                        # Roll: angulo_rotacion del dato + compensación por view_mode
                        total_roll_t = (
                            getattr(data, "angulo_rotacion", 0) + extra_roll_by_view[i]
                        )
                        if abs(total_roll_t) > 0.001:
                            m = AllplanGeo.Matrix3D()
                            m.Rotation(
                                AllplanGeo.Line3D(0, 0, 0, 1, 0, 0),
                                AllplanGeo.Angle.FromDeg(total_roll_t),
                            )
                            brep = AllplanGeo.Transform(brep, m)

                        # Yaw (planta) — ángulo efectivo de grupo
                        m = AllplanGeo.Matrix3D()
                        m.Rotation(
                            AllplanGeo.Line3D(0, 0, 0, 0, 0, 1),
                            AllplanGeo.Angle.FromDeg(rot_xy),
                        )
                        brep = AllplanGeo.Transform(brep, m)

                        # Pitch — eje perpendicular orientado por rot_xy efectivo
                        if abs(rot_pitch) > 0.001:
                            rad_xy = math.radians(rot_xy)
                            axis = AllplanGeo.Line3D(
                                0, 0, 0, math.sin(rad_xy), -math.cos(rad_xy), 0
                            )
                            m = AllplanGeo.Matrix3D()
                            m.Rotation(axis, AllplanGeo.Angle.FromDeg(rot_pitch))
                            brep = AllplanGeo.Transform(brep, m)

                        # Centro ajustado por extensiones
                        desplazamiento_neto = (
                            longitud_original / 2.0
                            + (extension_final - extension_inicio) / 2.0
                        )
                        mid_x = start_point.X + vec_curr.X * desplazamiento_neto
                        mid_y = start_point.Y + vec_curr.Y * desplazamiento_neto
                        mid_z = start_point.Z + vec_curr.Z * desplazamiento_neto

                        nuevo_brep = AllplanGeo.Move(
                            brep, AllplanGeo.Vector3D(mid_x, mid_y, mid_z)
                        )
                        elementos_transformados.append(
                            {
                                "index": i,
                                "element_type": tipo_str,
                                "element": AllplanBasisElements.ModelElement3D(
                                    prop, nuevo_brep
                                ),
                            }
                        )

            except Exception as ex:
                if debug:
                    print(f"ERROR CRÍTICO en elemento {i} ({tipo_str}): {ex}")

        if debug:
            print(f"\n{'='*70}")
            print(f"COMPLETADO: {len(elementos_transformados)} elementos procesados")
            print(f"{'='*70}\n")

        return elementos_transformados

    def center_and_connect_models_v7(
        self,
        data_list,
        conducto_width=75,
        color=None,
        point_role=None,
        point_side=None,
        debug=True,
    ):
        """
        Versión v7.

        REGLA DE ROTACIÓN (definitiva):
        ────────────────────────────────
        La rotación XY de la sección transversal del conducto se determina por
        el ÚLTIMO segmento PURAMENTE horizontal (delta_z ≈ 0) anterior al segmento
        actual.  Cualquier segmento que tenga componente Z (vertical puro, inclinado
        XZ o YZ) HEREDA ese ángulo, sin importar su propio angulo_xy.

        Esto cubre todos los casos:
        XY(0°) → XY(-45°) → Z↓ → XZ(0°) → XY(0°)
                                ↑           ↑
                            hereda -45°   hereda -45°  ← CORREGIDO en v6

        Clasificación de cada segmento:
        "XY puro"   : abs(delta_z) < UMBRAL_Z   → usa su propio angulo_xy
        "con Z"     : abs(delta_z) >= UMBRAL_Z   → hereda del XY puro anterior
                        (incluye vertical puro Y segmentos inclinados XZ/YZ)

        Pasadas del pre-procesado:
        Forward  → propaga el último XY puro hacia adelante
        Backward → cubre verticales que aparecen antes del primer XY puro

        NUEVO en v7 — extra_roll_by_view:
        ────────────────────────────────
        El BREP de cada segmento está modelado para viajar en el plano XY.
        Cuando view_mode es 'XZ' o 'YZ', la sección transversal queda girada
        90° respecto al plano de trabajo real → se compensa con +90° de roll
        alrededor del eje de viaje (antes del yaw).
        Funciona en ambas direcciones: XY→XZ/YZ y XZ/YZ→XY.
        """
        elementos_transformados = []
        last_real_end_point = None
        last_segment = None

        def get_dot_product(v1, v2):
            if not v1 or not v2:
                return 1.0
            return v1.X * v2.X + v1.Y * v2.Y + v1.Z * v2.Z

        def same_direction(seg1, seg2, tol_deg=1):
            if not seg1 or not seg2:
                return False
            diff = abs((seg1.data.angulo_xy - seg2.data.angulo_xy + 180) % 360 - 180)
            return diff < tol_deg

        CONDUCTO_WIDTH = conducto_width
        TIPOS_ACCESORIOS = ["manguito", "codo_45", "codo_90", "conexion", "difusor"]
        UMBRAL_Z = 0.1  # mm – por debajo se considera "sin componente Z" (XY puro)

        if debug:
            print(f"\n{'#'*70}")
            print(f"# PROCESANDO DATA LIST: {len(data_list)}")
            print(f"{'#'*70}")

        # =========================================================================
        # PRE-PROCESADO: effective_rot_xy
        #
        # Criterio: un segmento "tiene XY propio" solo si abs(delta_z) < UMBRAL_Z.
        # Cualquier segmento con componente Z hereda del último XY puro.
        # =========================================================================
        raw_rot_xy = []
        for item in data_list:
            seg = item.get("segment")
            if not seg:
                raw_rot_xy.append(None)
                continue
            d = seg.data
            delta_z = abs(getattr(d, "delta_z", 0.0))

            if delta_z < UMBRAL_Z:
                # XY puro → contribuye con su propio ángulo
                raw_rot_xy.append(getattr(d, "angulo_xy", 0.0))
            else:
                # Tiene Z (vertical o inclinado) → hereda
                raw_rot_xy.append(None)

        # Forward pass: propaga el último XY puro conocido hacia adelante
        last_known = None
        for idx in range(len(raw_rot_xy)):
            if raw_rot_xy[idx] is not None:
                last_known = raw_rot_xy[idx]
            elif last_known is not None:
                raw_rot_xy[idx] = last_known

        # Backward pass: cubre None al inicio (segmentos Z antes de cualquier XY)
        last_known = None
        for idx in range(len(raw_rot_xy) - 1, -1, -1):
            if raw_rot_xy[idx] is not None:
                last_known = raw_rot_xy[idx]
            elif last_known is not None:
                raw_rot_xy[idx] = last_known

        # Fallback final
        effective_rot_xy = [v if v is not None else 0.0 for v in raw_rot_xy]

        if debug:
            print(f"\n--- effective_rot_xy (v7: hereda si delta_z != 0) ---")
            for idx, item in enumerate(data_list):
                seg = item.get("segment")
                name = getattr(seg, "name", f"Seg_{idx}") if seg else f"Item_{idx}"
                tipo = item.get("type", "")
                if seg:
                    d = seg.data
                    dz = abs(getattr(d, "delta_z", 0.0))
                    orig = getattr(d, "angulo_xy", "?")
                    long_xy = getattr(d, "longitud_xy", 0.0)
                    fuente = (
                        "XY-propio" if dz < UMBRAL_Z else f"hereda (delta_z={dz:.1f})"
                    )
                    print(
                        f"  [{idx}] {name} ({tipo or 'tubo'}) | {fuente} | "
                        f"angulo_xy={orig}° long_xy={long_xy:.1f} → effective={effective_rot_xy[idx]:.2f}°"
                    )
            print()
        # =========================================================================

        # =========================================================================
        # PRE-PROCESADO: extra_roll_by_view
        #
        # El BREP de cada segmento está modelado para viajar en el plano XY.
        # Cuando el view_mode es 'XZ' o 'YZ', la sección transversal queda
        # girada 90° respecto al plano de trabajo real → compensamos con +90° de
        # roll alrededor del eje de viaje (aplicado antes del yaw).
        #
        # Funciona en ambas direcciones:
        #   XY → XZ/YZ  y  XZ/YZ → XY
        # =========================================================================
        extra_roll_by_view = []
        for idx, item_vm in enumerate(data_list):
            seg_vm = item_vm.get("segment")
            if seg_vm:
                vm = getattr(seg_vm, "view_mode", "XY")
                extra_roll_by_view.append(90.0 if vm in ("XZ", "YZ") else 0.0)
            else:
                extra_roll_by_view.append(0.0)

        if debug:
            print(f"--- extra_roll_by_view (XZ/YZ → +90°, XY → 0°) ---")
            for idx, item_vm in enumerate(data_list):
                seg_vm = item_vm.get("segment")
                if seg_vm:
                    vm = getattr(seg_vm, "view_mode", "XY")
                    name_vm = getattr(seg_vm, "name", f"Seg_{idx}")
                    print(
                        f"  [{idx}] {name_vm} | view_mode={vm} → extra_roll={extra_roll_by_view[idx]:.0f}°"
                    )
            print()
        # =========================================================================

        for i, item in enumerate(data_list):
            try:
                segment = item.get("segment")
                if not segment:
                    continue
                data = segment.data
                item_name = getattr(segment, "name", f"Segment_{i}")
                start_point = getattr(data, "start", None)
                if start_point is None:
                    continue
                tipo_str = item.get("type", "")
                is_dinamic = tipo_str not in TIPOS_ACCESORIOS

                vec_curr = getattr(data, "vector_normalizado", None)
                if vec_curr is None:
                    vec_curr = AllplanGeo.Vector3D(
                        getattr(data, "delta_x", 0),
                        getattr(data, "delta_y", 0),
                        getattr(data, "delta_z", 0),
                    )
                    vec_curr.Normalize()

                if (
                    last_real_end_point is not None
                    and last_segment is not None
                    and same_direction(last_segment, segment)
                ):
                    start_point = last_real_end_point

                extension_inicio = 0.0
                extension_final = 0.0

                # ── Extensiones en uniones (solo tubos dinámicos) ────────────────
                if is_dinamic:
                    MIN_ANGLE_RAD = 0.0175
                    MAX_ANGLE_RAD = math.pi - 0.0175

                    if i > 0:
                        prev_item = data_list[i - 1]
                        prev_tipo_s = prev_item.get("type", "")
                        prev_tipo_s = (
                            prev_tipo_s
                            if isinstance(prev_tipo_s, str)
                            else (prev_tipo_s[0] if prev_tipo_s else "")
                        )
                        if prev_tipo_s == "manguito":
                            extension_inicio = 0.0
                            if debug:
                                print(
                                    f"  {item_name} – manguito anterior → ext_inicio=0"
                                )
                        else:
                            p_data = prev_item["segment"].data
                            vec_prev = AllplanGeo.Vector3D(
                                p_data.delta_x, p_data.delta_y, p_data.delta_z
                            )
                            vec_prev.Normalize()
                            dot = max(
                                -1.0, min(1.0, get_dot_product(vec_prev, vec_curr))
                            )
                            a_rad = math.acos(dot)
                            if MIN_ANGLE_RAD < a_rad < MAX_ANGLE_RAD:
                                extension_inicio = (CONDUCTO_WIDTH / 2.0) * math.tan(
                                    a_rad / 2.0
                                )
                                if debug:
                                    print(
                                        f"  {item_name} – ext_inicio: {math.degrees(a_rad):.1f}° → {extension_inicio:.2f}mm"
                                    )

                    if i < len(data_list) - 1:
                        next_item = data_list[i + 1]
                        next_tipo_s = next_item.get("type", "")
                        next_tipo_s = (
                            next_tipo_s
                            if isinstance(next_tipo_s, str)
                            else (next_tipo_s[0] if next_tipo_s else "")
                        )
                        if next_tipo_s == "manguito":
                            extension_final = 0.0
                            if debug:
                                print(
                                    f"  {item_name} – manguito siguiente → ext_final=0"
                                )
                        else:
                            n_data = next_item["segment"].data
                            vec_next = AllplanGeo.Vector3D(
                                n_data.delta_x, n_data.delta_y, n_data.delta_z
                            )
                            vec_next.Normalize()
                            dot = max(
                                -1.0, min(1.0, get_dot_product(vec_curr, vec_next))
                            )
                            a_rad = math.acos(dot)
                            if MIN_ANGLE_RAD < a_rad < MAX_ANGLE_RAD:
                                extension_final = (CONDUCTO_WIDTH / 2.0) * math.tan(
                                    a_rad / 2.0
                                )
                                if debug:
                                    print(
                                        f"  {item_name} – ext_final: {math.degrees(a_rad):.1f}° → {extension_final:.2f}mm"
                                    )

                longitud_original = getattr(data, "longitud_3d", 0.0)
                longitud_total = longitud_original + extension_inicio + extension_final

                if debug and is_dinamic:
                    print(f"\n{item_name}")
                    print(
                        f"  long_orig={longitud_original:.2f} | ext_i={extension_inicio:.2f} | "
                        f"ext_f={extension_final:.2f} | total={longitud_total:.2f}"
                    )

                list_elem_3d = item.get("element3d", [])
                lista_elem_3d_modified = []
                if is_dinamic:
                    for elem in list_elem_3d:
                        lista_elem_3d_modified.append(
                            self.modificar_dimensiones_brep(elem, longitud_total)
                        )
                else:
                    lista_elem_3d_modified = list_elem_3d

                segment_brep = None
                for e, elem_3d in enumerate(lista_elem_3d_modified):
                    prop = elem_3d.GetCommonProperties()
                    if is_dinamic and color:
                        prop.Color = color

                    brep = elem_3d.GetGeometryObject()
                    _, verts = brep.GetVertices()

                    # Punto medio geométrico
                    pmx = (start_point.X + data.end.X) / 2.0
                    pmy = (start_point.Y + data.end.Y) / 2.0
                    pmz = (start_point.Z + data.end.Z) / 2.0
                    if verts:
                        pmx = sum(v.X for v in verts) / len(verts)
                        pmy = sum(v.Y for v in verts) / len(verts)
                        pmz = sum(v.Z for v in verts) / len(verts)

                    nuevo_brep = None

                    # ──────────────────────────────────────────────────────────
                    # CASO 1 – MANGUITO
                    # ──────────────────────────────────────────────────────────
                    if tipo_str == "manguito":
                        segment_brep = None
                        if e == 0:
                            _, vp = brep.GetVertices()
                            if vp:
                                cx = sum(v.X for v in vp) / len(vp)
                                cy = sum(v.Y for v in vp) / len(vp)
                                cz = sum(v.Z for v in vp) / len(vp)
                            else:
                                cx, cy, cz = pmx, pmy, pmz
                            if not hasattr(self, "_temp_manguito_center"):
                                self._temp_manguito_center = {}
                            self._temp_manguito_center[i] = (cx, cy, cz)
                        else:
                            cx, cy, cz = self._temp_manguito_center.get(i, (0, 0, 0))

                        brep = AllplanGeo.Move(
                            brep,
                            AllplanGeo.Vector3D(
                                -cx + (longitud_original / 2.0), -cy, -cz
                            ),
                        )

                        rot_xy = effective_rot_xy[i]
                        rot_pitch = math.degrees(
                            math.atan2(data.delta_z, getattr(data, "longitud_xy", 0))
                        )

                        if debug:
                            print(
                                f"  {item_name} [manguito] rot_xy={rot_xy:.2f}° | "
                                f"rot_pitch={rot_pitch:.2f}° | "
                                f"extra_roll={extra_roll_by_view[i]:.0f}° | "
                                f"angulo_rotacion={getattr(data, 'angulo_rotacion', 0):.1f}°"
                            )

                        # Roll: angulo_rotacion del dato + compensación por view_mode
                        total_roll_m = (
                            getattr(data, "angulo_rotacion", 0) + extra_roll_by_view[i]
                        )
                        if abs(total_roll_m) > 0.001:
                            m = AllplanGeo.Matrix3D()
                            m.Rotation(
                                AllplanGeo.Line3D(0, 0, 0, 1, 0, 0),
                                AllplanGeo.Angle.FromDeg(total_roll_m),
                            )
                            brep = AllplanGeo.Transform(brep, m)

                        # Yaw (planta) — ángulo efectivo
                        m = AllplanGeo.Matrix3D()
                        m.Rotation(
                            AllplanGeo.Line3D(0, 0, 0, 0, 0, 1),
                            AllplanGeo.Angle.FromDeg(rot_xy),
                        )
                        brep = AllplanGeo.Transform(brep, m)

                        if abs(rot_pitch) > 0.1:
                            rad_xy = math.radians(rot_xy)
                            axis = AllplanGeo.Line3D(
                                0, 0, 0, math.sin(rad_xy), -math.cos(rad_xy), 0
                            )
                            m = AllplanGeo.Matrix3D()
                            m.Rotation(axis, AllplanGeo.Angle.FromDeg(rot_pitch))
                            brep = AllplanGeo.Transform(brep, m)

                        nuevo_brep = AllplanGeo.Move(
                            brep,
                            AllplanGeo.Vector3D(
                                (start_point.X + data.end.X) / 2.0,
                                (start_point.Y + data.end.Y) / 2.0,
                                (start_point.Z + data.end.Z) / 2.0,
                            ),
                        )
                        elementos_transformados.append(
                            {
                                "index": i,
                                "element_type": tipo_str,
                                "element": AllplanBasisElements.ModelElement3D(
                                    prop, nuevo_brep
                                ),
                            }
                        )

                    # ──────────────────────────────────────────────────────────
                    # CASO 2 – DIFUSOR
                    # ──────────────────────────────────────────────────────────
                    elif tipo_str == "difusor":
                        move_offset = 0
                        if point_side == 0:
                            move_offset = CONDUCTO_WIDTH / 2
                        elif point_side == 2:
                            move_offset = -CONDUCTO_WIDTH / 2
                        ang_int = int(data.angulo_xy)

                        if debug:
                            print(
                                f"  start_point: ({start_point.X:.1f}, {start_point.Y:.1f}, {start_point.Z:.1f})"
                            )

                        if point_role == "inicial":
                            punto_inicio_real = start_point
                            for j in range(i + 1, len(data_list)):
                                ni = data_list[j]
                                nt_s = ni.get("type", "")
                                nt_s = (
                                    nt_s
                                    if isinstance(nt_s, str)
                                    else (nt_s[0] if nt_s else "")
                                )
                                if nt_s not in TIPOS_ACCESORIOS:
                                    punto_inicio_real = getattr(
                                        ni["segment"].data, "start", start_point
                                    )
                                    break
                            _, vd = brep.GetVertices()
                            if vd:
                                brep = AllplanGeo.Move(
                                    brep,
                                    AllplanGeo.Vector3D(
                                        -sum(v.X for v in vd) / len(vd),
                                        -sum(v.Y for v in vd) / len(vd),
                                        -sum(v.Z for v in vd) / len(vd),
                                    ),
                                )
                            if ang_int != 0:
                                mr = AllplanGeo.Matrix3D()
                                mr.Rotation(
                                    AllplanGeo.Line3D(0, 0, 0, 0, 0, 1),
                                    AllplanGeo.Angle.FromDeg(data.angulo_xy),
                                )
                                brep = AllplanGeo.Transform(brep, mr)
                            w_cubo = -60 if ang_int in [0, 90, 89] else 60
                            offset_x = punto_inicio_real.X + w_cubo
                            offset_y = punto_inicio_real.Y + (
                                move_offset if ang_int in [0, 180, 178, 179] else w_cubo
                            )
                            nuevo_brep = AllplanGeo.Move(
                                brep,
                                AllplanGeo.Vector3D(
                                    offset_x, offset_y - 1, punto_inicio_real.Z + 11
                                ),
                            )

                        elif point_role == "final":
                            punto_final_real = getattr(
                                data,
                                "end",
                                AllplanGeo.Point3D(
                                    start_point.X + data.delta_x,
                                    start_point.Y + data.delta_y,
                                    start_point.Z + data.delta_z,
                                ),
                            )
                            if i < len(data_list) - 1:
                                for j in range(len(data_list) - 1, i, -1):
                                    ni = data_list[j]
                                    nt_s = ni.get("type", "")
                                    nt_s = (
                                        nt_s
                                        if isinstance(nt_s, str)
                                        else (nt_s[0] if nt_s else "")
                                    )
                                    if nt_s not in TIPOS_ACCESORIOS:
                                        punto_final_real = getattr(
                                            ni["segment"].data, "end", punto_final_real
                                        )
                                        break
                            cdz = 0
                            _, vd = brep.GetVertices()
                            if vd:
                                cdz = sum(v.Z for v in vd) / len(vd)
                                brep = AllplanGeo.Move(
                                    brep,
                                    AllplanGeo.Vector3D(
                                        -sum(v.X for v in vd) / len(vd),
                                        -sum(v.Y for v in vd) / len(vd),
                                        -cdz,
                                    ),
                                )
                            rot_diff = (
                                180
                                if ang_int == 0
                                else (
                                    0
                                    if ang_int in [180, 179, 178]
                                    else (
                                        -data.angulo_xy
                                        if ang_int in [-90, 89, 90, -89]
                                        else 0
                                    )
                                )
                            )
                            mr = AllplanGeo.Matrix3D()
                            mr.Rotation(
                                AllplanGeo.Line3D(0, 0, 0, 0, 0, 1),
                                AllplanGeo.Angle.FromDeg(rot_diff),
                            )
                            brep = AllplanGeo.Transform(brep, mr)
                            padding = 60
                            ltc = AllplanGeo.CalcLength(
                                AllplanGeo.Line3D(
                                    (
                                        data_list[0]["segment"].data.start
                                        if data_list[0].get("type", "")
                                        not in TIPOS_ACCESORIOS
                                        else start_point
                                    ),
                                    punto_final_real,
                                )
                            )
                            if ang_int in [0, 180, 179, 178]:
                                factor = -1 if ang_int in [180, 179, 178] else 1
                                nuevo_brep = AllplanGeo.Move(
                                    brep,
                                    AllplanGeo.Vector3D(
                                        punto_final_real.X + (padding * factor),
                                        punto_final_real.Y + move_offset,
                                        punto_final_real.Z - cdz + 11,
                                    ),
                                )
                            else:
                                factor = -1 if ang_int in [-90, -89] else 1
                                nuevo_brep = AllplanGeo.Move(
                                    brep,
                                    AllplanGeo.Vector3D(
                                        punto_final_real.X + move_offset,
                                        punto_final_real.Y + (padding * factor),
                                        punto_final_real.Z - cdz + 11,
                                    ),
                                )
                        else:
                            nuevo_brep = AllplanGeo.Move(
                                brep, AllplanGeo.Vector3D(pmx, pmy, pmz)
                            )

                        elementos_transformados.append(
                            {
                                "index": i,
                                "element_type": tipo_str,
                                "element": AllplanBasisElements.ModelElement3D(
                                    prop, nuevo_brep
                                ),
                            }
                        )

                    # ──────────────────────────────────────────────────────────
                    # CASO 3 – TUBOS DINÁMICOS
                    # ──────────────────────────────────────────────────────────
                    else:
                        nx = sum(v.X for v in verts) / len(verts) if verts else 0
                        ny = sum(v.Y for v in verts) / len(verts) if verts else 0
                        nz = sum(v.Z for v in verts) / len(verts) if verts else 0
                        brep = AllplanGeo.Move(brep, AllplanGeo.Vector3D(-nx, -ny, -nz))

                        # ─── ROT_XY efectivo ──────────────────────────────────
                        rot_xy = effective_rot_xy[i]

                        # Pitch: ángulo de inclinación con respecto al plano XY
                        long_xy_seg = getattr(data, "longitud_xy", 0.0)
                        rot_pitch = math.degrees(math.atan2(data.delta_z, long_xy_seg))

                        if debug:
                            dz_val = abs(getattr(data, "delta_z", 0.0))
                            fuente = (
                                "XY-propio"
                                if dz_val < UMBRAL_Z
                                else f"hereda(dz={dz_val:.1f})"
                            )
                            vm_name = getattr(segment, "view_mode", "XY")
                            print(
                                f"  {item_name} [{fuente}] view_mode={vm_name} "
                                f"rot_xy={rot_xy:.2f}° | rot_pitch={rot_pitch:.2f}° | "
                                f"long_xy={long_xy_seg:.2f} | "
                                f"extra_roll={extra_roll_by_view[i]:.0f}°"
                            )

                        # Roll: angulo_rotacion del dato + compensación por view_mode
                        total_roll_t = (
                            getattr(data, "angulo_rotacion", 0) + extra_roll_by_view[i]
                        )
                        if abs(total_roll_t) > 0.001:
                            m = AllplanGeo.Matrix3D()
                            m.Rotation(
                                AllplanGeo.Line3D(0, 0, 0, 1, 0, 0),
                                AllplanGeo.Angle.FromDeg(total_roll_t),
                            )
                            brep = AllplanGeo.Transform(brep, m)

                        # Yaw (planta) — ángulo efectivo
                        m = AllplanGeo.Matrix3D()
                        m.Rotation(
                            AllplanGeo.Line3D(0, 0, 0, 0, 0, 1),
                            AllplanGeo.Angle.FromDeg(rot_xy),
                        )
                        brep = AllplanGeo.Transform(brep, m)

                        # Pitch — el eje usa rot_xy efectivo para garantizar que la
                        # inclinación ocurra en el plano XZ o YZ correcto
                        if abs(rot_pitch) > 0.001:
                            rad_xy = math.radians(rot_xy)
                            axis = AllplanGeo.Line3D(
                                0, 0, 0, math.sin(rad_xy), -math.cos(rad_xy), 0
                            )
                            m = AllplanGeo.Matrix3D()
                            m.Rotation(axis, AllplanGeo.Angle.FromDeg(rot_pitch))
                            brep = AllplanGeo.Transform(brep, m)

                        # Centro ajustado por extensiones
                        desplazamiento_neto = (
                            longitud_original / 2.0
                            + (extension_final - extension_inicio) / 2.0
                        )
                        mid_x = start_point.X + vec_curr.X * desplazamiento_neto
                        mid_y = start_point.Y + vec_curr.Y * desplazamiento_neto
                        mid_z = start_point.Z + vec_curr.Z * desplazamiento_neto

                        nuevo_brep = AllplanGeo.Move(
                            brep, AllplanGeo.Vector3D(mid_x, mid_y, mid_z)
                        )
                        segment_brep = {
                            "index": i,
                            "element_type": tipo_str,
                            "element": AllplanBasisElements.ModelElement3D(
                                prop, nuevo_brep
                            ),
                        }
                        elementos_transformados.append(segment_brep)

            except Exception as ex:
                if debug:
                    print(f"ERROR CRÍTICO en elemento {i} ({tipo_str}): {ex}")

        if debug:
            print(f"\n{'='*70}")
            print(f"COMPLETADO: {len(elementos_transformados)} elementos procesados")
            print(f"{'='*70}\n")

        return elementos_transformados

    def center_and_connect_models_v6(
        self,
        data_list,
        conducto_width=75,
        color=None,
        point_role=None,
        point_side=None,
        debug=True,
    ):
        """
        Versión v6.

        REGLA DE ROTACIÓN (definitiva):
        ────────────────────────────────
        La rotación XY de la sección transversal del conducto se determina por
        el ÚLTIMO segmento PURAMENTE horizontal (delta_z ≈ 0) anterior al segmento
        actual.  Cualquier segmento que tenga componente Z (vertical puro, inclinado
        XZ o YZ) HEREDA ese ángulo, sin importar su propio angulo_xy.

        Esto cubre todos los casos:
        XY(0°) → XY(-45°) → Z↓ → XZ(0°) → XY(0°)
                                ↑           ↑
                            hereda -45°   hereda -45°  ← CORREGIDO en v6

        Clasificación de cada segmento:
        "XY puro"   : abs(delta_z) < UMBRAL_Z   → usa su propio angulo_xy
        "con Z"     : abs(delta_z) >= UMBRAL_Z   → hereda del XY puro anterior
                        (incluye vertical puro Y segmentos inclinados XZ/YZ)

        Pasadas del pre-procesado:
        Forward  → propaga el último XY puro hacia adelante
        Backward → cubre verticales que aparecen antes del primer XY puro
        """
        elementos_transformados = []
        last_real_end_point = None
        last_segment = None

        def get_dot_product(v1, v2):
            if not v1 or not v2:
                return 1.0
            return v1.X * v2.X + v1.Y * v2.Y + v1.Z * v2.Z

        def same_direction(seg1, seg2, tol_deg=1):
            if not seg1 or not seg2:
                return False
            diff = abs((seg1.data.angulo_xy - seg2.data.angulo_xy + 180) % 360 - 180)
            return diff < tol_deg

        CONDUCTO_WIDTH = conducto_width
        TIPOS_ACCESORIOS = ["manguito", "codo_45", "codo_90", "conexion", "difusor"]
        UMBRAL_Z = 0.1  # mm – por debajo se considera "sin componente Z" (XY puro)

        if debug:
            print(f"\n{'#'*70}")
            print(f"# PROCESANDO DATA LIST: {len(data_list)}")
            print(f"{'#'*70}")

        # =========================================================================
        # PRE-PROCESADO: effective_rot_xy
        #
        # Criterio: un segmento "tiene XY propio" solo si abs(delta_z) < UMBRAL_Z.
        # Cualquier segmento con componente Z hereda del último XY puro.
        # =========================================================================
        raw_rot_xy = []
        for item in data_list:
            seg = item.get("segment")
            if not seg:
                raw_rot_xy.append(None)
                continue
            d = seg.data
            delta_z = abs(getattr(d, "delta_z", 0.0))

            if delta_z < UMBRAL_Z:
                # XY puro → contribuye con su propio ángulo
                raw_rot_xy.append(getattr(d, "angulo_xy", 0.0))
            else:
                # Tiene Z (vertical o inclinado) → hereda
                raw_rot_xy.append(None)

        # Forward pass: propaga el último XY puro conocido hacia adelante
        last_known = None
        for idx in range(len(raw_rot_xy)):
            if raw_rot_xy[idx] is not None:
                last_known = raw_rot_xy[idx]
            elif last_known is not None:
                raw_rot_xy[idx] = last_known

        # Backward pass: cubre None al inicio (segmentos Z antes de cualquier XY)
        last_known = None
        for idx in range(len(raw_rot_xy) - 1, -1, -1):
            if raw_rot_xy[idx] is not None:
                last_known = raw_rot_xy[idx]
            elif last_known is not None:
                raw_rot_xy[idx] = last_known

        # Fallback final
        effective_rot_xy = [v if v is not None else 0.0 for v in raw_rot_xy]

        if debug:
            print(f"\n--- effective_rot_xy (v6: hereda si delta_z != 0) ---")
            for idx, item in enumerate(data_list):
                seg = item.get("segment")
                name = getattr(seg, "name", f"Seg_{idx}") if seg else f"Item_{idx}"
                tipo = item.get("type", "")
                if seg:
                    d = seg.data
                    dz = abs(getattr(d, "delta_z", 0.0))
                    orig = getattr(d, "angulo_xy", "?")
                    long_xy = getattr(d, "longitud_xy", 0.0)
                    fuente = (
                        "XY-propio" if dz < UMBRAL_Z else f"hereda (delta_z={dz:.1f})"
                    )
                    print(
                        f"  [{idx}] {name} ({tipo or 'tubo'}) | {fuente} | "
                        f"angulo_xy={orig}° long_xy={long_xy:.1f} → effective={effective_rot_xy[idx]:.2f}°"
                    )
            print()
        # =========================================================================
        # PRE-PROCESADO: extra_roll_by_view
        #
        # El BREP de cada segmento está modelado para viajar en el plano XY.
        # Cuando el view_mode es 'XZ' o 'YZ', la sección transversal queda
        # girada 90° respecto al plano de trabajo real → compensamos con +90° de
        # roll alrededor del eje de viaje (aplicado antes del yaw).
        #
        # Funciona en ambas direcciones:
        #   XY → XZ/YZ  y  XZ/YZ → XY
        # =========================================================================
        extra_roll_by_view = []
        for idx, item_vm in enumerate(data_list):
            seg_vm = item_vm.get("segment")
            if seg_vm:
                vm = getattr(seg_vm, "view_mode", "XY")
                extra_roll_by_view.append(90.0 if vm in ("XZ", "YZ") else 0.0)
            else:
                extra_roll_by_view.append(0.0)

        if debug:
            print(f"--- extra_roll_by_view (XZ/YZ → +90°, XY → 0°) ---")
            for idx, item_vm in enumerate(data_list):
                seg_vm = item_vm.get("segment")
                if seg_vm:
                    vm = getattr(seg_vm, "view_mode", "XY")
                    name_vm = getattr(seg_vm, "name", f"Seg_{idx}")
                    print(
                        f"  [{idx}] {name_vm} | view_mode={vm} → extra_roll={extra_roll_by_view[idx]:.0f}°"
                    )
            print()
        # =========================================================================

        for i, item in enumerate(data_list):
            try:
                segment = item.get("segment")
                if not segment:
                    continue
                data = segment.data
                item_name = getattr(segment, "name", f"Segment_{i}")
                start_point = getattr(data, "start", None)
                if start_point is None:
                    continue
                tipo_str = item.get("type", "")
                is_dinamic = tipo_str not in TIPOS_ACCESORIOS

                vec_curr = getattr(data, "vector_normalizado", None)
                if vec_curr is None:
                    vec_curr = AllplanGeo.Vector3D(
                        getattr(data, "delta_x", 0),
                        getattr(data, "delta_y", 0),
                        getattr(data, "delta_z", 0),
                    )
                    vec_curr.Normalize()

                if (
                    last_real_end_point is not None
                    and last_segment is not None
                    and same_direction(last_segment, segment)
                ):
                    start_point = last_real_end_point

                extension_inicio = 0.0
                extension_final = 0.0

                # ── Extensiones en uniones (solo tubos dinámicos) ────────────────
                if is_dinamic:
                    MIN_ANGLE_RAD = 0.0175
                    MAX_ANGLE_RAD = math.pi - 0.0175

                    if i > 0:
                        prev_item = data_list[i - 1]
                        prev_tipo_s = prev_item.get("type", "")
                        prev_tipo_s = (
                            prev_tipo_s
                            if isinstance(prev_tipo_s, str)
                            else (prev_tipo_s[0] if prev_tipo_s else "")
                        )
                        if prev_tipo_s == "manguito":
                            extension_inicio = 0.0
                            if debug:
                                print(
                                    f"  {item_name} – manguito anterior → ext_inicio=0"
                                )
                        else:
                            p_data = prev_item["segment"].data
                            vec_prev = AllplanGeo.Vector3D(
                                p_data.delta_x, p_data.delta_y, p_data.delta_z
                            )
                            vec_prev.Normalize()
                            dot = max(
                                -1.0, min(1.0, get_dot_product(vec_prev, vec_curr))
                            )
                            a_rad = math.acos(dot)
                            if MIN_ANGLE_RAD < a_rad < MAX_ANGLE_RAD:
                                extension_inicio = (CONDUCTO_WIDTH / 2.0) * math.tan(
                                    a_rad / 2.0
                                )
                                if debug:
                                    print(
                                        f"  {item_name} – ext_inicio: {math.degrees(a_rad):.1f}° → {extension_inicio:.2f}mm"
                                    )

                    if i < len(data_list) - 1:
                        next_item = data_list[i + 1]
                        next_tipo_s = next_item.get("type", "")
                        next_tipo_s = (
                            next_tipo_s
                            if isinstance(next_tipo_s, str)
                            else (next_tipo_s[0] if next_tipo_s else "")
                        )
                        if next_tipo_s == "manguito":
                            extension_final = 0.0
                            if debug:
                                print(
                                    f"  {item_name} – manguito siguiente → ext_final=0"
                                )
                        else:
                            n_data = next_item["segment"].data
                            vec_next = AllplanGeo.Vector3D(
                                n_data.delta_x, n_data.delta_y, n_data.delta_z
                            )
                            vec_next.Normalize()
                            dot = max(
                                -1.0, min(1.0, get_dot_product(vec_curr, vec_next))
                            )
                            a_rad = math.acos(dot)
                            if MIN_ANGLE_RAD < a_rad < MAX_ANGLE_RAD:
                                extension_final = (CONDUCTO_WIDTH / 2.0) * math.tan(
                                    a_rad / 2.0
                                )
                                if debug:
                                    print(
                                        f"  {item_name} – ext_final: {math.degrees(a_rad):.1f}° → {extension_final:.2f}mm"
                                    )

                longitud_original = getattr(data, "longitud_3d", 0.0)
                longitud_total = longitud_original + extension_inicio + extension_final

                if debug and is_dinamic:
                    print(f"\n{item_name}")
                    print(
                        f"  long_orig={longitud_original:.2f} | ext_i={extension_inicio:.2f} | "
                        f"ext_f={extension_final:.2f} | total={longitud_total:.2f}"
                    )

                list_elem_3d = item.get("element3d", [])
                lista_elem_3d_modified = []
                if is_dinamic:
                    for elem in list_elem_3d:
                        lista_elem_3d_modified.append(
                            self.modificar_dimensiones_brep(elem, longitud_total)
                        )
                else:
                    lista_elem_3d_modified = list_elem_3d

                segment_brep = None
                for e, elem_3d in enumerate(lista_elem_3d_modified):
                    prop = elem_3d.GetCommonProperties()
                    if is_dinamic and color:
                        prop.Color = color

                    brep = elem_3d.GetGeometryObject()
                    _, verts = brep.GetVertices()

                    # Punto medio geométrico
                    pmx = (start_point.X + data.end.X) / 2.0
                    pmy = (start_point.Y + data.end.Y) / 2.0
                    pmz = (start_point.Z + data.end.Z) / 2.0
                    if verts:
                        pmx = sum(v.X for v in verts) / len(verts)
                        pmy = sum(v.Y for v in verts) / len(verts)
                        pmz = sum(v.Z for v in verts) / len(verts)

                    nuevo_brep = None

                    # ──────────────────────────────────────────────────────────
                    # CASO 1 – MANGUITO
                    # ──────────────────────────────────────────────────────────
                    if tipo_str == "manguito":
                        segment_brep = None
                        if e == 0:
                            _, vp = brep.GetVertices()
                            if vp:
                                cx = sum(v.X for v in vp) / len(vp)
                                cy = sum(v.Y for v in vp) / len(vp)
                                cz = sum(v.Z for v in vp) / len(vp)
                            else:
                                cx, cy, cz = pmx, pmy, pmz
                            if not hasattr(self, "_temp_manguito_center"):
                                self._temp_manguito_center = {}
                            self._temp_manguito_center[i] = (cx, cy, cz)
                        else:
                            cx, cy, cz = self._temp_manguito_center.get(i, (0, 0, 0))

                        brep = AllplanGeo.Move(
                            brep,
                            AllplanGeo.Vector3D(
                                -cx + (longitud_original / 2.0), -cy, -cz
                            ),
                        )

                        rot_xy = effective_rot_xy[i]
                        rot_pitch = math.degrees(
                            math.atan2(data.delta_z, getattr(data, "longitud_xy", 0))
                        )

                        if debug:
                            print(
                                f"  {item_name} [manguito] rot_xy={rot_xy:.2f}° | rot_pitch={rot_pitch:.2f}°"
                            )

                        if abs(getattr(data, "angulo_rotacion", 0)) > 0.1:
                            m = AllplanGeo.Matrix3D()
                            m.Rotation(
                                AllplanGeo.Line3D(0, 0, 0, 1, 0, 0),
                                AllplanGeo.Angle.FromDeg(data.angulo_rotacion),
                            )
                            brep = AllplanGeo.Transform(brep, m)

                        m = AllplanGeo.Matrix3D()
                        m.Rotation(
                            AllplanGeo.Line3D(0, 0, 0, 0, 0, 1),
                            AllplanGeo.Angle.FromDeg(rot_xy),
                        )
                        brep = AllplanGeo.Transform(brep, m)

                        if abs(rot_pitch) > 0.1:
                            rad_xy = math.radians(rot_xy)
                            axis = AllplanGeo.Line3D(
                                0, 0, 0, math.sin(rad_xy), -math.cos(rad_xy), 0
                            )
                            m = AllplanGeo.Matrix3D()
                            m.Rotation(axis, AllplanGeo.Angle.FromDeg(rot_pitch))
                            brep = AllplanGeo.Transform(brep, m)

                        nuevo_brep = AllplanGeo.Move(
                            brep,
                            AllplanGeo.Vector3D(
                                (start_point.X + data.end.X) / 2.0,
                                (start_point.Y + data.end.Y) / 2.0,
                                (start_point.Z + data.end.Z) / 2.0,
                            ),
                        )
                        elementos_transformados.append(
                            {
                                "index": i,
                                "element_type": tipo_str,
                                "element": AllplanBasisElements.ModelElement3D(
                                    prop, nuevo_brep
                                ),
                            }
                        )

                    # ──────────────────────────────────────────────────────────
                    # CASO 2 – DIFUSOR
                    # ──────────────────────────────────────────────────────────
                    elif tipo_str == "difusor":
                        move_offset = 0
                        if point_side == 0:
                            move_offset = CONDUCTO_WIDTH / 2
                        elif point_side == 2:
                            move_offset = -CONDUCTO_WIDTH / 2
                        ang_int = int(data.angulo_xy)

                        if debug:
                            print(
                                f"  start_point: ({start_point.X:.1f}, {start_point.Y:.1f}, {start_point.Z:.1f})"
                            )

                        if point_role == "inicial":
                            punto_inicio_real = start_point
                            for j in range(i + 1, len(data_list)):
                                ni = data_list[j]
                                nt_s = ni.get("type", "")
                                nt_s = (
                                    nt_s
                                    if isinstance(nt_s, str)
                                    else (nt_s[0] if nt_s else "")
                                )
                                if nt_s not in TIPOS_ACCESORIOS:
                                    punto_inicio_real = getattr(
                                        ni["segment"].data, "start", start_point
                                    )
                                    break
                            _, vd = brep.GetVertices()
                            if vd:
                                brep = AllplanGeo.Move(
                                    brep,
                                    AllplanGeo.Vector3D(
                                        -sum(v.X for v in vd) / len(vd),
                                        -sum(v.Y for v in vd) / len(vd),
                                        -sum(v.Z for v in vd) / len(vd),
                                    ),
                                )
                            if ang_int != 0:
                                mr = AllplanGeo.Matrix3D()
                                mr.Rotation(
                                    AllplanGeo.Line3D(0, 0, 0, 0, 0, 1),
                                    AllplanGeo.Angle.FromDeg(data.angulo_xy),
                                )
                                brep = AllplanGeo.Transform(brep, mr)
                            w_cubo = -60 if ang_int in [0, 90, 89] else 60
                            offset_x = punto_inicio_real.X + w_cubo
                            offset_y = punto_inicio_real.Y + (
                                move_offset if ang_int in [0, 180, 178, 179] else w_cubo
                            )
                            nuevo_brep = AllplanGeo.Move(
                                brep,
                                AllplanGeo.Vector3D(
                                    offset_x, offset_y - 1, punto_inicio_real.Z + 11
                                ),
                            )

                        elif point_role == "final":
                            punto_final_real = getattr(
                                data,
                                "end",
                                AllplanGeo.Point3D(
                                    start_point.X + data.delta_x,
                                    start_point.Y + data.delta_y,
                                    start_point.Z + data.delta_z,
                                ),
                            )
                            if i < len(data_list) - 1:
                                for j in range(len(data_list) - 1, i, -1):
                                    ni = data_list[j]
                                    nt_s = ni.get("type", "")
                                    nt_s = (
                                        nt_s
                                        if isinstance(nt_s, str)
                                        else (nt_s[0] if nt_s else "")
                                    )
                                    if nt_s not in TIPOS_ACCESORIOS:
                                        punto_final_real = getattr(
                                            ni["segment"].data, "end", punto_final_real
                                        )
                                        break
                            cdz = 0
                            _, vd = brep.GetVertices()
                            if vd:
                                cdz = sum(v.Z for v in vd) / len(vd)
                                brep = AllplanGeo.Move(
                                    brep,
                                    AllplanGeo.Vector3D(
                                        -sum(v.X for v in vd) / len(vd),
                                        -sum(v.Y for v in vd) / len(vd),
                                        -cdz,
                                    ),
                                )
                            rot_diff = (
                                180
                                if ang_int == 0
                                else (
                                    0
                                    if ang_int in [180, 179, 178]
                                    else (
                                        -data.angulo_xy
                                        if ang_int in [-90, 89, 90, -89]
                                        else 0
                                    )
                                )
                            )
                            mr = AllplanGeo.Matrix3D()
                            mr.Rotation(
                                AllplanGeo.Line3D(0, 0, 0, 0, 0, 1),
                                AllplanGeo.Angle.FromDeg(rot_diff),
                            )
                            brep = AllplanGeo.Transform(brep, mr)
                            padding = 60
                            ltc = AllplanGeo.CalcLength(
                                AllplanGeo.Line3D(
                                    (
                                        data_list[0]["segment"].data.start
                                        if data_list[0].get("type", "")
                                        not in TIPOS_ACCESORIOS
                                        else start_point
                                    ),
                                    punto_final_real,
                                )
                            )
                            if ang_int in [0, 180, 179, 178]:
                                factor = -1 if ang_int in [180, 179, 178] else 1
                                nuevo_brep = AllplanGeo.Move(
                                    brep,
                                    AllplanGeo.Vector3D(
                                        punto_final_real.X + (padding * factor),
                                        punto_final_real.Y + move_offset,
                                        punto_final_real.Z - cdz + 11,
                                    ),
                                )
                            else:
                                factor = -1 if ang_int in [-90, -89] else 1
                                nuevo_brep = AllplanGeo.Move(
                                    brep,
                                    AllplanGeo.Vector3D(
                                        punto_final_real.X + move_offset,
                                        punto_final_real.Y + (padding * factor),
                                        punto_final_real.Z - cdz + 11,
                                    ),
                                )
                        else:
                            nuevo_brep = AllplanGeo.Move(
                                brep, AllplanGeo.Vector3D(pmx, pmy, pmz)
                            )

                        elementos_transformados.append(
                            {
                                "index": i,
                                "element_type": tipo_str,
                                "element": AllplanBasisElements.ModelElement3D(
                                    prop, nuevo_brep
                                ),
                            }
                        )

                    # ──────────────────────────────────────────────────────────
                    # CASO 3 – TUBOS DINÁMICOS
                    # ──────────────────────────────────────────────────────────
                    else:
                        nx = sum(v.X for v in verts) / len(verts) if verts else 0
                        ny = sum(v.Y for v in verts) / len(verts) if verts else 0
                        nz = sum(v.Z for v in verts) / len(verts) if verts else 0
                        brep = AllplanGeo.Move(brep, AllplanGeo.Vector3D(-nx, -ny, -nz))

                        # ─── ROT_XY efectivo ──────────────────────────────────
                        # Si delta_z ≈ 0 → usa el propio angulo_xy (ya está en effective)
                        # Si delta_z != 0 → hereda del último XY puro (ya está en effective)
                        rot_xy = effective_rot_xy[i]

                        # Pitch: ángulo de inclinación con respecto al plano XY
                        # atan2(delta_z, longitud_xy):
                        #   XY puro   → pitch = 0°
                        #   Z puro    → pitch = ±90°
                        #   Inclinado → pitch = ±45° (o el ángulo real)
                        long_xy_seg = getattr(data, "longitud_xy", 0.0)
                        rot_pitch = math.degrees(math.atan2(data.delta_z, long_xy_seg))

                        if debug:
                            dz_val = abs(getattr(data, "delta_z", 0.0))
                            fuente = (
                                "XY-propio"
                                if dz_val < UMBRAL_Z
                                else f"hereda(dz={dz_val:.1f})"
                            )
                            print(
                                f"  {item_name} [{fuente}] "
                                f"rot_xy={rot_xy:.2f}° | rot_pitch={rot_pitch:.2f}° | "
                                f"long_xy={long_xy_seg:.2f}"
                            )

                        # Roll
                        if abs(getattr(data, "angulo_rotacion", 0)) > 0.001:
                            m = AllplanGeo.Matrix3D()
                            m.Rotation(
                                AllplanGeo.Line3D(0, 0, 0, 1, 0, 0),
                                AllplanGeo.Angle.FromDeg(data.angulo_rotacion),
                            )
                            brep = AllplanGeo.Transform(brep, m)

                        # Yaw (planta) — ángulo efectivo
                        m = AllplanGeo.Matrix3D()
                        m.Rotation(
                            AllplanGeo.Line3D(0, 0, 0, 0, 0, 1),
                            AllplanGeo.Angle.FromDeg(rot_xy),
                        )
                        brep = AllplanGeo.Transform(brep, m)

                        # Pitch — el eje usa rot_xy efectivo para garantizar que la
                        # inclinación ocurra en el plano XZ o YZ correcto según la
                        # dirección horizontal del conducto
                        if abs(rot_pitch) > 0.001:
                            rad_xy = math.radians(rot_xy)
                            axis = AllplanGeo.Line3D(
                                0,
                                0,
                                0,
                                math.sin(rad_xy),  #  componente X del eje perpendicular
                                -math.cos(
                                    rad_xy
                                ),  # -componente Y del eje perpendicular
                                0,
                            )
                            m = AllplanGeo.Matrix3D()
                            m.Rotation(axis, AllplanGeo.Angle.FromDeg(rot_pitch))
                            brep = AllplanGeo.Transform(brep, m)

                        # Centro ajustado por extensiones
                        desplazamiento_neto = (
                            longitud_original / 2.0
                            + (extension_final - extension_inicio) / 2.0
                        )
                        mid_x = start_point.X + vec_curr.X * desplazamiento_neto
                        mid_y = start_point.Y + vec_curr.Y * desplazamiento_neto
                        mid_z = start_point.Z + vec_curr.Z * desplazamiento_neto

                        nuevo_brep = AllplanGeo.Move(
                            brep, AllplanGeo.Vector3D(mid_x, mid_y, mid_z)
                        )
                        segment_brep = {
                            "index": i,
                            "element_type": tipo_str,
                            "element": AllplanBasisElements.ModelElement3D(
                                prop, nuevo_brep
                            ),
                        }
                        elementos_transformados.append(segment_brep)

            except Exception as ex:
                if debug:
                    print(f"ERROR CRÍTICO en elemento {i} ({tipo_str}): {ex}")

        if debug:
            print(f"\n{'='*70}")
            print(f"COMPLETADO: {len(elementos_transformados)} elementos procesados")
            print(f"{'='*70}\n")

        return elementos_transformados

    def center_and_connect_models_v5(
        self,
        data_list,
        conducto_width=75,
        color=None,
        point_role=None,
        point_side=None,
        debug=True,
    ):
        """
        Versión v5.

        REGLA DE ROTACIÓN (simplificada y correcta):
        ─────────────────────────────────────────────
        • Segmento CON componente XY (longitud_xy >= UMBRAL_XY):
            → usa su propio data.angulo_xy  (nunca se hereda ni se sobreescribe)

        • Segmento SIN componente XY  (longitud_xy < UMBRAL_XY = vertical puro):
            → hereda el effective_rot_xy del segmento horizontal más cercano.
            Primero busca hacia ATRÁS; si no hay, busca hacia ADELANTE.
            El eje del pitch también usará ese ángulo heredado para que la
            inclinación se aplique en el plano XZ o YZ correcto.

        Esto cubre:
        XY → Z (descenso vertical)          ✓  hereda ángulo del XY anterior
        Z  → XY (subida / retorno plano)    ✓  el XY siguiente da su propio ángulo
        XY → XZ/YZ (inclinado con delta_z)  ✓  el segmento inclinado tiene XY propio
        XZ/YZ → XY                          ✓  ídem
        """
        elementos_transformados = []
        last_real_end_point = None
        last_segment = None

        def get_dot_product(v1, v2):
            if not v1 or not v2:
                return 1.0
            return v1.X * v2.X + v1.Y * v2.Y + v1.Z * v2.Z

        def same_direction(seg1, seg2, tol_deg=1):
            if not seg1 or not seg2:
                return False
            diff = abs((seg1.data.angulo_xy - seg2.data.angulo_xy + 180) % 360 - 180)
            return diff < tol_deg

        CONDUCTO_WIDTH = conducto_width
        TIPOS_ACCESORIOS = ["manguito", "codo_45", "codo_90", "conexion", "difusor"]
        UMBRAL_XY = 0.1  # mm – por debajo se considera "sin componente XY"

        if debug:
            print(f"\n{'#'*70}")
            print(f"# PROCESANDO DATA LIST: {len(data_list)}")
            print(f"{'#'*70}")

        # # =========================================================================
        # # PRE-PROCESADO: effective_rot_xy
        # #
        # # Paso 1 – marcar cada slot:
        # #   • tiene XY propio  → guardar data.angulo_xy
        # #   • sin XY (vertical)→ None  (se rellena en paso 2)
        # #
        # # Paso 2 – relleno bidireccional:
        # #   Forward:  propaga el último angulo_xy conocido hacia los None
        # #   Backward: propaga el primer angulo_xy conocido hacia los None iniciales
        # # =========================================================================
        # raw_rot_xy = []
        # for item in data_list:
        #     seg = item.get("segment")
        #     if not seg:
        #         raw_rot_xy.append(None)
        #         continue
        #     d       = seg.data
        #     long_xy = getattr(d, 'longitud_xy', 0.0)
        #     # Solo tiene orientación XY propia si realmente se mueve en XY
        #     raw_rot_xy.append(d.angulo_xy if long_xy >= UMBRAL_XY else None)
        # =========================================================================
        # PRE-PROCESADO: effective_rot_xy (CORREGIDO)
        # =========================================================================
        raw_rot_xy = []
        for item in data_list:
            seg = item.get("segment")
            if not seg:
                raw_rot_xy.append(None)
                continue

            d = seg.data
            long_xy = getattr(d, "longitud_xy", 0.0)
            delta_z = abs(getattr(d, "delta_z", 0.0))

            # REGLA DE ORO: Solo los segmentos "planos" definen la dirección XY.
            # Un segmento inclinado (con delta_z significativo) debe heredar
            # la rotación de los tramos horizontales para no salirse del plano.
            # Usamos un umbral para decidir si el tramo es lo suficientemente horizontal.
            es_horizontal = delta_z < (
                long_xy * 0.5
            )  # Ejemplo: pendiente menor a 30° aprox.
            # O simplemente: es_horizontal = delta_z < 1.0 (si el desnivel es casi cero)

            if long_xy >= UMBRAL_XY and es_horizontal:
                raw_rot_xy.append(d.angulo_xy)
            else:
                # Si es vertical PURO o inclinado con mucha pendiente -> Hereda
                raw_rot_xy.append(None)

        # Forward pass: hereda del anterior
        last_known = None
        for idx in range(len(raw_rot_xy)):
            if raw_rot_xy[idx] is not None:
                last_known = raw_rot_xy[idx]
            elif last_known is not None:
                raw_rot_xy[idx] = last_known  # hereda

        # Backward pass: rellena None que quedaron al inicio (verticales sin XY previo)
        last_known = None
        for idx in range(len(raw_rot_xy) - 1, -1, -1):
            if raw_rot_xy[idx] is not None:
                last_known = raw_rot_xy[idx]
            elif last_known is not None:
                raw_rot_xy[idx] = last_known

        # None residuales → 0.0
        effective_rot_xy = [v if v is not None else 0.0 for v in raw_rot_xy]

        if debug:
            print(f"\n--- effective_rot_xy ---")
            for idx, item in enumerate(data_list):
                seg = item.get("segment")
                name = getattr(seg, "name", f"Seg_{idx}") if seg else f"Item_{idx}"
                tipo = item.get("type", "")
                if seg:
                    d = seg.data
                    long_xy = getattr(d, "longitud_xy", 0.0)
                    orig = getattr(d, "angulo_xy", "?")
                    tiene = "XY-propio" if long_xy >= UMBRAL_XY else "vertical→hereda"
                    print(
                        f"  [{idx}] {name} ({tipo or 'tubo'}) | {tiene} | angulo_xy_orig={orig}° → effective={effective_rot_xy[idx]:.2f}°"
                    )
            print()
        # =========================================================================

        for i, item in enumerate(data_list):
            try:
                segment = item.get("segment")
                if not segment:
                    continue
                data = segment.data
                item_name = getattr(segment, "name", f"Segment_{i}")
                start_point = getattr(data, "start", None)
                if start_point is None:
                    continue
                tipo_str = item.get("type", "")
                is_dinamic = tipo_str not in TIPOS_ACCESORIOS

                # Vector de dirección actual
                vec_curr = getattr(data, "vector_normalizado", None)
                if vec_curr is None:
                    vec_curr = AllplanGeo.Vector3D(
                        getattr(data, "delta_x", 0),
                        getattr(data, "delta_y", 0),
                        getattr(data, "delta_z", 0),
                    )
                    vec_curr.Normalize()

                # Continuidad de inicio para segmentos en la misma dirección
                if (
                    last_real_end_point is not None
                    and last_segment is not None
                    and same_direction(last_segment, segment)
                ):
                    start_point = last_real_end_point

                extension_inicio = 0.0
                extension_final = 0.0

                # ── Cálculo de extensiones (solo tubos dinámicos) ────────────────
                if is_dinamic:
                    MIN_ANGLE_RAD = 0.0175  # ~1°
                    MAX_ANGLE_RAD = math.pi - 0.0175  # ~179°

                    # Vecino anterior
                    if i > 0:
                        prev_item = data_list[i - 1]
                        prev_tipo = prev_item.get("type", "")
                        prev_tipo_s = (
                            prev_tipo
                            if isinstance(prev_tipo, str)
                            else (prev_tipo[0] if prev_tipo else "")
                        )
                        if prev_tipo_s == "manguito":
                            extension_inicio = 0.0
                            if debug:
                                print(
                                    f"  {item_name} – manguito anterior → ext_inicio=0"
                                )
                        else:
                            p_data = prev_item["segment"].data
                            vec_prev = AllplanGeo.Vector3D(
                                p_data.delta_x, p_data.delta_y, p_data.delta_z
                            )
                            vec_prev.Normalize()
                            dot = max(
                                -1.0, min(1.0, get_dot_product(vec_prev, vec_curr))
                            )
                            a_rad = math.acos(dot)
                            if MIN_ANGLE_RAD < a_rad < MAX_ANGLE_RAD:
                                extension_inicio = (CONDUCTO_WIDTH / 2.0) * math.tan(
                                    a_rad / 2.0
                                )
                                if debug:
                                    print(
                                        f"  {item_name} – ext_inicio: {math.degrees(a_rad):.1f}° → {extension_inicio:.2f}mm"
                                    )
                            else:
                                extension_inicio = 0.0

                    # Vecino siguiente
                    if i < len(data_list) - 1:
                        next_item = data_list[i + 1]
                        next_tipo = next_item.get("type", "")
                        next_tipo_s = (
                            next_tipo
                            if isinstance(next_tipo, str)
                            else (next_tipo[0] if next_tipo else "")
                        )
                        if next_tipo_s == "manguito":
                            extension_final = 0.0
                            if debug:
                                print(
                                    f"  {item_name} – manguito siguiente → ext_final=0"
                                )
                        else:
                            n_data = next_item["segment"].data
                            vec_next = AllplanGeo.Vector3D(
                                n_data.delta_x, n_data.delta_y, n_data.delta_z
                            )
                            vec_next.Normalize()
                            dot = max(
                                -1.0, min(1.0, get_dot_product(vec_curr, vec_next))
                            )
                            a_rad = math.acos(dot)
                            if MIN_ANGLE_RAD < a_rad < MAX_ANGLE_RAD:
                                extension_final = (CONDUCTO_WIDTH / 2.0) * math.tan(
                                    a_rad / 2.0
                                )
                                if debug:
                                    print(
                                        f"  {item_name} – ext_final: {math.degrees(a_rad):.1f}° → {extension_final:.2f}mm"
                                    )
                            else:
                                extension_final = 0.0

                longitud_original = getattr(data, "longitud_3d", 0.0)
                longitud_total = longitud_original + extension_inicio + extension_final

                if debug and is_dinamic:
                    print(f"\n{item_name}")
                    print(
                        f"  long_orig={longitud_original:.2f} | ext_i={extension_inicio:.2f} | ext_f={extension_final:.2f} | total={longitud_total:.2f}"
                    )

                # ── BREPs ────────────────────────────────────────────────────────
                list_elem_3d = item.get("element3d", [])
                lista_elem_3d_modified = []
                if is_dinamic:
                    for elem in list_elem_3d:
                        lista_elem_3d_modified.append(
                            self.modificar_dimensiones_brep(elem, longitud_total)
                        )
                else:
                    lista_elem_3d_modified = list_elem_3d

                segment_brep = None
                for e, elem_3d in enumerate(lista_elem_3d_modified):
                    prop = elem_3d.GetCommonProperties()
                    if is_dinamic and color:
                        prop.Color = color

                    brep = elem_3d.GetGeometryObject()
                    _, verts = brep.GetVertices()

                    # Punto medio geométrico del segmento (para manguitos / fallback)
                    pmx = (start_point.X + data.end.X) / 2.0
                    pmy = (start_point.Y + data.end.Y) / 2.0
                    pmz = (start_point.Z + data.end.Z) / 2.0

                    if verts:
                        pmx = sum(v.X for v in verts) / len(verts)
                        pmy = sum(v.Y for v in verts) / len(verts)
                        pmz = sum(v.Z for v in verts) / len(verts)

                    nuevo_brep = None

                    # ──────────────────────────────────────────────────────────
                    # CASO 1 – MANGUITO
                    # ──────────────────────────────────────────────────────────
                    if tipo_str == "manguito":
                        segment_brep = None
                        if e == 0:
                            _, vp = brep.GetVertices()
                            if vp:
                                cx = sum(v.X for v in vp) / len(vp)
                                cy = sum(v.Y for v in vp) / len(vp)
                                cz = sum(v.Z for v in vp) / len(vp)
                            else:
                                cx, cy, cz = pmx, pmy, pmz
                            if not hasattr(self, "_temp_manguito_center"):
                                self._temp_manguito_center = {}
                            self._temp_manguito_center[i] = (cx, cy, cz)
                        else:
                            cx, cy, cz = self._temp_manguito_center.get(i, (0, 0, 0))

                        brep = AllplanGeo.Move(
                            brep,
                            AllplanGeo.Vector3D(
                                -cx + (longitud_original / 2.0), -cy, -cz
                            ),
                        )

                        # *** Usa effective_rot_xy (heredado si es vertical) ***
                        rot_xy = effective_rot_xy[i]
                        rot_pitch = math.degrees(
                            math.atan2(data.delta_z, getattr(data, "longitud_xy", 0))
                        )

                        if debug:
                            print(
                                f"  {item_name} [manguito] rot_xy={rot_xy:.2f}° | rot_pitch={rot_pitch:.2f}°"
                            )

                        # Roll
                        if abs(getattr(data, "angulo_rotacion", 0)) > 0.1:
                            m = AllplanGeo.Matrix3D()
                            m.Rotation(
                                AllplanGeo.Line3D(0, 0, 0, 1, 0, 0),
                                AllplanGeo.Angle.FromDeg(data.angulo_rotacion),
                            )
                            brep = AllplanGeo.Transform(brep, m)

                        # Yaw
                        m = AllplanGeo.Matrix3D()
                        m.Rotation(
                            AllplanGeo.Line3D(0, 0, 0, 0, 0, 1),
                            AllplanGeo.Angle.FromDeg(rot_xy),
                        )
                        brep = AllplanGeo.Transform(brep, m)

                        # Pitch — eje perpendicular al rot_xy efectivo
                        if abs(rot_pitch) > 0.1:
                            rad_xy = math.radians(rot_xy)
                            axis = AllplanGeo.Line3D(
                                0, 0, 0, math.sin(rad_xy), -math.cos(rad_xy), 0
                            )
                            m = AllplanGeo.Matrix3D()
                            m.Rotation(axis, AllplanGeo.Angle.FromDeg(rot_pitch))
                            brep = AllplanGeo.Transform(brep, m)

                        nuevo_brep = AllplanGeo.Move(
                            brep,
                            AllplanGeo.Vector3D(
                                (start_point.X + data.end.X) / 2.0,
                                (start_point.Y + data.end.Y) / 2.0,
                                (start_point.Z + data.end.Z) / 2.0,
                            ),
                        )
                        elementos_transformados.append(
                            {
                                "index": i,
                                "element_type": tipo_str,
                                "element": AllplanBasisElements.ModelElement3D(
                                    prop, nuevo_brep
                                ),
                            }
                        )

                    # ──────────────────────────────────────────────────────────
                    # CASO 2 – DIFUSOR
                    # ──────────────────────────────────────────────────────────
                    elif tipo_str == "difusor":
                        move_offset = 0
                        if point_side == 0:
                            move_offset = CONDUCTO_WIDTH / 2
                        elif point_side == 2:
                            move_offset = -CONDUCTO_WIDTH / 2
                        ang_int = int(data.angulo_xy)

                        if debug:
                            print(
                                f"  start_point: ({start_point.X:.1f}, {start_point.Y:.1f}, {start_point.Z:.1f})"
                            )

                        if point_role == "inicial":
                            punto_inicio_real = start_point
                            for j in range(i + 1, len(data_list)):
                                ni = data_list[j]
                                nt_s = ni.get("type", "")
                                nt_s = (
                                    nt_s
                                    if isinstance(nt_s, str)
                                    else (nt_s[0] if nt_s else "")
                                )
                                if nt_s not in TIPOS_ACCESORIOS:
                                    punto_inicio_real = getattr(
                                        ni["segment"].data, "start", start_point
                                    )
                                    break
                            _, vd = brep.GetVertices()
                            if vd:
                                brep = AllplanGeo.Move(
                                    brep,
                                    AllplanGeo.Vector3D(
                                        -sum(v.X for v in vd) / len(vd),
                                        -sum(v.Y for v in vd) / len(vd),
                                        -sum(v.Z for v in vd) / len(vd),
                                    ),
                                )
                            if ang_int != 0:
                                mr = AllplanGeo.Matrix3D()
                                mr.Rotation(
                                    AllplanGeo.Line3D(0, 0, 0, 0, 0, 1),
                                    AllplanGeo.Angle.FromDeg(data.angulo_xy),
                                )
                                brep = AllplanGeo.Transform(brep, mr)
                            w_cubo = -60 if ang_int in [0, 90, 89] else 60
                            offset_x = punto_inicio_real.X + w_cubo
                            offset_y = punto_inicio_real.Y + (
                                move_offset if ang_int in [0, 180, 178, 179] else w_cubo
                            )
                            nuevo_brep = AllplanGeo.Move(
                                brep,
                                AllplanGeo.Vector3D(
                                    offset_x, offset_y - 1, punto_inicio_real.Z + 11
                                ),
                            )

                        elif point_role == "final":
                            punto_final_real = getattr(
                                data,
                                "end",
                                AllplanGeo.Point3D(
                                    start_point.X + data.delta_x,
                                    start_point.Y + data.delta_y,
                                    start_point.Z + data.delta_z,
                                ),
                            )
                            if i < len(data_list) - 1:
                                for j in range(len(data_list) - 1, i, -1):
                                    ni = data_list[j]
                                    nt_s = ni.get("type", "")
                                    nt_s = (
                                        nt_s
                                        if isinstance(nt_s, str)
                                        else (nt_s[0] if nt_s else "")
                                    )
                                    if nt_s not in TIPOS_ACCESORIOS:
                                        punto_final_real = getattr(
                                            ni["segment"].data, "end", punto_final_real
                                        )
                                        break
                            cdz = 0
                            _, vd = brep.GetVertices()
                            if vd:
                                cdz = sum(v.Z for v in vd) / len(vd)
                                brep = AllplanGeo.Move(
                                    brep,
                                    AllplanGeo.Vector3D(
                                        -sum(v.X for v in vd) / len(vd),
                                        -sum(v.Y for v in vd) / len(vd),
                                        -cdz,
                                    ),
                                )
                            rot_diff = (
                                180
                                if ang_int == 0
                                else (
                                    0
                                    if ang_int in [180, 179, 178]
                                    else (
                                        -data.angulo_xy
                                        if ang_int in [-90, 89, 90, -89]
                                        else 0
                                    )
                                )
                            )
                            mr = AllplanGeo.Matrix3D()
                            mr.Rotation(
                                AllplanGeo.Line3D(0, 0, 0, 0, 0, 1),
                                AllplanGeo.Angle.FromDeg(rot_diff),
                            )
                            brep = AllplanGeo.Transform(brep, mr)
                            padding = 60
                            ltc = AllplanGeo.CalcLength(
                                AllplanGeo.Line3D(
                                    (
                                        data_list[0]["segment"].data.start
                                        if data_list[0].get("type", "")
                                        not in TIPOS_ACCESORIOS
                                        else start_point
                                    ),
                                    punto_final_real,
                                )
                            )
                            if ang_int in [0, 180, 179, 178]:
                                factor = -1 if ang_int in [180, 179, 178] else 1
                                nuevo_brep = AllplanGeo.Move(
                                    brep,
                                    AllplanGeo.Vector3D(
                                        punto_final_real.X + (padding * factor),
                                        punto_final_real.Y + move_offset,
                                        punto_final_real.Z - cdz + 11,
                                    ),
                                )
                            else:
                                factor = -1 if ang_int in [-90, -89] else 1
                                nuevo_brep = AllplanGeo.Move(
                                    brep,
                                    AllplanGeo.Vector3D(
                                        punto_final_real.X + move_offset,
                                        punto_final_real.Y + (padding * factor),
                                        punto_final_real.Z - cdz + 11,
                                    ),
                                )
                        else:
                            nuevo_brep = AllplanGeo.Move(
                                brep, AllplanGeo.Vector3D(pmx, pmy, pmz)
                            )

                        elementos_transformados.append(
                            {
                                "index": i,
                                "element_type": tipo_str,
                                "element": AllplanBasisElements.ModelElement3D(
                                    prop, nuevo_brep
                                ),
                            }
                        )

                    # ──────────────────────────────────────────────────────────
                    # CASO 3 – TUBOS DINÁMICOS (recto, inclinado, vertical)
                    # ──────────────────────────────────────────────────────────
                    else:
                        nx = sum(v.X for v in verts) / len(verts) if verts else 0
                        ny = sum(v.Y for v in verts) / len(verts) if verts else 0
                        nz = sum(v.Z for v in verts) / len(verts) if verts else 0
                        brep = AllplanGeo.Move(brep, AllplanGeo.Vector3D(-nx, -ny, -nz))

                        long_xy_seg = getattr(data, "longitud_xy", 0.0)

                        # ─── ROT_XY ───────────────────────────────────────────
                        # Segmento CON componente XY → usa su propio angulo_xy
                        # Segmento SIN componente XY → hereda del horizontal más cercano
                        # effective_rot_xy[i] ya tiene la lógica correcta del pre-procesado
                        rot_xy = effective_rot_xy[i]

                        # ─── ROT_PITCH ────────────────────────────────────────
                        # Para segmentos con XY: inclinación relativa al plano XY
                        # Para verticales puros: atan2(dz, 0) = ±90°
                        rot_pitch = math.degrees(math.atan2(data.delta_z, long_xy_seg))

                        if debug:
                            tiene_xy = long_xy_seg >= UMBRAL_XY
                            print(
                                f"  {item_name} ({'XY-propio' if tiene_xy else 'hereda'}) "
                                f"rot_xy={rot_xy:.2f}° | rot_pitch={rot_pitch:.2f}° | "
                                f"long_xy={long_xy_seg:.2f}"
                            )

                        # Roll (si el segmento tiene rotación axial definida)
                        if abs(getattr(data, "angulo_rotacion", 0)) > 0.001:
                            m = AllplanGeo.Matrix3D()
                            m.Rotation(
                                AllplanGeo.Line3D(0, 0, 0, 1, 0, 0),
                                AllplanGeo.Angle.FromDeg(data.angulo_rotacion),
                            )
                            brep = AllplanGeo.Transform(brep, m)

                        # Yaw (planta) — aplica SIEMPRE el ángulo efectivo
                        m = AllplanGeo.Matrix3D()
                        m.Rotation(
                            AllplanGeo.Line3D(0, 0, 0, 0, 0, 1),
                            AllplanGeo.Angle.FromDeg(rot_xy),
                        )
                        brep = AllplanGeo.Transform(brep, m)

                        # Pitch (elevación/descenso) — solo si hay componente Z
                        # El eje de rotación usa rot_xy efectivo, garantizando que
                        # el pitch siempre ocurra en el plano XZ o YZ correcto
                        # (el plano definido por la dirección horizontal del conducto)
                        if abs(rot_pitch) > 0.001:
                            rad_xy = math.radians(rot_xy)
                            # Eje perpendicular a la dirección horizontal del conducto
                            # = gira 90° en XY respecto a la dirección de avance
                            axis = AllplanGeo.Line3D(
                                0,
                                0,
                                0,
                                math.sin(rad_xy),  #  sin(rot_xy)
                                -math.cos(rad_xy),  # -cos(rot_xy)
                                0,
                            )
                            m = AllplanGeo.Matrix3D()
                            m.Rotation(axis, AllplanGeo.Angle.FromDeg(rot_pitch))
                            brep = AllplanGeo.Transform(brep, m)

                        # Centro del segmento ajustado por extensiones
                        desplazamiento_neto = (longitud_original / 2.0) + (
                            (extension_final - extension_inicio) / 2.0
                        )
                        mid_x = start_point.X + vec_curr.X * desplazamiento_neto
                        mid_y = start_point.Y + vec_curr.Y * desplazamiento_neto
                        mid_z = start_point.Z + vec_curr.Z * desplazamiento_neto

                        nuevo_brep = AllplanGeo.Move(
                            brep, AllplanGeo.Vector3D(mid_x, mid_y, mid_z)
                        )
                        segment_brep = {
                            "index": i,
                            "element_type": tipo_str,
                            "element": AllplanBasisElements.ModelElement3D(
                                prop, nuevo_brep
                            ),
                        }
                        elementos_transformados.append(segment_brep)

            except Exception as ex:
                if debug:
                    print(f"ERROR CRÍTICO en elemento {i} ({tipo_str}): {ex}")

        if debug:
            print(f"\n{'='*70}")
            print(f"COMPLETADO: {len(elementos_transformados)} elementos procesados")
            print(f"{'='*70}\n")

        return elementos_transformados

    def center_and_connect_models_v4(
        self,
        data_list,
        conducto_width=75,
        color=None,
        point_role=None,
        point_side=None,
        debug=True,
    ):
        """
        Versión robusta que ignora elementos intermedios (manguitos) para el cálculo
        de ángulos y asegura que todos los objetos se generen.

        CAMBIO v3: Se agrega pre-procesado de rot_xy efectivo para cada segmento.
        Los segmentos verticales (longitud_xy ≈ 0) y los que cambian de plano
        heredan la orientación XY del segmento anterior o siguiente más cercano,
        evitando que rot_xy caiga a 0 por defecto.
        """
        elementos_transformados = []
        last_real_end_point = None
        last_segment = None

        def get_dot_product(v1, v2):
            if not v1 or not v2:
                return 1.0
            return v1.X * v2.X + v1.Y * v2.Y + v1.Z * v2.Z

        def same_direction(seg1, seg2, tol_deg=1):
            if not seg1 or not seg1:
                return False
            a1 = seg1.data.angulo_xy
            a2 = seg2.data.angulo_xy
            diff = abs((a1 - a2 + 180) % 360 - 180)
            return diff < tol_deg

        # CONSTANTES
        CONDUCTO_WIDTH = conducto_width
        TIPOS_ACCESORIOS = ["manguito", "codo_45", "codo_90", "conexion", "difusor"]

        if debug:
            print(f"\n{'#'*70}")
            print(f"# PROCESANDO DATA LIST: {len(data_list)}")
            print(f"{'#'*70}")

        # =========================================================================
        # PRE-PROCESADO: Calcular effective_rot_xy para cada elemento
        #
        # Regla:
        #   - Si el segmento tiene componente XY (longitud_xy >= umbral): usa data.angulo_xy
        #   - Si es vertical puro o sin componente XY: busca hacia atrás el XY más
        #     cercano; si no lo hay, busca hacia adelante.
        #   - Para accesorios (manguitos, codos, etc.) se aplica la misma lógica.
        #
        # Esto resuelve tanto XY→ZX/ZY como ZX/ZY→XY en una sola pasada doble.
        # =========================================================================
        UMBRAL_XY = 0.1  # mm — por debajo de esto se considera sin componente XY

        raw_rot_xy = []  # None si el segmento no tiene orientación XY propia
        for item in data_list:
            seg = item.get("segment")
            if not seg:
                raw_rot_xy.append(None)
                continue
            d = seg.data
            long_xy = getattr(d, "longitud_xy", 0.0)
            if long_xy >= UMBRAL_XY:
                raw_rot_xy.append(d.angulo_xy)
            else:
                raw_rot_xy.append(None)  # vertical puro → hereda de vecinos

        # Primer sub-pase: rellena con el vecino anterior conocido
        last_known = None
        for idx in range(len(raw_rot_xy)):
            if raw_rot_xy[idx] is not None:
                last_known = raw_rot_xy[idx]
            else:
                raw_rot_xy[idx] = last_known  # puede quedar None si es el primero

        # Segundo sub-pase: rellena con el vecino siguiente (para los que aún son None)
        last_known = None
        for idx in range(len(raw_rot_xy) - 1, -1, -1):
            if raw_rot_xy[idx] is not None:
                last_known = raw_rot_xy[idx]
            else:
                raw_rot_xy[idx] = last_known  # puede quedar None si no hay ninguno

        # Convertir None residuales a 0.0 (caso extremo: lista sin segmentos XY)
        effective_rot_xy = [v if v is not None else 0.0 for v in raw_rot_xy]

        if debug:
            print(f"\n--- effective_rot_xy pre-calculado ---")
            for idx, item in enumerate(data_list):
                seg = item.get("segment")
                name = getattr(seg, "name", f"Seg_{idx}") if seg else f"Item_{idx}"
                orig = (
                    getattr(getattr(seg, "data", None), "angulo_xy", "?")
                    if seg
                    else "?"
                )
                print(
                    f"  [{idx}] {name}: angulo_xy_original={orig} → effective_rot_xy={effective_rot_xy[idx]}"
                )
            print()
        # =========================================================================
        # FIN PRE-PROCESADO
        # =========================================================================

        for i, item in enumerate(data_list):
            try:
                segment = item.get("segment")
                if not segment:
                    continue
                data = segment.data
                item_name = getattr(segment, "name", f"Segment_{i}")
                start_point = getattr(data, "start", None)
                if start_point is None:
                    continue
                tipo_str = item.get("type", "")

                is_dinamic = tipo_str not in TIPOS_ACCESORIOS

                # 2. OBTENER VECTOR ACTUAL
                vec_curr = getattr(data, "vector_normalizado", None)
                if vec_curr is None:
                    vec_curr = AllplanGeo.Vector3D(
                        getattr(data, "delta_x", 0),
                        getattr(data, "delta_y", 0),
                        getattr(data, "delta_z", 0),
                    )
                    vec_curr.Normalize()

                # CONTINUIDAD ENTRE SEGMENTOS RECTOS
                if (
                    last_real_end_point is not None
                    and last_segment is not None
                    and same_direction(last_segment, segment)
                ):
                    start_point = last_real_end_point

                extension_inicio = 0.0
                extension_final = 0.0
                desplazamiento_neto = 0.0

                # 3. LÓGICA DE CONEXIÓN (Solo para tubos dinámicos)
                if is_dinamic:
                    MIN_ANGLE_RAD = 0.0175
                    MAX_ANGLE_RAD = math.pi - 0.0175

                    # --- VECINO ANTERIOR ---
                    if i > 0:
                        prev_idx = i - 1
                        prev_item = data_list[prev_idx]
                        prev_tipo_raw = prev_item.get("type", "")
                        prev_tipo_str = (
                            prev_tipo_raw
                            if isinstance(prev_tipo_raw, str)
                            else (prev_tipo_raw[0] if len(prev_tipo_raw) > 0 else "")
                        )

                        if prev_tipo_str == "manguito":
                            extension_final = 0.0
                            if debug:
                                print(
                                    f"  {item_name} - Manguito anterior detectado, ext inicio = 0"
                                )
                        else:
                            p_data = prev_item["segment"].data
                            vec_prev = AllplanGeo.Vector3D(
                                p_data.delta_x, p_data.delta_y, p_data.delta_z
                            )
                            vec_prev.Normalize()
                            dot = max(
                                -1.0, min(1.0, get_dot_product(vec_prev, vec_curr))
                            )
                            angle_rad = math.acos(dot)
                            if MIN_ANGLE_RAD < angle_rad < MAX_ANGLE_RAD:
                                extension_inicio = (CONDUCTO_WIDTH / 2.0) * math.tan(
                                    angle_rad / 2.0
                                )
                                if debug:
                                    print(
                                        f"  {item_name} - Ext inicio: {math.degrees(angle_rad):.1f}° → {extension_inicio:.2f}mm"
                                    )
                            else:
                                extension_inicio = 0.0
                                if debug:
                                    print(
                                        f"  {item_name} - Ángulo insignificante ({math.degrees(angle_rad):.1f}°), ext inicio = 0"
                                    )

                    # --- VECINO SIGUIENTE ---
                    if i < len(data_list) - 1:
                        next_idx = i + 1
                        next_item = data_list[next_idx]
                        next_tipo_raw = next_item.get("type", "")
                        next_tipo_str = (
                            next_tipo_raw
                            if isinstance(next_tipo_raw, str)
                            else (next_tipo_raw[0] if len(next_tipo_raw) > 0 else "")
                        )

                        if next_tipo_str == "manguito":
                            extension_inicio = 0.0
                            if debug:
                                print(
                                    f"  {item_name} - Manguito siguiente detectado, ext final = 0"
                                )
                        else:
                            n_data = next_item["segment"].data
                            vec_next = AllplanGeo.Vector3D(
                                n_data.delta_x, n_data.delta_y, n_data.delta_z
                            )
                            vec_next.Normalize()
                            dot = max(
                                -1.0, min(1.0, get_dot_product(vec_curr, vec_next))
                            )
                            angle_rad = math.acos(dot)
                            if MIN_ANGLE_RAD < angle_rad < MAX_ANGLE_RAD:
                                extension_final = (CONDUCTO_WIDTH / 2.0) * math.tan(
                                    angle_rad / 2.0
                                )
                                if debug:
                                    print(
                                        f"  {item_name} - Ext final: {math.degrees(angle_rad):.1f}° → {extension_final:.2f}mm"
                                    )
                            else:
                                extension_final = 0.0
                                if debug:
                                    print(
                                        f"  {item_name} - Ángulo insignificante ({math.degrees(angle_rad):.1f}°), ext final = 0"
                                    )

                # 4. GEOMETRÍA FINAL DEL SEGMENTO
                longitud_original = getattr(data, "longitud_3d", 0.0)
                longitud_total = longitud_original + extension_inicio + extension_final

                if debug and is_dinamic:
                    print(f"\n{item_name}")
                    print(f"  Long original: {longitud_original}")
                    print(
                        f"  Ext inicio: {extension_inicio}, Ext final: {extension_final}"
                    )
                    print(f"  Long total: {longitud_total}")

                # 5. PROCESAR BREPS
                lista_elem_3d_modified = []
                list_elem_3d = item.get("element3d", [])

                if is_dinamic:
                    for elem_3d in list_elem_3d:
                        brep_ajustado = self.modificar_dimensiones_brep(
                            elem_3d, longitud_total
                        )
                        lista_elem_3d_modified.append(brep_ajustado)
                else:
                    lista_elem_3d_modified = list_elem_3d

                conn_type_list = []
                segment_brep = None
                for e, elem_3d in enumerate(lista_elem_3d_modified):
                    prop = elem_3d.GetCommonProperties()
                    if is_dinamic and color:
                        prop.Color = color

                    brep = elem_3d.GetGeometryObject()
                    _, vertices = brep.GetVertices()

                    punto_medio_x = (start_point.X + data.end.X) / 2.0
                    punto_medio_y = (start_point.Y + data.end.Y) / 2.0
                    punto_medio_z = (start_point.Z + data.end.Z) / 2.0

                    centro_brep_geom = AllplanGeo.Point3D(
                        punto_medio_x, punto_medio_y, punto_medio_z
                    )
                    if vertices:
                        nx = sum(v.X for v in vertices) / len(vertices)
                        ny = sum(v.Y for v in vertices) / len(vertices)
                        nz = sum(v.Z for v in vertices) / len(vertices)
                        centro_brep_geom = AllplanGeo.Point3D(nx, ny, nz)

                    nuevo_brep = None

                    # --- CASO 1: MANGUITOS ---
                    if tipo_str == "manguito":
                        segment_brep = None
                        if e == 0:
                            _, vertices_principal = brep.GetVertices()
                            if vertices_principal:
                                centro_manguito_x = sum(
                                    v.X for v in vertices_principal
                                ) / len(vertices_principal)
                                centro_manguito_y = sum(
                                    v.Y for v in vertices_principal
                                ) / len(vertices_principal)
                                centro_manguito_z = sum(
                                    v.Z for v in vertices_principal
                                ) / len(vertices_principal)
                            else:
                                centro_manguito_x = centro_brep_geom.X
                                centro_manguito_y = centro_brep_geom.Y
                                centro_manguito_z = centro_brep_geom.Z
                            if not hasattr(self, "_temp_manguito_center"):
                                self._temp_manguito_center = {}
                            self._temp_manguito_center[i] = (
                                centro_manguito_x,
                                centro_manguito_y,
                                centro_manguito_z,
                            )
                        else:
                            centro_manguito_x, centro_manguito_y, centro_manguito_z = (
                                self._temp_manguito_center.get(i, (0, 0, 0))
                            )

                        brep = AllplanGeo.Move(
                            brep,
                            AllplanGeo.Vector3D(
                                -centro_manguito_x + (longitud_original / 2.0),
                                -centro_manguito_y,
                                -centro_manguito_z,
                            ),
                        )

                        # *** CAMBIO: usar effective_rot_xy en lugar de data.angulo_xy raw ***
                        rot_xy = effective_rot_xy[i]
                        rot_pitch = math.degrees(
                            math.atan2(data.delta_z, getattr(data, "longitud_xy", 0))
                        )

                        if debug:
                            long_xy_val = getattr(data, "longitud_xy", 0)
                            print(
                                f"  {item_name} [manguito] rot_xy={rot_xy:.2f}° (longitud_xy={long_xy_val:.3f}) rot_pitch={rot_pitch:.2f}°"
                            )

                        if abs(getattr(data, "angulo_rotacion", 0)) > 0.1:
                            m = AllplanGeo.Matrix3D()
                            m.Rotation(
                                AllplanGeo.Line3D(0, 0, 0, 1, 0, 0),
                                AllplanGeo.Angle.FromDeg(data.angulo_rotacion),
                            )
                            brep = AllplanGeo.Transform(brep, m)

                        m = AllplanGeo.Matrix3D()
                        m.Rotation(
                            AllplanGeo.Line3D(0, 0, 0, 0, 0, 1),
                            AllplanGeo.Angle.FromDeg(rot_xy),
                        )
                        brep = AllplanGeo.Transform(brep, m)

                        if abs(rot_pitch) > 0.1:
                            rad_xy = math.radians(rot_xy)
                            axis = AllplanGeo.Line3D(
                                0, 0, 0, math.sin(rad_xy), -math.cos(rad_xy), 0
                            )
                            m = AllplanGeo.Matrix3D()
                            m.Rotation(axis, AllplanGeo.Angle.FromDeg(rot_pitch))
                            brep = AllplanGeo.Transform(brep, m)

                        nuevo_brep = AllplanGeo.Move(
                            brep,
                            AllplanGeo.Vector3D(
                                punto_medio_x, punto_medio_y, punto_medio_z
                            ),
                        )
                        elementos_transformados.append(
                            {
                                "index": i,
                                "element_type": tipo_str,
                                "element": AllplanBasisElements.ModelElement3D(
                                    prop, nuevo_brep
                                ),
                            }
                        )

                    # --- CASO 2: DIFUSORES ---
                    elif tipo_str == "difusor":
                        move_offset = 0
                        if point_side == 0:
                            move_offset = CONDUCTO_WIDTH / 2
                        elif point_side == 2:
                            move_offset = -CONDUCTO_WIDTH / 2

                        ang_int = int(data.angulo_xy)

                        if debug:
                            print(
                                f"  start_point: ({start_point.X:.1f}, {start_point.Y:.1f}, {start_point.Z:.1f})"
                            )

                        if point_role == "inicial":
                            punto_inicio_real = start_point
                            for j in range(i + 1, len(data_list)):
                                next_item = data_list[j]
                                next_tipo = next_item.get("type", "")
                                next_tipo_str = (
                                    next_tipo
                                    if isinstance(next_tipo, str)
                                    else (next_tipo[0] if len(next_tipo) > 0 else "")
                                )
                                if next_tipo_str not in TIPOS_ACCESORIOS:
                                    next_data = next_item["segment"].data
                                    punto_inicio_real = getattr(
                                        next_data, "start", start_point
                                    )
                                    if debug:
                                        print(
                                            f"  Usando inicio del segmento {j}: ({punto_inicio_real.X:.1f}, {punto_inicio_real.Y:.1f}, {punto_inicio_real.Z:.1f})"
                                        )
                                    break

                            _, vertices_dif = brep.GetVertices()
                            if vertices_dif:
                                centro_dif_x = sum(v.X for v in vertices_dif) / len(
                                    vertices_dif
                                )
                                centro_dif_y = sum(v.Y for v in vertices_dif) / len(
                                    vertices_dif
                                )
                                centro_dif_z = sum(v.Z for v in vertices_dif) / len(
                                    vertices_dif
                                )
                                brep = AllplanGeo.Move(
                                    brep,
                                    AllplanGeo.Vector3D(
                                        -centro_dif_x, -centro_dif_y, -centro_dif_z
                                    ),
                                )

                            if ang_int != 0:
                                matriz_rot = AllplanGeo.Matrix3D()
                                matriz_rot.Rotation(
                                    AllplanGeo.Line3D(0, 0, 0, 0, 0, 1),
                                    AllplanGeo.Angle.FromDeg(data.angulo_xy),
                                )
                                brep = AllplanGeo.Transform(brep, matriz_rot)

                            w_cubo = -60 if ang_int in [0, 90, 89] else 60
                            offset_x = punto_inicio_real.X + w_cubo
                            offset_y = punto_inicio_real.Y + (
                                move_offset if ang_int in [0, 180, 178, 179] else w_cubo
                            )

                            nuevo_brep = AllplanGeo.Move(
                                brep,
                                AllplanGeo.Vector3D(
                                    offset_x, offset_y - 1, punto_inicio_real.Z + 11
                                ),
                            )

                            if debug:
                                print(
                                    f"  Posición final difusor: ({offset_x:.1f}, {offset_y:.1f}, {punto_inicio_real.Z + 11:.1f})"
                                )

                        elif point_role == "final":
                            punto_final_real = (
                                data.end
                                if hasattr(data, "end")
                                else AllplanGeo.Point3D(
                                    start_point.X + data.delta_x,
                                    start_point.Y + data.delta_y,
                                    start_point.Z + data.delta_z,
                                )
                            )

                            if i < len(data_list) - 1:
                                for j in range(len(data_list) - 1, i, -1):
                                    next_item = data_list[j]
                                    next_tipo = next_item.get("type", "")
                                    next_tipo_str = (
                                        next_tipo
                                        if isinstance(next_tipo, str)
                                        else (
                                            next_tipo[0] if len(next_tipo) > 0 else ""
                                        )
                                    )
                                    if next_tipo_str not in TIPOS_ACCESORIOS:
                                        next_data = next_item["segment"].data
                                        punto_final_real = getattr(
                                            next_data, "end", punto_final_real
                                        )
                                        if debug:
                                            print(
                                                f"  Usando final del segmento {j}: ({punto_final_real.X:.1f}, {punto_final_real.Y:.1f}, {punto_final_real.Z:.1f})"
                                            )
                                        break

                            _, vertices_dif = brep.GetVertices()
                            if vertices_dif:
                                centro_dif_x = sum(v.X for v in vertices_dif) / len(
                                    vertices_dif
                                )
                                centro_dif_y = sum(v.Y for v in vertices_dif) / len(
                                    vertices_dif
                                )
                                centro_dif_z = sum(v.Z for v in vertices_dif) / len(
                                    vertices_dif
                                )
                                brep = AllplanGeo.Move(
                                    brep,
                                    AllplanGeo.Vector3D(
                                        -centro_dif_x, -centro_dif_y, -centro_dif_z
                                    ),
                                )
                            else:
                                centro_dif_z = 0

                            rot_diff = 0
                            if ang_int == 0:
                                rot_diff = 180
                            elif ang_int in [180, 179, 178]:
                                rot_diff = 0
                            elif ang_int in [-90, 89, 90, -89]:
                                rot_diff = -data.angulo_xy

                            matriz_rot = AllplanGeo.Matrix3D()
                            matriz_rot.Rotation(
                                AllplanGeo.Line3D(0, 0, 0, 0, 0, 1),
                                AllplanGeo.Angle.FromDeg(rot_diff),
                            )
                            brep = AllplanGeo.Transform(brep, matriz_rot)

                            es_horizontal_pura = ang_int in [0, 180, 179, 178]
                            padding = 60

                            long_total_conducto = AllplanGeo.CalcLength(
                                AllplanGeo.Line3D(
                                    (
                                        data_list[0]["segment"].data.start
                                        if data_list[0].get("type", "")
                                        not in TIPOS_ACCESORIOS
                                        else start_point
                                    ),
                                    punto_final_real,
                                )
                            )

                            if es_horizontal_pura:
                                factor = -1 if ang_int in [180, 179, 178] else 1
                                w_cubo = (long_total_conducto + padding) * factor
                                if ang_int in [180, 179, 178]:
                                    w_cubo = -long_total_conducto - padding
                                nuevo_brep = AllplanGeo.Move(
                                    brep,
                                    AllplanGeo.Vector3D(
                                        punto_final_real.X + (padding * factor),
                                        punto_final_real.Y + move_offset,
                                        punto_final_real.Z - centro_dif_z + 11,
                                    ),
                                )
                            else:
                                factor = -1 if ang_int in [-90, -89] else 1
                                w_cubo = (long_total_conducto + padding) * factor
                                nuevo_brep = AllplanGeo.Move(
                                    brep,
                                    AllplanGeo.Vector3D(
                                        punto_final_real.X + move_offset,
                                        punto_final_real.Y + (padding * factor),
                                        punto_final_real.Z - centro_dif_z + 11,
                                    ),
                                )
                        else:
                            nuevo_brep = AllplanGeo.Move(
                                brep,
                                AllplanGeo.Vector3D(
                                    punto_medio_x, punto_medio_y, punto_medio_z
                                ),
                            )

                        elementos_transformados.append(
                            {
                                "index": i,
                                "element_type": tipo_str,
                                "element": AllplanBasisElements.ModelElement3D(
                                    prop, nuevo_brep
                                ),
                            }
                        )

                    # --- CASO 3: TUBOS DINÁMICOS Y RESTO ---
                    else:
                        nx = (
                            sum(v.X for v in vertices) / len(vertices)
                            if vertices
                            else 0
                        )
                        ny = (
                            sum(v.Y for v in vertices) / len(vertices)
                            if vertices
                            else 0
                        )
                        nz = (
                            sum(v.Z for v in vertices) / len(vertices)
                            if vertices
                            else 0
                        )
                        brep = AllplanGeo.Move(brep, AllplanGeo.Vector3D(-nx, -ny, -nz))

                        # *** CAMBIO PRINCIPAL: usar effective_rot_xy en lugar de data.angulo_xy raw ***
                        # Antes:  rot_xy = 0.0 if getattr(data, 'longitud_xy', 0) < 0.1 else data.angulo_xy
                        # Ahora:  siempre se usa el valor pre-calculado que hereda del vecino XY
                        rot_xy = effective_rot_xy[i]
                        rot_pitch = math.degrees(
                            math.atan2(data.delta_z, getattr(data, "longitud_xy", 0))
                        )

                        if debug:
                            long_xy_val = getattr(data, "longitud_xy", 0)
                            print(
                                f"  {item_name} rot_xy={rot_xy:.2f}° (longitud_xy={long_xy_val:.3f}) rot_pitch={rot_pitch:.2f}°"
                            )

                        # Roll
                        if abs(getattr(data, "angulo_rotacion", 0)) > 0.001:
                            m = AllplanGeo.Matrix3D()
                            m.Rotation(
                                AllplanGeo.Line3D(0, 0, 0, 1, 0, 0),
                                AllplanGeo.Angle.FromDeg(data.angulo_rotacion),
                            )
                            brep = AllplanGeo.Transform(brep, m)

                        # Yaw (Planta) — usa el ángulo efectivo (heredado si es vertical)
                        m = AllplanGeo.Matrix3D()
                        m.Rotation(
                            AllplanGeo.Line3D(0, 0, 0, 0, 0, 1),
                            AllplanGeo.Angle.FromDeg(rot_xy),
                        )
                        brep = AllplanGeo.Transform(brep, m)

                        # Pitch (Elevación) — el eje de rotación usa rot_xy efectivo para
                        # que el pitch se aplique en el plano correcto aun cuando longitud_xy=0
                        if abs(rot_pitch) > 0.001:
                            rad_xy = math.radians(rot_xy)
                            axis = AllplanGeo.Line3D(
                                0, 0, 0, math.sin(rad_xy), -math.cos(rad_xy), 0
                            )
                            m = AllplanGeo.Matrix3D()
                            m.Rotation(axis, AllplanGeo.Angle.FromDeg(rot_pitch))
                            brep = AllplanGeo.Transform(brep, m)

                        desplazamiento_neto = (longitud_original / 2.0) + (
                            (extension_final - extension_inicio) / 2.0
                        )

                        mid_x = start_point.X + vec_curr.X * desplazamiento_neto
                        mid_y = start_point.Y + vec_curr.Y * desplazamiento_neto
                        mid_z = start_point.Z + vec_curr.Z * desplazamiento_neto

                        nuevo_brep = AllplanGeo.Move(
                            brep, AllplanGeo.Vector3D(mid_x, mid_y, mid_z)
                        )
                        segment_brep = {
                            "index": i,
                            "element_type": tipo_str,
                            "element": AllplanBasisElements.ModelElement3D(
                                prop, nuevo_brep
                            ),
                        }
                        elementos_transformados.append(segment_brep)

            except Exception as e:
                if debug:
                    print(f"ERROR CRÍTICO en elemento {i} ({tipo_str}): {e}")

        if debug:
            print(f"\n{'='*70}")
            print(f"COMPLETADO: {len(elementos_transformados)} elementos procesados")
            print(f"{'='*70}\n")

        return elementos_transformados

    def center_and_connect_models_v2(
        self,
        data_list,
        conducto_width=75,
        color=None,
        point_role=None,
        point_side=None,
        debug=True,
    ):
        """
        Versión robusta que ignora elementos intermedios (manguitos) para el cálculo
        de ángulos y asegura que todos los objetos se generen.
        """
        elementos_transformados = []
        last_real_end_point = None
        last_segment = None

        def get_dot_product(v1, v2):
            if not v1 or not v2:
                return 1.0
            return v1.X * v2.X + v1.Y * v2.Y + v1.Z * v2.Z

        def same_direction(seg1, seg2, tol_deg=1):
            if not seg1 or not seg1:
                return False

            a1 = seg1.data.angulo_xy
            a2 = seg2.data.angulo_xy

            diff = abs((a1 - a2 + 180) % 360 - 180)
            return diff < tol_deg

        # CONSTANTES
        CONDUCTO_WIDTH = conducto_width
        TIPOS_ACCESORIOS = ["manguito", "codo_45", "codo_90", "conexion", "difusor"]

        if debug:
            print(f"\n{'#'*70}")
            print(f"# PROCESANDO DATA LIST: {len(data_list)}")
            print(f"{'#'*70}")

        for i, item in enumerate(data_list):
            try:
                segment = item.get("segment")
                if not segment:
                    continue
                data = segment.data
                item_name = getattr(segment, "name", f"Segment_{i}")
                start_point = getattr(data, "start", None)
                if start_point is None:
                    continue
                tipo_str = item.get("type", "")

                # 1. IDENTIFICAR TIPO
                # tipo_raw = item.get('type', "")
                # tipo_raw if isinstance(tipo_raw, str) else (tipo_raw[0] if len(tipo_raw) > 0 else tipo_raw)

                # NOTA: Ya no saltamos los manguitos, los procesamos
                is_dinamic = tipo_str not in TIPOS_ACCESORIOS

                # 2. OBTENER VECTOR ACTUAL
                vec_curr = getattr(data, "vector_normalizado", None)
                if vec_curr is None:
                    vec_curr = AllplanGeo.Vector3D(
                        getattr(data, "delta_x", 0),
                        getattr(data, "delta_y", 0),
                        getattr(data, "delta_z", 0),
                    )
                    vec_curr.Normalize()

                # CONTINUIDAD ENTRE SEGMENTOS RECTOS
                if (
                    last_real_end_point is not None
                    and last_segment is not None
                    and same_direction(last_segment, segment)
                ):
                    start_point = last_real_end_point

                extension_inicio = 0.0
                extension_final = 0.0
                desplazamiento_neto = 0.0

                # 3. LÓGICA DE CONEXIÓN (Solo para tubos dinámicos)
                # ── Extensiones en uniones (solo tubos dinámicos) ────────────────
                if is_dinamic:
                    vec_curr = data.vector_normalizado
                    SAFE_MAX_ANGLE = math.radians(175.0)

                    # Tolerancia para detectar 135° (por si hay decimales como 134.99)
                    ANGULO_ESPECIAL_RAD = math.radians(135.0)
                    TOLERANCIA = math.radians(1.0)

                    # 1. Extensión al INICIO
                    extension_inicio = 0.0
                    if i > 0:
                        prev_item = data_list[i - 1]
                        if prev_item.get("type") != "manguito":
                            vec_prev = prev_item["segment"].data.vector_normalizado
                            dot = max(
                                -1.0, min(1.0, get_dot_product(vec_prev, vec_curr))
                            )
                            a_rad = math.acos(dot)

                            if 0.0001 < a_rad < SAFE_MAX_ANGLE:
                                # --- IF DISTINTO PARA 135° ---
                                if abs(a_rad - ANGULO_ESPECIAL_RAD) < TOLERANCIA:
                                    # En el inicio del segundo segmento del codo, recortamos
                                    extension_inicio = -15.4
                                    if debug:
                                        print(
                                            f"  {item_name} - Inicio: Detectado 135°, aplicando recorte -22.5"
                                        )
                                else:
                                    # Lógica inicial (Tangente)
                                    extension_teorica = (
                                        CONDUCTO_WIDTH / 2.0
                                    ) * math.tan(a_rad / 2.0)
                                    extension_inicio = extension_teorica

                    # 2. Extensión al FINAL
                    extension_final = 0.0
                    if i < len(data_list) - 1:
                        next_item = data_list[i + 1]
                        if next_item.get("type") != "manguito":
                            vec_next = next_item["segment"].data.vector_normalizado
                            dot = max(
                                -1.0, min(1.0, get_dot_product(vec_curr, vec_next))
                            )
                            a_rad = math.acos(dot)

                            if 0.0001 < a_rad < SAFE_MAX_ANGLE:
                                # --- IF DISTINTO PARA 135° ---
                                if abs(a_rad - ANGULO_ESPECIAL_RAD) < TOLERANCIA:
                                    # En el final del primer segmento del codo, alargamos
                                    extension_final = 15.4
                                    if debug:
                                        print(
                                            f"  {item_name} - Final: Detectado 135°, aplicando alargue 22.5"
                                        )
                                else:
                                    # Lógica inicial (Tangente)
                                    extension_teorica = (
                                        CONDUCTO_WIDTH / 2.0
                                    ) * math.tan(a_rad / 2.0)
                                    extension_final = extension_teorica

                    # 3. Aplicación de longitud
                    longitud_original = getattr(data, "longitud_3d", 0.0)
                    longitud_total = (
                        longitud_original + extension_inicio + extension_final
                    )

                if debug and is_dinamic:
                    print(f"\n{item_name}")
                    print(f"  Long original: {longitud_original}")
                    print(
                        f"  Ext inicio: {extension_inicio}, Ext final: {extension_final}"
                    )
                    print(f"  Long total: {longitud_total}")

                # 5. PROCESAR BREPS
                lista_elem_3d_modified = []
                list_elem_3d = item.get("element3d", [])

                if is_dinamic:
                    for elem_3d in list_elem_3d:
                        brep_ajustado = None
                        # Asumimos que esta función estira el BREP simétricamente desde el centro
                        brep_ajustado = self.modificar_dimensiones_brep(
                            elem_3d, longitud_total
                        )
                        lista_elem_3d_modified.append(brep_ajustado)
                else:
                    lista_elem_3d_modified = list_elem_3d

                # Procesar cada elemento 3D
                conn_type_list = []
                segment_brep = None
                for e, elem_3d in enumerate(lista_elem_3d_modified):
                    prop = elem_3d.GetCommonProperties()
                    if is_dinamic and color:
                        prop.Color = color

                    brep = elem_3d.GetGeometryObject()
                    _, vertices = brep.GetVertices()  # type: ignore

                    # Cálculo de centro auxiliar para manguitos
                    punto_medio_x = (start_point.X + data.end.X) / 2.0
                    punto_medio_y = (start_point.Y + data.end.Y) / 2.0
                    punto_medio_z = (start_point.Z + data.end.Z) / 2.0

                    centro_brep_geom = AllplanGeo.Point3D(
                        punto_medio_x, punto_medio_y, punto_medio_z
                    )
                    if vertices:
                        nx = sum(v.X for v in vertices) / len(vertices)
                        ny = sum(v.Y for v in vertices) / len(vertices)
                        nz = sum(v.Z for v in vertices) / len(vertices)
                        centro_brep_geom = AllplanGeo.Point3D(nx, ny, nz)

                    nuevo_brep = None

                    # --- CASO 1: MANGUITOS ---

                    if tipo_str == "manguito":
                        segment_brep = None
                        if (
                            e == 0
                        ):  # Solo calculamos centro y transformaciones con el primer BREP
                            # Recalcular el centro del BREP principal (el primero)
                            _, vertices_principal = brep.GetVertices()  # type: ignore
                            if vertices_principal:
                                centro_manguito_x = sum(
                                    v.X for v in vertices_principal
                                ) / len(vertices_principal)
                                centro_manguito_y = sum(
                                    v.Y for v in vertices_principal
                                ) / len(vertices_principal)
                                centro_manguito_z = sum(
                                    v.Z for v in vertices_principal
                                ) / len(vertices_principal)
                            else:
                                centro_manguito_x = centro_brep_geom.X
                                centro_manguito_y = centro_brep_geom.Y
                                centro_manguito_z = centro_brep_geom.Z

                            # Guardar el centro para usar en todos los BREPs del manguito
                            if not hasattr(self, "_temp_manguito_center"):
                                self._temp_manguito_center = {}
                            self._temp_manguito_center[i] = (
                                centro_manguito_x,
                                centro_manguito_y,
                                centro_manguito_z,
                            )
                        else:
                            # Usar el centro calculado del primer BREP
                            centro_manguito_x, centro_manguito_y, centro_manguito_z = (
                                self._temp_manguito_center.get(i, (0, 0, 0))
                            )

                        # 1. Resetear al origen usando el centro del BREP principal
                        # Esto mantiene la posición relativa de los detalles
                        brep = AllplanGeo.Move(
                            brep,
                            AllplanGeo.Vector3D(
                                -centro_manguito_x + (longitud_original / 2.0),
                                -centro_manguito_y,
                                -centro_manguito_z,
                            ),
                        )

                        # 2. Calcular ángulos
                        rot_xy = (
                            0.0
                            if getattr(data, "longitud_xy", 0) < 0.1
                            else data.angulo_xy
                        )
                        rot_pitch = math.degrees(
                            math.atan2(data.delta_z, getattr(data, "longitud_xy", 0))
                        )

                        # 3. Aplicar rotaciones: Roll
                        if abs(getattr(data, "angulo_rotacion", 0)) > 0.1:
                            m = AllplanGeo.Matrix3D()
                            m.Rotation(
                                AllplanGeo.Line3D(0, 0, 0, 1, 0, 0),
                                AllplanGeo.Angle.FromDeg(data.angulo_rotacion),
                            )
                            brep = AllplanGeo.Transform(brep, m)

                        # Yaw (Planta)
                        m = AllplanGeo.Matrix3D()
                        m.Rotation(
                            AllplanGeo.Line3D(0, 0, 0, 0, 0, 1),
                            AllplanGeo.Angle.FromDeg(rot_xy),
                        )
                        brep = AllplanGeo.Transform(brep, m)

                        # Pitch (Elevación)
                        if abs(rot_pitch) > 0.1:
                            rad_xy = math.radians(rot_xy)
                            axis = AllplanGeo.Line3D(
                                0, 0, 0, math.sin(rad_xy), -math.cos(rad_xy), 0
                            )
                            m = AllplanGeo.Matrix3D()
                            m.Rotation(axis, AllplanGeo.Angle.FromDeg(rot_pitch))
                            brep = AllplanGeo.Transform(brep, m)

                        # 4. Mover al punto medio del segmento del manguito
                        # El punto medio ya está calculado correctamente
                        nuevo_brep = AllplanGeo.Move(
                            brep,
                            AllplanGeo.Vector3D(
                                punto_medio_x, punto_medio_y, punto_medio_z
                            ),
                        )

                        elementos_transformados.append(
                            {
                                "index": i,
                                "element_type": tipo_str,
                                "element": AllplanBasisElements.ModelElement3D(
                                    prop, nuevo_brep
                                ),
                            }
                        )
                    # --- CASO 2: DIFUSORES ---
                    elif tipo_str == "difusor":
                        move_offset = 0
                        if point_side == 0:
                            move_offset = CONDUCTO_WIDTH / 2
                        elif point_side == 2:
                            move_offset = -CONDUCTO_WIDTH / 2

                        ang_int = int(data.angulo_xy)

                        if debug:
                            print(
                                f"  start_point: ({start_point.X:.1f}, {start_point.Y:.1f}, {start_point.Z:.1f})"
                            )

                        if point_role == "inicial":
                            # DIFUSOR INICIAL: Debe estar al inicio absoluto del conducto
                            # Buscar el primer segmento dinámico para obtener el punto de inicio real
                            punto_inicio_real = start_point

                            # Si el difusor no es el primer elemento, buscar el inicio del primer tubo
                            # Buscar el primer tubo después del difusor
                            for j in range(i + 1, len(data_list)):
                                next_item = data_list[j]
                                next_tipo = next_item.get("type", "")
                                next_tipo_str = (
                                    next_tipo
                                    if isinstance(next_tipo, str)
                                    else (next_tipo[0] if len(next_tipo) > 0 else "")
                                )
                                # Encontrar el primer segmento dinámico
                                if next_tipo_str not in TIPOS_ACCESORIOS:
                                    next_data = next_item["segment"].data
                                    punto_inicio_real = getattr(
                                        next_data, "start", start_point
                                    )
                                    if debug:
                                        print(
                                            f"  Usando inicio del segmento {j}: ({punto_inicio_real.X:.1f}, {punto_inicio_real.Y:.1f}, {punto_inicio_real.Z:.1f})"
                                        )
                                    break

                            # Resetear BREP al origen
                            _, vertices_dif = brep.GetVertices()  # type: ignore
                            if vertices_dif:
                                centro_dif_x = sum(v.X for v in vertices_dif) / len(
                                    vertices_dif
                                )
                                centro_dif_y = sum(v.Y for v in vertices_dif) / len(
                                    vertices_dif
                                )
                                centro_dif_z = sum(v.Z for v in vertices_dif) / len(
                                    vertices_dif
                                )
                                brep = AllplanGeo.Move(
                                    brep,
                                    AllplanGeo.Vector3D(
                                        -centro_dif_x, -centro_dif_y, -centro_dif_z
                                    ),
                                )

                            # Aplicar rotación
                            if ang_int != 0:
                                matriz_rot = AllplanGeo.Matrix3D()
                                matriz_rot.Rotation(
                                    AllplanGeo.Line3D(0, 0, 0, 0, 0, 1),
                                    AllplanGeo.Angle.FromDeg(data.angulo_xy),
                                )
                                brep = AllplanGeo.Transform(brep, matriz_rot)

                            # Calcular offset basado en ángulo
                            w_cubo = -60 if ang_int in [0, 90, 89] else 60
                            offset_x = (
                                punto_inicio_real.X + w_cubo
                            )  # (w_cubo if ang_int in [180, 178, 179] else move_offset)
                            offset_y = punto_inicio_real.Y + (
                                move_offset if ang_int in [0, 180, 178, 179] else w_cubo
                            )

                            nuevo_brep = AllplanGeo.Move(
                                brep,
                                AllplanGeo.Vector3D(
                                    offset_x, offset_y - 1, punto_inicio_real.Z + 11
                                ),
                            )

                            if debug:
                                print(
                                    f"  Posición final difusor: ({offset_x:.1f}, {offset_y:.1f}, {punto_inicio_real.Z + 11:.1f})"
                                )

                        elif point_role == "final":
                            # DIFUSOR FINAL: Debe estar al final absoluto del conducto
                            # Buscar el último segmento dinámico
                            punto_final_real = (
                                data.end
                                if hasattr(data, "end")
                                else AllplanGeo.Point3D(
                                    start_point.X + data.delta_x,
                                    start_point.Y + data.delta_y,
                                    start_point.Z + data.delta_z,
                                )
                            )

                            # Si hay más segmentos después, buscar el final del último tubo
                            if i < len(data_list) - 1:
                                for j in range(len(data_list) - 1, i, -1):
                                    next_item = data_list[j]
                                    next_tipo = next_item.get("type", "")
                                    next_tipo_str = (
                                        next_tipo
                                        if isinstance(next_tipo, str)
                                        else (
                                            next_tipo[0] if len(next_tipo) > 0 else ""
                                        )
                                    )
                                    # Encontrar el último segmento dinámico
                                    if next_tipo_str not in TIPOS_ACCESORIOS:
                                        next_data = next_item["segment"].data
                                        punto_final_real = getattr(
                                            next_data, "end", punto_final_real
                                        )
                                        if debug:
                                            print(
                                                f"  Usando final del segmento {j}: ({punto_final_real.X:.1f}, {punto_final_real.Y:.1f}, {punto_final_real.Z:.1f})"
                                            )
                                        break

                            # Resetear BREP al origen
                            _, vertices_dif = brep.GetVertices()  # type: ignore
                            if vertices_dif:
                                centro_dif_x = sum(v.X for v in vertices_dif) / len(
                                    vertices_dif
                                )
                                centro_dif_y = sum(v.Y for v in vertices_dif) / len(
                                    vertices_dif
                                )
                                centro_dif_z = sum(v.Z for v in vertices_dif) / len(
                                    vertices_dif
                                )
                                brep = AllplanGeo.Move(
                                    brep,
                                    AllplanGeo.Vector3D(
                                        -centro_dif_x, -centro_dif_y, -centro_dif_z
                                    ),
                                )
                            else:
                                centro_dif_z = 0

                            # Calcular rotación para difusor final
                            rot_diff = 0
                            if ang_int == 0:
                                rot_diff = 180
                            elif ang_int in [180, 179, 178]:
                                rot_diff = 0
                            elif ang_int in [-90, 89, 90, -89]:
                                rot_diff = -data.angulo_xy

                            matriz_rot = AllplanGeo.Matrix3D()
                            matriz_rot.Rotation(
                                AllplanGeo.Line3D(0, 0, 0, 0, 0, 1),
                                AllplanGeo.Angle.FromDeg(rot_diff),
                            )
                            brep = AllplanGeo.Transform(brep, matriz_rot)

                            # Calcular posición final
                            es_horizontal_pura = ang_int in [0, 180, 179, 178]
                            padding = 60

                            # Calcular desde el punto inicial al final
                            long_total_conducto = AllplanGeo.CalcLength(
                                AllplanGeo.Line3D(
                                    (
                                        data_list[0]["segment"].data.start
                                        if data_list[0].get("type", "")
                                        not in TIPOS_ACCESORIOS
                                        else start_point
                                    ),
                                    punto_final_real,
                                )
                            )

                            if es_horizontal_pura:
                                factor = -1 if ang_int in [180, 179, 178] else 1
                                w_cubo = (long_total_conducto + padding) * factor
                                if ang_int in [180, 179, 178]:
                                    w_cubo = -long_total_conducto - padding

                                nuevo_brep = AllplanGeo.Move(
                                    brep,
                                    AllplanGeo.Vector3D(
                                        punto_final_real.X + (padding * factor),
                                        punto_final_real.Y + move_offset,
                                        punto_final_real.Z - centro_dif_z + 11,
                                    ),
                                )
                            else:
                                factor = -1 if ang_int in [-90, -89] else 1
                                w_cubo = (long_total_conducto + padding) * factor

                                nuevo_brep = AllplanGeo.Move(
                                    brep,
                                    AllplanGeo.Vector3D(
                                        punto_final_real.X + move_offset,
                                        punto_final_real.Y + (padding * factor),
                                        punto_final_real.Z - centro_dif_z + 11,
                                    ),
                                )
                        else:
                            # Caso por defecto (sin point_role definido)
                            nuevo_brep = AllplanGeo.Move(
                                brep,
                                AllplanGeo.Vector3D(
                                    punto_medio_x, punto_medio_y, punto_medio_z
                                ),
                            )

                        elementos_transformados.append(
                            {
                                "index": i,
                                "element_type": tipo_str,
                                "element": AllplanBasisElements.ModelElement3D(
                                    prop, nuevo_brep
                                ),
                            }
                        )
                    else:
                        # 1. Resetear al Origen (0,0,0) usando el centroide geométrico
                        # Esto asegura que las rotaciones se hagan sobre el centro de la pieza
                        nx = (
                            sum(v.X for v in vertices) / len(vertices)
                            if vertices
                            else 0
                        )
                        ny = (
                            sum(v.Y for v in vertices) / len(vertices)
                            if vertices
                            else 0
                        )
                        nz = (
                            sum(v.Z for v in vertices) / len(vertices)
                            if vertices
                            else 0
                        )
                        brep = AllplanGeo.Move(brep, AllplanGeo.Vector3D(-nx, -ny, -nz))

                        # 2. Calcular Ángulos
                        rot_xy = (
                            0.0
                            if getattr(data, "longitud_xy", 0) < 0.1
                            else data.angulo_xy
                        )
                        rot_pitch = math.degrees(
                            math.atan2(data.delta_z, getattr(data, "longitud_xy", 0))
                        )

                        # print("############################################## ITEMS ROT: ", rot_xy, rot_pitch)
                        # 3. Aplicar Rotaciones
                        # Roll
                        if abs(getattr(data, "angulo_rotacion", 0)) > 0.001:
                            m = AllplanGeo.Matrix3D()
                            m.Rotation(
                                AllplanGeo.Line3D(0, 0, 0, 1, 0, 0),
                                AllplanGeo.Angle.FromDeg(data.angulo_rotacion),
                            )
                            brep = AllplanGeo.Transform(brep, m)

                        # Yaw (Planta)
                        m = AllplanGeo.Matrix3D()
                        m.Rotation(
                            AllplanGeo.Line3D(0, 0, 0, 0, 0, 1),
                            AllplanGeo.Angle.FromDeg(rot_xy),
                        )
                        brep = AllplanGeo.Transform(brep, m)

                        # Pitch (Elevación)
                        if abs(rot_pitch) > 0.001:
                            rad_xy = math.radians(rot_xy)
                            axis = AllplanGeo.Line3D(
                                0, 0, 0, math.sin(rad_xy), -math.cos(rad_xy), 0
                            )
                            m = AllplanGeo.Matrix3D()
                            m.Rotation(axis, AllplanGeo.Angle.FromDeg(rot_pitch))
                            brep = AllplanGeo.Transform(brep, m)

                        # Calcular el punto medio del segmento EXTENDIDO
                        # Punto medio = start + vec * (long_original/2 + (ext_final - ext_inicio)/2)
                        desplazamiento_neto = (longitud_original / 2.0) + (
                            (extension_final - extension_inicio) / 2.0
                        )

                        mid_x = start_point.X + vec_curr.X * desplazamiento_neto
                        mid_y = start_point.Y + vec_curr.Y * desplazamiento_neto
                        mid_z = start_point.Z + vec_curr.Z * desplazamiento_neto

                        # desplazamiento_centro = (extension_final - extension_inicio) / 2.0
                        # mid_x = start_point.X + (getattr(data, 'delta_x', 0) * 0.5) + (vec_curr.X * desplazamiento_centro)
                        # mid_y = start_point.Y + (getattr(data, 'delta_y', 0) * 0.5) + (vec_curr.Y * desplazamiento_centro)
                        # mid_z = start_point.Z + (getattr(data, 'delta_z', 0) * 0.5) + (vec_curr.Z * desplazamiento_centro)

                        nuevo_brep = AllplanGeo.Move(
                            brep, AllplanGeo.Vector3D(mid_x, mid_y, mid_z)
                        )
                        elementos_transformados.append(
                            {
                                "index": i,
                                "element_type": tipo_str,
                                "element": AllplanBasisElements.ModelElement3D(
                                    prop, nuevo_brep
                                ),
                            }
                        )
            except Exception as e:
                if debug:
                    print(f"ERROR CRÍTICO en elemento {i} ({tipo_str}): {e}")

        if debug:
            print(f"\n{'='*70}")
            print(f"COMPLETADO: {len(elementos_transformados)} elementos procesados")
            print(f"{'='*70}\n")

        return elementos_transformados

    def center_and_connect_models_v1(
        self,
        data_list,
        overlap_mm=0.0,
        color=None,
        layers=[],
        layer_default=0,
        default_attrs=[],
        point_role=None,
        point_side=None,
        debug=True,
    ) -> List:
        """
        Centra cada modelo 3D en su propio segmento con soporte para rotación en 3D.

        Soporta segmentos en cualquier dirección (XY y Z):
        - Segmentos horizontales (plano XY)
        - Segmentos verticales (eje Z)
        - Segmentos inclinados (combinación XY + Z)

        Args:
            data_list: Lista de diccionarios con 'element3d' y 'segment'
            solapamiento_mm: Milímetros adicionales de longitud (por defecto 0mm)
            solapamiento_porcentaje: Porcentaje adicional de longitud (0.003 = 0.3%)
            debug: Si es True, imprime información de depuración

        Returns:
            Lista de AllplanBasisElements.ModelElement3D transformados
        """

        elementos_transformados = []
        list_atts_apply = []
        list_name_segment = []
        for i, item in enumerate(data_list):
            item_name = item["segment"].name
            if debug:
                print(f"\n{'#'*70}")
                print(f"# PROCESANDO ITEM {i+1}: {item_name}")
                print(f"{'#'*70}")

            list_elem_3d = item["element3d"]
            # obj_type = item["type"]
            segment = item["segment"]

            start_point = segment.data.start
            end_point = segment.data.end

            # Calcular longitud 3D del segmento (incluyendo componente Z)
            longitud_segmento = segment.data.longitud_3d

            # Calcular ángulos del segmento en 3D
            delta_x = end_point.X - start_point.X
            delta_y = end_point.Y - start_point.Y
            delta_z = end_point.Z - start_point.Z

            # Calcular distancia en el plano XY
            distancia_xy = math.sqrt(delta_x**2 + delta_y**2)

            # CASO ESPECIAL: Segmento completamente vertical
            if distancia_xy < 0.001:  # Prácticamente vertical (ΔX≈0, ΔY≈0)
                angulo_xy = 0.0  # No hay dirección horizontal definida

                # Rotación de 90° o -90° según la dirección Z
                if delta_z > 0:
                    angulo_inclinacion = 90.0  # Hacia arriba
                elif delta_z < 0:
                    angulo_inclinacion = -90.0  # Hacia abajo
                else:
                    angulo_inclinacion = 0.0  # Segmento de longitud cero

                if debug:
                    direccion = (
                        "ARRIBA ↑"
                        if delta_z > 0
                        else "ABAJO ↓" if delta_z < 0 else "PUNTO"
                    )
                    print(f"SEGMENTO VERTICAL DETECTADO: {direccion}")
            else:
                # Caso normal: Segmento con componente horizontal
                # Ángulo en plano XY (rotación alrededor del eje Z)
                angulo_xy = (
                    segment.data.angulo_xy
                )  # math.degrees(math.atan2(delta_y, delta_x))

                # Ángulo de inclinación (elevación desde el plano XY)
                angulo_inclinacion = math.degrees(math.atan2(delta_z, distancia_xy))

            # Ángulo de rotación del elemento (alrededor de su propio eje X)
            angulo_rotacion_elemento = getattr(segment.data, "angulo_rotacion", 0)

            longitud_con_solape = longitud_segmento + (2 * overlap_mm)
            if debug:
                print(f"Longitud final con solape: {longitud_con_solape:.2f}mm")

            # Modificar dimensiones según el tipo
            dinamic_flag = item["type"][0] not in [
                "manguito",
                "codo_45",
                "codo_90",
                "conexion",
                "difusor",
            ]
            lista_elem_3d_modified = []

            if dinamic_flag:
                for elem_3d in list_elem_3d:
                    brep_ajustado = self.modificar_dimensiones_brep(
                        elem_3d, longitud_con_solape
                    )
                    lista_elem_3d_modified.append(brep_ajustado)
            else:
                lista_elem_3d_modified = list_elem_3d

            # Procesar cada elemento 3D
            for e, elem_3d in enumerate(lista_elem_3d_modified):
                prop = elem_3d.GetCommonProperties()
                if len(layers) > 0:
                    prop.Layer = next(
                        (d.get(item_name) for d in layers if item_name in d),
                        layer_default,
                    )
                else:
                    prop.Layer = layer_default

                if dinamic_flag and color:
                    prop.Color = color

                list_name_segment.append(item_name)

                brep = elem_3d.GetGeometryObject()
                _, vertices = brep.GetVertices()

                # Calcular punto medio del segmento (en 3D) -- lo usamos también como fallback
                punto_medio_x = (start_point.X + end_point.X) / 2.0
                punto_medio_y = (start_point.Y + end_point.Y) / 2.0
                punto_medio_z = (start_point.Z + end_point.Z) / 2.0

                centro_brep = AllplanGeo.Point3D(
                    punto_medio_x, punto_medio_y, punto_medio_z
                )
                # --- Calcular centro del BRep con fallback si no hay vértices ---
                if vertices:
                    nx = sum(v.X for v in vertices) / len(vertices)
                    ny = sum(v.Y for v in vertices) / len(vertices)
                    nz = sum(v.Z for v in vertices) / len(vertices)
                    centro_brep = AllplanGeo.Point3D(nx, ny, nz)

                # === TRANSFORMACIÓN EN 3D ===
                nuevo_brep = None
                conducto_width = 75
                move = 0
                if point_side == 0:
                    move = conducto_width / 2
                elif point_side == 2:
                    move = -conducto_width / 2
                else:
                    move = 0  # -conducto_width/2-2

                if item["type"][0] == "manguito":
                    nuevo_brep = AllplanGeo.Move(
                        brep,
                        AllplanGeo.Vector3D(
                            punto_medio_x - centro_brep.Y - ny / 2,
                            punto_medio_y - centro_brep.Y,
                            punto_medio_z - centro_brep.Y,
                        ),
                    )
                elif item["type"][0] == "difusor":
                    if point_role == "inicial":
                        if int(segment.data.angulo_xy) != 0:
                            matriz_rotacion_propia = AllplanGeo.Matrix3D()
                            eje_x = AllplanGeo.Line3D(
                                AllplanGeo.Point3D(0, 0, 0), AllplanGeo.Point3D(0, 0, 1)
                            )
                            matriz_rotacion_propia.SetRotation(
                                eje_x, AllplanGeo.Angle.FromDeg(segment.data.angulo_xy)
                            )
                            brep = AllplanGeo.Transform(brep, matriz_rotacion_propia)

                        W_CUBO = -120 if segment.data.angulo_xy in [0, 90, 89] else 120
                        if int(segment.data.angulo_xy) in [0, 180, 178, 179]:
                            nuevo_brep = AllplanGeo.Move(
                                brep,
                                AllplanGeo.Vector3D(
                                    start_point.X + W_CUBO,
                                    start_point.Y + move,
                                    punto_medio_z - nz + 11,
                                ),
                            )
                        else:
                            # W_CUBO = 80 if segment.data.angulo_xy == 0 else -80
                            nuevo_brep = AllplanGeo.Move(
                                brep,
                                AllplanGeo.Vector3D(
                                    start_point.X - move,
                                    start_point.Y + W_CUBO,
                                    punto_medio_z - nz + 11,
                                ),
                            )
                    elif point_role == "final":
                        angulo_rotacion = 0
                        if int(segment.data.angulo_xy) in [0]:
                            angulo_rotacion = 180
                        elif int(segment.data.angulo_xy) in [180, 179, 178]:
                            angulo_rotacion = 0
                        elif int(segment.data.angulo_xy) in [-90, 89, 90, -89]:
                            angulo_rotacion = -segment.data.angulo_xy

                        matriz_rotacion_propia = AllplanGeo.Matrix3D()
                        eje_x = AllplanGeo.Line3D(
                            AllplanGeo.Point3D(0, 0, 0), AllplanGeo.Point3D(0, 0, 1)
                        )
                        matriz_rotacion_propia.SetRotation(
                            eje_x, AllplanGeo.Angle.FromDeg(angulo_rotacion)
                        )
                        brep = AllplanGeo.Transform(brep, matriz_rotacion_propia)

                        if int(segment.data.angulo_xy) in [0, 180, 179, 178]:
                            W_CUBO = (
                                (-longitud_con_solape - 80)
                                if int(segment.data.angulo_xy) in [180, 179, 178]
                                else longitud_con_solape + 80
                            )
                            nuevo_brep = AllplanGeo.Move(
                                brep,
                                AllplanGeo.Vector3D(
                                    start_point.X + W_CUBO,
                                    start_point.Y + move,
                                    punto_medio_z - nz + 11,
                                ),
                            )
                        else:
                            W_CUBO = (
                                (-longitud_con_solape - 80)
                                if int(segment.data.angulo_xy) in [-90, -89]
                                else longitud_con_solape + 80
                            )
                            nuevo_brep = AllplanGeo.Move(
                                brep,
                                AllplanGeo.Vector3D(
                                    start_point.X + move,
                                    start_point.Y + W_CUBO,
                                    punto_medio_z - nz + 11,
                                ),
                            )
                    else:
                        nuevo_brep = AllplanGeo.Move(
                            brep,
                            AllplanGeo.Vector3D(
                                punto_medio_x, punto_medio_y, punto_medio_z
                            ),
                        )
                else:
                    # Paso 1: Trasladar al origen
                    brep_trasladado = AllplanGeo.Move(
                        brep,
                        AllplanGeo.Vector3D(
                            -centro_brep.X, -centro_brep.Y, -centro_brep.Z
                        ),
                    )

                    # Paso 2: Rotación del elemento alrededor de su propio eje X (antes de otras rotaciones)
                    # Esto es importante para orientar correctamente codos y conexiones
                    if abs(angulo_rotacion_elemento) > 0.001:
                        matriz_rotacion_propia = AllplanGeo.Matrix3D()
                        eje_x = AllplanGeo.Line3D(
                            AllplanGeo.Point3D(0, 0, 0), AllplanGeo.Point3D(1, 0, 0)
                        )
                        matriz_rotacion_propia.SetRotation(
                            eje_x, AllplanGeo.Angle.FromDeg(angulo_rotacion_elemento)
                        )
                        brep_rotado_propio = AllplanGeo.Transform(
                            brep_trasladado, matriz_rotacion_propia
                        )

                        if debug:
                            print(
                                f"Aplicada rotación propia del elemento: {angulo_rotacion_elemento:.2f}°"
                            )
                    else:
                        brep_rotado_propio = brep_trasladado

                    # Paso 3: Rotación en plano XY (alrededor del eje Z)
                    matriz_rotacion_xy = AllplanGeo.Matrix3D()
                    eje_z = AllplanGeo.Line3D(
                        AllplanGeo.Point3D(0, 0, 0), AllplanGeo.Point3D(0, 0, 1)
                    )
                    matriz_rotacion_xy.SetRotation(
                        eje_z, AllplanGeo.Angle.FromDeg(angulo_xy)
                    )

                    brep_rotado_xy = AllplanGeo.Transform(
                        brep_rotado_propio, matriz_rotacion_xy
                    )

                    # Paso 4: Rotación de inclinación (alrededor del eje Y local)
                    if abs(angulo_inclinacion) > 0.001:
                        matriz_rotacion_inclinacion = AllplanGeo.Matrix3D()

                        # Calcular el eje Y después de la rotación XY
                        eje_y_x = math.sin(math.radians(angulo_xy))
                        eje_y_y = -math.cos(math.radians(angulo_xy))
                        eje_y = AllplanGeo.Line3D(
                            AllplanGeo.Point3D(0, 0, 0),
                            AllplanGeo.Point3D(eje_y_x, eje_y_y, 0),
                        )

                        matriz_rotacion_inclinacion.SetRotation(
                            eje_y, AllplanGeo.Angle.FromDeg(angulo_inclinacion)
                        )
                        brep_rotado_final = AllplanGeo.Transform(
                            brep_rotado_xy, matriz_rotacion_inclinacion
                        )

                        if debug:
                            print(
                                f"Aplicada rotación de inclinación: {angulo_inclinacion:.2f}°"
                            )
                    else:
                        brep_rotado_final = brep_rotado_xy

                    # Paso 5: Trasladar al punto medio del segmento (en 3D)
                    nuevo_brep = AllplanGeo.Move(
                        brep_rotado_final,
                        AllplanGeo.Vector3D(
                            punto_medio_x, punto_medio_y, punto_medio_z
                        ),
                    )

                # Crear el ModelElement3D transformado
                elementos_transformados.append(
                    AllplanBasisElements.ModelElement3D(prop, nuevo_brep)
                )

        for i, element in enumerate(elementos_transformados):
            attr_list = default_attrs.copy()

            attr_set_list = []
            attr_set_list.append(AllplanBaseElements.AttributeSet(attr_list))
            attributes = AllplanBaseElements.Attributes(attr_set_list)
            element.SetAttributes(attributes)
            list_atts_apply.append(element)

        if debug:
            print(f"\n{'='*70}")
            print(f"COMPLETADO: {len(elementos_transformados)} elementos procesados")
            print(f"{'='*70}\n")

        return list_atts_apply

    def split_list_by_ducts_connections(self, data_list, connection_types=None):
        """
        Separa los elementos en conductos y conexiones, manteniendo el índice
        de referencia para saber dónde debe insertarse cada conexión.
        """
        if connection_types is None:
            connection_types = ["manguito", "codo_45", "codo_90", "conexion", "difusor"]

        ducts = []
        connections = []

        for i, item in enumerate(data_list):
            tipo_raw = item.get("type", "")
            tipo_str = (
                tipo_raw
                if isinstance(tipo_raw, str)
                else (tipo_raw[0] if len(tipo_raw) > 0 else "")
            )
            if tipo_str in connection_types:
                connection = {"insert_at_index": i, "item": item}
                connections.append(connection)
            else:
                duct = {"insert_at_index": i, "item": item}
                ducts.append(duct)

        return {"ducts": ducts, "connections": connections}

    def split_list_by_connections_pairs(self, data_list, connection_types=None):
        """
        Busca todos los elementos con tipos de conexión y crea grupos de 2 elementos
        (elemento_previo + conexión), retornando una lista única con segmentos en orden.

        Args:
            data_list: Lista de elementos
            connection_types: Lista de tipos de conexión a buscar

        Returns:
            list: Lista de diccionarios con claves 'connection_groups' o 'remaining_list'
                [{"remaining_list": [...]}, {"connection_groups": [prev, conn]}, ...]

        Ejemplo:
            Input: [C1, C2, M1, C3, C4, M2, C5]
            Output: [
                {"remaining_list": [C1, C2]},
                {"connection_groups": [C2, M1]},  # Solo 2 elementos
                {"remaining_list": [C3, C4]},
                {"connection_groups": [C4, M2]},  # Solo 2 elementos
                {"remaining_list": [C5]}
            ]
        """

        # Tipos de conexión por defecto si no se proporcionan
        if connection_types is None:
            connection_types = ["manguito", "codo_45", "codo_90", "conexion", "difusor"]

        # Buscar todos los índices de conexiones
        connection_indices = []

        for i, item in enumerate(data_list):
            try:
                tipo_raw = item.get("type", "")
                tipo_str = (
                    tipo_raw
                    if isinstance(tipo_raw, str)
                    else (tipo_raw[0] if len(tipo_raw) > 0 else "")
                )

                if tipo_str in connection_types:
                    connection_indices.append(i)

            except (AttributeError, TypeError, IndexError):
                continue

        # Si no se encuentran conexiones, retornar toda la lista como remaining
        if not connection_indices:
            return [{"remaining_list": data_list}]

        # Crear lista de resultados con segmentos en orden
        result = []
        used_indices = set()
        current_pos = 0

        for conn_index in connection_indices:
            # Determinar el rango para este grupo de conexión
            # Solo incluye: elemento_previo + conexión (2 elementos)
            start_idx = max(0, conn_index - 1)
            end_idx = conn_index  # SOLO hasta la conexión, NO incluye el siguiente

            # Agregar elementos restantes ANTES de este grupo de conexión
            remaining_before = []
            for i in range(current_pos, start_idx):
                if i not in used_indices:
                    remaining_before.append(data_list[i])
                    used_indices.add(i)

            if remaining_before:
                result.append({"remaining_list": remaining_before})

            # Crear grupo de conexión (solo 2 elementos: previo + conexión)
            group = []
            for i in range(start_idx, end_idx + 1):
                if i not in used_indices:
                    group.append(data_list[i])
                    used_indices.add(i)

            if group:
                result.append({"connection_groups": group})

            # Actualizar posición actual (siguiente elemento después de la conexión)
            current_pos = conn_index + 1

        # Agregar elementos restantes DESPUÉS de todas las conexiones
        remaining_after = []
        for i in range(current_pos, len(data_list)):
            if i not in used_indices:
                remaining_after.append(data_list[i])
                used_indices.add(i)

        if remaining_after:
            result.append({"remaining_list": remaining_after})

        return result

    def split_list_by_all_connections(self, data_list, connection_types=None):
        """
        Searches for ALL items with connection types and creates groups of 3 elements,
        returning a single list with segments in order.

        Args:
            data_list: List of items
            connection_types: List of connection types to search for

        Returns:
            list: List of dictionaries with keys 'connection_groups' or 'remaining_list'
                [{"remaining_list": [...]}, {"connection_groups": [prev, conn, next]}, ...]
        """

        # Default connection types if not provided
        if connection_types is None:
            connection_types = ["manguito", "codo_45", "codo_90", "conexion", "difusor"]

        # Search for all connection indices
        connection_indices = []

        for i, item in enumerate(data_list):
            try:
                tipo_raw = item.get("type", "")
                tipo_str = (
                    tipo_raw
                    if isinstance(tipo_raw, str)
                    else (tipo_raw[0] if len(tipo_raw) > 0 else "")
                )

                if tipo_str in connection_types:
                    connection_indices.append(i)

            except (AttributeError, TypeError, IndexError):
                continue

        # If no connections found, return entire list as remaining
        if not connection_indices:
            return [{"remaining_list": data_list}]

        # Create result list with segments in order
        result = []
        used_indices = set()
        current_pos = 0

        for conn_index in connection_indices:
            # Determine the range for this connection group
            start_idx = max(0, conn_index - 1)
            end_idx = min(len(data_list) - 1, conn_index + 1)

            # Add remaining items BEFORE this connection group
            remaining_before = []
            for i in range(current_pos, start_idx):
                if i not in used_indices:
                    remaining_before.append(data_list[i])
                    used_indices.add(i)

            if remaining_before:
                result.append({"remaining_list": remaining_before})

            # Create connection group
            group = []
            for i in range(start_idx, end_idx + 1):
                if i not in used_indices:
                    group.append(data_list[i])
                    used_indices.add(i)

            if group:
                result.append({"connection_groups": group})

            # Update current position
            current_pos = end_idx + 1

        # Add any remaining items AFTER all connections
        remaining_after = []
        for i in range(current_pos, len(data_list)):
            if i not in used_indices:
                remaining_after.append(data_list[i])
                used_indices.add(i)

        if remaining_after:
            result.append({"remaining_list": remaining_after})

        return result

    def modificar_dimensiones_brep(
        self, model_element, nueva_longitud
    ) -> AllplanBasisElements.ModelElement3D:
        """
        Escala un BREP en su eje longitudinal (X local) manteniendo su geometría original.
        """
        geo = model_element.GetGeometryObject()

        # Obtener dimensiones actuales
        _, vertices = geo.GetVertices()
        if not vertices:
            return model_element

        # Calcular longitud actual en X
        x_coords = [v.X for v in vertices]
        longitud_actual = max(x_coords) - min(x_coords)

        if abs(longitud_actual) < 0.001:  # Evitar división por cero
            return model_element

        # Calcular factor de escala
        factor_escala = nueva_longitud / longitud_actual

        # Crear matriz de transformación para escalar solo en X
        matriz = AllplanGeo.Matrix3D()
        matriz.Scaling(factor_escala, 1.0, 1.0)  # Escala X, mantiene Y y Z

        # Aplicar transformación
        nuevo_brep = AllplanGeo.Transform(geo, matriz)

        # Crear nuevo ModelElement con las mismas propiedades
        nuevo_model = AllplanBasisElements.ModelElement3D(
            model_element.GetCommonProperties(), nuevo_brep
        )
        # print(f"  Escalado BREP: {longitud_actual:.2f}mm → {nueva_longitud:.2f}mm (factor: {factor_escala:.3f})")
        return nuevo_model

    def modificar_dimensiones_brep_v1(
        self, model_element, nueva_longitud
    ) -> AllplanBasisElements.ModelElement3D:
        """
        Modifica la longitud (eje X) de un elemento 3D representado por BRep3D.
        """
        # 1. Acceder a la sección BRep3D
        geo = model_element.GetGeometryObject()

        # 2. Acceder a los vertices
        initial_vertices = geo.GetVertices()

        # 3. Determinar la longitud actual (máxima X)
        longitud_actual = max(v.X for v in initial_vertices[1])  # Debería ser 1500

        # Si la nueva longitud es igual a la actual, no hacemos nada
        if nueva_longitud == longitud_actual:
            print(f"La longitud ya es {nueva_longitud}. No se requiere modificación.")
            return model_element

        # 4. Modificar los vértices
        nuevo_bloque_vertices = []

        for v in initial_vertices[1]:
            # se reemplaza por la nueva longitud.
            if v.X == longitud_actual:
                v = AllplanGeo.Point3D(nueva_longitud, v.Y, v.Z)

            nuevo_bloque_vertices.append(v)

        # 5. Actualizar el elemento (Simulación de actualización)
        print(f"Longitud original: {longitud_actual}")
        print(f"Nueva longitud: {nueva_longitud}")
        print("--- Vértices Actualizados ---")

        # Crear nuevo BRep vacío
        # Calcula dimensiones desde tus vértices
        p_min = nuevo_bloque_vertices[6]  # vértice mínimo
        p_max = nuevo_bloque_vertices[2]  # vértice máximo

        # Crear paralelepípedo directamente
        polyhedron = AllplanGeo.Polyhedron3D.CreateCuboid(p_min, p_max)

        # Convertir a BRep
        _, nuevo_brep = AllplanGeo.CreateBRep3D(polyhedron)

        nuevo_model = AllplanBasisElements.ModelElement3D(
            model_element.GetCommonProperties(), nuevo_brep
        )

        return nuevo_model


class PipelineProcessor:
    def __init__(
        self,
        elem3D_list,
        element_type=None,
        debug=False,
        build_ele=None,
        doc=None,
        saneamiento_tube_rebuild=None,
        saneamiento_extra_templates=None,
        saneamiento_extra_world_offset_z_mm: float = 0.0,
    ):
        """
        Args:
            elem3D_list: [{'type': 'conducto', 'elem': model}, ...]
        """
        self.templates = {item["type"]: item["elem"] for item in elem3D_list}
        self.debug = debug
        self.offset_codo = 0
        self.element_type_core = element_type
        # TE nodes (bifurcaciones) opcional: { (x,y,z): {"yaw_deg": float, ...} }
        self.te_nodes = {}
        self.build_ele = build_ele
        self.doc = doc
        # Saneamiento: opcionalmente regenerar tubo+anillo por tramo (anillo tamaño fijo).
        self.saneamiento_tube_rebuild = saneamiento_tube_rebuild
        # Saneamiento: templates extra (copias) para insertar por tramo.
        self.saneamiento_extra_templates = list(saneamiento_extra_templates or [])
        # Offset global Z opcional para copias extra de saneamiento (mm).
        self.saneamiento_extra_world_offset_z_mm = float(
            saneamiento_extra_world_offset_z_mm or 0.0
        )
        # Cache de modelos de manguito por distribución + par de diámetros
        self._manguito_model_cache = {}
        self._manguito_classes = None
        self._reduct_conjuntos_model_cls = None
        self._reduct_conjuntos_load_attempted = False
        # Cache de modelos de tubo por distribución + diámetro
        self._tubo_model_cache = {}
        self._tubo_classes = None
        # Cache de modelos de TE por distribución + trío de diámetros
        self._te_model_cache = {}
        self._te_classes = None
        # Evita mostrar el mismo aviso de TE inválida múltiples veces en un ciclo.
        self._te_invalid_warning_cache = set()
        # Orientación global capturada por PolyLib (start_orientation_capture).
        self.reference_orientation_angle = None

    def _resolve_vertical_rotation_angle(self, p_prev, p_mid) -> float:
        """
        Prioridad de orientación vertical (port de fontaneria.py):
        1) reference_orientation_angle capturada,
        2) ángulo del tramo previo horizontal.
        """
        ref_orientation = getattr(self, "reference_orientation_angle", None)
        if ref_orientation is not None:
            return float(ref_orientation)

        if p_prev is None or p_mid is None:
            return 0.0

        prev_dx = p_mid.X - p_prev.X
        prev_dy = p_mid.Y - p_prev.Y
        prev_dz = p_mid.Z - p_prev.Z
        prev_len = math.sqrt(
            prev_dx * prev_dx + prev_dy * prev_dy + prev_dz * prev_dz
        )

        if prev_len > 1e-6 and abs(prev_dz) < 1e-6:
            return math.atan2(prev_dy, prev_dx)

        return 0.0

    def _load_manguito_classes(self):
        """
        Carga dinámica de clases de manguito para poder elegir tipo por diámetros
        (M20, M25, reductor 25-20) igual que en fontaneria.
        """
        if self._manguito_classes is not None:
            return self._manguito_classes

        classes = {"IS": None, "TD": None, "RED": None}
        try:
            base_dir = os.path.dirname(os.path.dirname(__file__))
            is_path = os.path.join(base_dir, "manguito_005_is.py")
            td_path = os.path.join(base_dir, "manguito_005_td.py")

            if os.path.exists(is_path):
                spec_is = importlib.util.spec_from_file_location(
                    "agua_manguito_005_is_runtime",
                    is_path,
                )
                if spec_is and spec_is.loader:
                    mod_is = importlib.util.module_from_spec(spec_is)
                    spec_is.loader.exec_module(mod_is)
                    classes["IS"] = getattr(mod_is, "ManguitoModel", None)

            if os.path.exists(td_path):
                spec_td = importlib.util.spec_from_file_location(
                    "agua_manguito_005_td_runtime",
                    td_path,
                )
                if spec_td and spec_td.loader:
                    mod_td = importlib.util.module_from_spec(spec_td)
                    spec_td.loader.exec_module(mod_td)
                    classes["TD"] = getattr(mod_td, "ManguitoTDModel", None)

            # Fallback nuevo saneamiento: Reduct_40_25_script como reductor 40-25 / 25-40.
            # Compatibilidad: si no existe el nombre nuevo, probar script legado.
            red_paths = [
                os.path.join(base_dir, "Reduct_40_25_script.py"),
                os.path.join(base_dir, "Tapreduction_010.py"),
            ]
            red_path = next((p for p in red_paths if os.path.exists(p)), None)
            if red_path:
                spec_red = importlib.util.spec_from_file_location(
                    "saneamiento_reduct_40_25_runtime",
                    red_path,
                )
                if spec_red and spec_red.loader:
                    mod_red = importlib.util.module_from_spec(spec_red)
                    spec_red.loader.exec_module(mod_red)
                    red_class = (
                        getattr(mod_red, "TapReductionModel", None)
                        or getattr(mod_red, "ManguitoModel", None)
                        or getattr(mod_red, "TapreductionModel", None)
                    )
                    if red_class is not None:
                        classes["RED"] = red_class
                        if classes.get("IS") is None:
                            classes["IS"] = red_class
                        if classes.get("TD") is None:
                            classes["TD"] = red_class
        except Exception as ex:
            print(f"[AGUA] Error cargando clases de manguito por diámetro: {ex}")

        self._manguito_classes = classes
        return classes

    def _load_reduct_conjuntos_model_class(self):
        """
        Reductor conjunto 110↔50/40 (Reduct_110_50_40_script.ReductConjuntosModel).
        """
        if self._reduct_conjuntos_load_attempted:
            return self._reduct_conjuntos_model_cls
        self._reduct_conjuntos_load_attempted = True
        try:
            base_dir = os.path.dirname(os.path.dirname(__file__))
            path = os.path.join(base_dir, "Reduct_110_50_40_script.py")
            if not os.path.exists(path):
                return None
            spec = importlib.util.spec_from_file_location(
                "saneamiento_reduct_conjuntos_runtime",
                path,
            )
            if spec and spec.loader:
                mod = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(mod)
                cls = getattr(mod, "ReductConjuntosModel", None) or getattr(
                    mod, "ManguitoModel", None
                )
                self._reduct_conjuntos_model_cls = cls
        except Exception as ex:
            print(f"[AGUA][MANGUITO] Error cargando ReductConjuntosModel: {ex}")
            self._reduct_conjuntos_model_cls = None
        return self._reduct_conjuntos_model_cls

    def _get_manguito_models_for_diameters(self, d1, d2, distribution_type="IS"):
        """
        Devuelve model_list de manguito ajustado al par de diámetros.
        Soporta IS/TD y cachea por par para evitar reconstrucciones repetidas.
        """
        try:
            di1 = int(round(float(d1)))
            di2 = int(round(float(d2)))
        except Exception:
            return []

        dist = "TD" if str(distribution_type).upper() == "TD" else "IS"
        cache_key = (dist, tuple(sorted((di1, di2))))
        cached = self._manguito_model_cache.get(cache_key)
        if cached is not None:
            print(
                f"[AGUA][MANGUITO] cache hit dist={dist} pair={cache_key[1]} elems={len(cached)}"
            )
            return cached

        if self.build_ele is None or self.doc is None:
            return []

        classes = self._load_manguito_classes()
        pair_sorted = tuple(sorted((di1, di2)))
        # Forzar Reduct_40_25_script para transición 40<->25.
        if pair_sorted == (25, 40) and classes and classes.get("RED") is not None:
            ModelClass = classes.get("RED")
            print(
                f"[AGUA][MANGUITO] usando Reduct_40_25_script para par {pair_sorted} "
                f"(dist={dist}, d1={di1}, d2={di2})"
            )
        elif pair_sorted == (40, 110):
            ModelClass = self._load_reduct_conjuntos_model_class()
            if ModelClass is not None:
                print(
                    f"[AGUA][MANGUITO] usando Reduct_110_50_40_script (110↔40) par {pair_sorted} "
                    f"(dist={dist}, d1={di1}, d2={di2})"
                )
            else:
                ModelClass = classes.get(dist) if classes else None
        else:
            ModelClass = classes.get(dist) if classes else None
        if ModelClass is None:
            return []

        try:
            try:
                manguito_obj = ModelClass(self.build_ele, self.doc)
            except TypeError:
                manguito_obj = ModelClass(self.build_ele)

            if hasattr(manguito_obj, "set_diameters"):
                manguito_obj.set_diameters(di1, di2)

            type_manguito = getattr(manguito_obj, "type_manguito", None)
            model_list = manguito_obj.build() or []
            print(
                f"[AGUA][MANGUITO] build dist={dist} d1={di1} d2={di2} pair={cache_key[1]} "
                f"type_manguito={type_manguito} elems={len(model_list)}"
            )
            self._manguito_model_cache[cache_key] = model_list
            return model_list
        except Exception as ex:
            print(
                f"[AGUA] Error creando manguito para diámetros {di1}-{di2} ({dist}): {ex}"
            )
            self._manguito_model_cache[cache_key] = []
            return []

    def _normalize_tube_family(self, tube_system=None) -> str:
        """
        Normaliza el sistema de tubo del segmento a una familia interna.
        """
        raw = str(tube_system or "").strip().lower()
        if "multi" in raw:
            return "multicapa"
        if "arma" in raw:
            return "armaflex"
        if "poli" in raw:
            return "polietile"
        return "polietile"

    def _load_tubo_classes(self):
        """
        Carga dinámica de clases de tubo (IS/TD) para instanciar por diámetro real
        de cada segmento, evitando que todos tomen el último diámetro global.
        """
        if self._tubo_classes is not None:
            return self._tubo_classes

        classes = {
            "polietile": {"IS": None, "TD": None},
            "multicapa": {"IS": None, "TD": None},
            "armaflex": {"IS": None, "TD": None},
        }
        try:
            base_dir = os.path.dirname(os.path.dirname(__file__))
            is_path = os.path.join(base_dir, "tub_polietile_007_is.py")
            td_path = os.path.join(base_dir, "tub_polietile_007_td.py")
            multicapa_td_path = os.path.join(base_dir, "tub_multicapa_008_td.py")
            armaflex_td_path = os.path.join(base_dir, "armaflex_009_td.py")

            if os.path.exists(is_path):
                spec_is = importlib.util.spec_from_file_location(
                    "agua_tub_polietile_007_is_runtime",
                    is_path,
                )
                if spec_is and spec_is.loader:
                    mod_is = importlib.util.module_from_spec(spec_is)
                    spec_is.loader.exec_module(mod_is)
                    classes["polietile"]["IS"] = getattr(
                        mod_is, "TubPolietileModel", None
                    )

            if os.path.exists(td_path):
                spec_td = importlib.util.spec_from_file_location(
                    "agua_tub_polietile_007_td_runtime",
                    td_path,
                )
                if spec_td and spec_td.loader:
                    mod_td = importlib.util.module_from_spec(spec_td)
                    spec_td.loader.exec_module(mod_td)
                    classes["polietile"]["TD"] = getattr(
                        mod_td, "TubPolietileTDModel", None
                    )

            if os.path.exists(multicapa_td_path):
                spec_mc_td = importlib.util.spec_from_file_location(
                    "agua_tub_multicapa_008_td_runtime",
                    multicapa_td_path,
                )
                if spec_mc_td and spec_mc_td.loader:
                    mod_mc_td = importlib.util.module_from_spec(spec_mc_td)
                    spec_mc_td.loader.exec_module(mod_mc_td)
                    classes["multicapa"]["TD"] = getattr(
                        mod_mc_td, "TubMulticapaTDModel", None
                    )

            if os.path.exists(armaflex_td_path):
                spec_af_td = importlib.util.spec_from_file_location(
                    "agua_armaflex_009_td_runtime",
                    armaflex_td_path,
                )
                if spec_af_td and spec_af_td.loader:
                    mod_af_td = importlib.util.module_from_spec(spec_af_td)
                    spec_af_td.loader.exec_module(mod_af_td)
                    classes["armaflex"]["TD"] = getattr(
                        mod_af_td, "ArmaflexModel", None
                    )
        except Exception as ex:
            print(f"[AGUA][TUBO] Error cargando clases dinámicas: {ex}")

        self._tubo_classes = classes
        return classes

    def _set_build_ele_diameter_and_water(
        self, diameter_mm: int, dist: str, water_type=None
    ):
        """
        Sincroniza build_ele con diámetro/tipo de agua para crear el modelo correcto.
        """
        if self.build_ele is None:
            return
        try:
            diam_attr = getattr(self.build_ele, "DiametroAplicar", None)
            if diam_attr is not None and hasattr(diam_attr, "value"):
                diam_attr.value = int(diameter_mm)
            else:
                setattr(self.build_ele, "DiametroAplicar", int(diameter_mm))
        except Exception:
            pass

        if water_type is None:
            return
        try:
            target_names = (
                ["TipoDeAguaIS", "TipoDeAgua"]
                if dist == "IS"
                else ["TipoDeAguaTD", "TipoDeAgua"]
            )
            for name in target_names:
                try:
                    attr = getattr(self.build_ele, name, None)
                    if attr is not None and hasattr(attr, "value"):
                        attr.value = str(water_type)
                    else:
                        setattr(self.build_ele, name, str(water_type))
                except Exception:
                    continue
        except Exception:
            pass

    def _get_tubo_models_for_segment(
        self, diameter_mm, distribution_type="IS", water_type=None, tube_system=None
    ):
        """
        Devuelve [outer, inner?] del tubo para el diámetro/distribución del segmento.
        """
        try:
            di = int(round(float(diameter_mm)))
        except Exception:
            di = 20
        dist = "TD" if str(distribution_type).upper() == "TD" else "IS"
        family = self._normalize_tube_family(tube_system)
        water_key = str(water_type or "").strip().lower()
        cache_key = (family, dist, di, water_key)
        cached = self._tubo_model_cache.get(cache_key)
        if cached is not None:
            return cached

        if self.build_ele is None or self.doc is None:
            return []

        classes = self._load_tubo_classes()
        family_classes = classes.get(family, {}) if classes else {}
        ModelClass = family_classes.get(dist) if family_classes else None
        if ModelClass is None and classes:
            # Fallback seguro: polietilè
            ModelClass = classes.get("polietile", {}).get(dist)
        if ModelClass is None:
            return []

        try:
            self._set_build_ele_diameter_and_water(di, dist, water_type=water_type)
            tubo_obj = ModelClass(self.build_ele, self.doc)
            model_list = tubo_obj.build() or []
            self._tubo_model_cache[cache_key] = model_list
            print(
                f"[AGUA][TUBO] build family={family} dist={dist} diam={di} "
                f"water={water_key or '-'} elems={len(model_list)} (cache miss)"
            )
            return model_list
        except Exception as ex:
            print(
                f"[AGUA][TUBO] Error creando modelo dinámico family={family} "
                f"dist={dist} diam={di}: {ex}"
            )
            self._tubo_model_cache[cache_key] = []
            return []

    def _load_te_classes(self):
        """Carga dinámica de clases Te (IS/TD) para selección por diámetros."""
        if self._te_classes is not None:
            return self._te_classes

        classes = {"IS": None, "TD": None}
        try:
            base_dir = os.path.dirname(os.path.dirname(__file__))
            is_path = os.path.join(base_dir, "te_003_is.py")
            td_path = os.path.join(base_dir, "te_003_td.py")

            if os.path.exists(is_path):
                spec_is = importlib.util.spec_from_file_location(
                    "agua_te_003_is_runtime",
                    is_path,
                )
                if spec_is and spec_is.loader:
                    mod_is = importlib.util.module_from_spec(spec_is)
                    spec_is.loader.exec_module(mod_is)
                    classes["IS"] = getattr(mod_is, "TeModel", None)

            if os.path.exists(td_path):
                spec_td = importlib.util.spec_from_file_location(
                    "agua_te_003_td_runtime",
                    td_path,
                )
                if spec_td and spec_td.loader:
                    mod_td = importlib.util.module_from_spec(spec_td)
                    spec_td.loader.exec_module(mod_td)
                    classes["TD"] = getattr(mod_td, "TeTDModel", None)
        except Exception as ex:
            print(f"[AGUA][TE] Error cargando clases dinámicas: {ex}")

        self._te_classes = classes
        return classes

    def _get_te_models_for_diameters(
        self,
        d_main_in,
        d_main_out,
        d_branch,
        distribution_type="IS",
        mirror_model_x: bool = False,
    ):
        """
        Devuelve [outer, inner?] de TE para el nodo según diámetros reales
        (main_in, main_out, branch) y distribución IS/TD.
        """
        try:
            di_in = int(round(float(d_main_in)))
            di_out = int(round(float(d_main_out)))
            di_branch = int(round(float(d_branch)))
        except Exception:
            return []

        dist = "TD" if str(distribution_type).upper() == "TD" else "IS"

        def _is_supported_te_combo(di_in, di_out, di_branch):
            if di_in == di_out == di_branch and di_in in (20, 25, 32, 40, 110):
                return True
            triple_sorted = tuple(sorted((di_in, di_out, di_branch)))
            if di_in == 25 and di_out == 25 and di_branch == 20:
                return True
            if di_branch == 25 and triple_sorted == (20, 25, 25):
                return True
            if di_branch == 20 and triple_sorted == (20, 20, 25):
                return True
            return False

        if not _is_supported_te_combo(di_in, di_out, di_branch):
            warn_key = (dist, di_in, di_out, di_branch)
            if warn_key not in self._te_invalid_warning_cache:
                self._te_invalid_warning_cache.add(warn_key)
                msg = (
                    "No existe una TE para la combinación de diámetros seleccionada.\n\n"
                    f"Combinación detectada: {di_in}-{di_out}-{di_branch} ({dist}).\n\n"
                    "Modifique los diámetros de los segmentos para que coincidan "
                    "con los tipos de TE disponibles."
                )
                try:
                    PythonUtility.ShowMessageBox(msg, PythonUtility.MB_OK)
                except Exception:
                    print(f"[AGUA][TE] {msg}")
            print(
                f"[AGUA][TE] combinación no soportada dist={dist} "
                f"di_in={di_in} di_out={di_out} di_branch={di_branch}"
            )
            return []

        cache_key = (dist, di_in, di_out, di_branch, bool(mirror_model_x))
        cached = self._te_model_cache.get(cache_key)
        if cached is not None:
            print(
                f"[AGUA][TE] cache hit dist={dist} di_in={di_in} di_out={di_out} "
                f"di_branch={di_branch} mirror_model_x={mirror_model_x} elems={len(cached)}"
            )
            return cached

        if self.build_ele is None or self.doc is None:
            return []

        if getattr(self, "element_type_core", None) == "tubo_saneamiento":
            if di_in == di_out == di_branch == 40:
                ModelCls = _get_derivacion_y45_d40_model_class()
                if ModelCls is None:
                    self._te_model_cache[cache_key] = []
                    print(
                        f"[SANEAMIENTO][TE-Y40] clase no disponible dist={dist} "
                        f"di={di_in}/{di_out}/{di_branch}"
                    )
                    return []
                try:
                    te_obj = ModelCls(self.build_ele, self.doc)
                    if hasattr(te_obj, "set_diameters"):
                        if mirror_model_x:
                            te_obj.set_diameters(di_out, di_branch, di_in)
                        else:
                            te_obj.set_diameters(di_in, di_branch, di_out)
                    model_list = list(te_obj.build() or [])
                except Exception as ex:
                    print(f"[SANEAMIENTO][TE-Y40] build error: {ex}")
                    model_list = []
                self._te_model_cache[cache_key] = model_list
                print(
                    f"[SANEAMIENTO][TE-Y40] build dist={dist} di_in={di_in} di_out={di_out} "
                    f"di_branch={di_branch} elems={len(model_list)}"
                )
                return model_list

            if di_in == di_out == di_branch == 110:
                if getattr(self, "saneamiento_fecal_tricapa_install", False):
                    # TE Y110 pluvial (Derivacion110m_f_script) no aplica a tricapa fecal.
                    pass
                else:
                    ModelCls110 = _get_derivacion_y110_d110_model_class()
                    if ModelCls110 is None:
                        self._te_model_cache[cache_key] = []
                        print(
                            f"[SANEAMIENTO][TE-Y110-P] clase no disponible dist={dist} "
                            f"di={di_in}/{di_out}/{di_branch}"
                        )
                        return []
                    try:
                        te_obj_110 = ModelCls110(self.build_ele, self.doc)
                        if hasattr(te_obj_110, "set_diameters"):
                            if mirror_model_x:
                                te_obj_110.set_diameters(di_out, di_branch, di_in)
                            else:
                                te_obj_110.set_diameters(di_in, di_branch, di_out)
                        model_list_110 = list(te_obj_110.build() or [])
                    except Exception as ex:
                        print(f"[SANEAMIENTO][TE-Y110-P] build error: {ex}")
                        model_list_110 = []
                    self._te_model_cache[cache_key] = model_list_110
                    print(
                        f"[SANEAMIENTO][TE-Y110-P] build dist={dist} di_in={di_in} di_out={di_out} "
                        f"di_branch={di_branch} elems={len(model_list_110)}"
                    )
                    return model_list_110

        classes = self._load_te_classes()
        ModelClass = classes.get(dist) if classes else None
        if ModelClass is None:
            return []

        try:
            try:
                te_obj = ModelClass(self.build_ele, self.doc)
            except TypeError:
                te_obj = ModelClass(self.build_ele)

            if hasattr(te_obj, "set_diameters"):
                # Igual que fontaneria.py:
                # - normal: (main_in, branch, main_out)
                # - invertida (mirror_x): (main_out, branch, main_in)
                if mirror_model_x:
                    te_obj.set_diameters(di_out, di_branch, di_in)
                else:
                    te_obj.set_diameters(di_in, di_branch, di_out)

            type_te = getattr(te_obj, "type_te", None)
            model_list = te_obj.build() or []
            self._te_model_cache[cache_key] = model_list
            print(
                f"[AGUA][TE] build dist={dist} di_in={di_in} di_out={di_out} "
                f"di_branch={di_branch} mirror_model_x={mirror_model_x} "
                f"type_te={type_te} elems={len(model_list)}"
            )
            return model_list
        except Exception as ex:
            print(
                f"[AGUA][TE] Error creando modelo dinámico dist={dist} "
                f"di_in={di_in} di_out={di_out} di_branch={di_branch}: {ex}"
            )
            self._te_model_cache[cache_key] = []
            return []

    def _modificar_dimensiones_brep_longest_bbox_axis(
        self, model_element, nueva_longitud
    ) -> AllplanBasisElements.ModelElement3D:
        """
        Escala el BRep solo en el eje donde el bounding box es mayor (eje del tubo).
        Necesario para `tub_pvc_tricapa_f_40_script`: el tramo largo va en Z; el método
        genérico que solo escala X tomaba el diámetro (~40 mm) y deformaba tubo y anillo.
        """
        geo = model_element.GetGeometryObject()
        _, vertices = geo.GetVertices()
        if not vertices:
            return model_element

        xs = [v.X for v in vertices]
        ys = [v.Y for v in vertices]
        zs = [v.Z for v in vertices]
        dx = max(xs) - min(xs)
        dy = max(ys) - min(ys)
        dz = max(zs) - min(zs)

        candidates = ((dx, 0, "X"), (dy, 1, "Y"), (dz, 2, "Z"))
        longitud_actual, axis_idx, axis_name = max(candidates, key=lambda t: t[0])

        if abs(longitud_actual) < 0.001:
            return model_element

        factor_escala = nueva_longitud / longitud_actual
        matriz = AllplanGeo.Matrix3D()
        if axis_idx == 0:
            matriz.Scaling(factor_escala, 1.0, 1.0)
        elif axis_idx == 1:
            matriz.Scaling(1.0, factor_escala, 1.0)
        else:
            matriz.Scaling(1.0, 1.0, factor_escala)

        nuevo_brep = AllplanGeo.Transform(geo, matriz)
        nuevo_model = AllplanBasisElements.ModelElement3D(
            model_element.GetCommonProperties(), nuevo_brep
        )
        try:
            src_attrs = (
                model_element.GetAttributes()
                if hasattr(model_element, "GetAttributes")
                else None
            )
            if src_attrs:
                nuevo_model.SetAttributes(src_attrs)
        except Exception:
            pass
        print(
            f"[SANEAMIENTO][TUBO] stretch eje={axis_name} "
            f"L_actual={longitud_actual:.1f} -> L_nueva={nueva_longitud:.1f} "
            f"(factor={factor_escala:.4f})"
        )
        return nuevo_model

    def modificar_dimensiones_brep(
        self, model_element, nueva_longitud
    ) -> AllplanBasisElements.ModelElement3D:
        """
        Escala un BREP en su eje longitudinal manteniendo el resto de dimensiones.

        Para fontanería / tubos Agua el modelo suele ir alineado con X. Los PythonParts
        `tub_pvc_tricapa_f_40` dejan el eje largo en Z hasta la rotación en `_aplicar_transformacion`;
        `tub_pvc_basic_f_25` ya va en X. Para `tubo_saneamiento` se usa la mayor dimensión del bbox.
        """
        if getattr(self, "element_type_core", None) == "tubo_saneamiento":
            return self._modificar_dimensiones_brep_longest_bbox_axis(
                model_element, nueva_longitud
            )

        geo = model_element.GetGeometryObject()

        # Obtener dimensiones actuales
        _, vertices = geo.GetVertices()
        if not vertices:
            return model_element

        # Calcular longitud actual en X
        x_coords = [v.X for v in vertices]
        longitud_actual = max(x_coords) - min(x_coords)

        if abs(longitud_actual) < 0.001:  # Evitar división por cero
            return model_element

        # Calcular factor de escala
        factor_escala = nueva_longitud / longitud_actual

        # Crear matriz de transformación para escalar solo en X
        matriz = AllplanGeo.Matrix3D()
        matriz.Scaling(factor_escala, 1.0, 1.0)  # Escala X, mantiene Y y Z

        # Aplicar transformación
        nuevo_brep = AllplanGeo.Transform(geo, matriz)

        # Crear nuevo ModelElement con las mismas propiedades y atributos.
        # Sin esto se pierde, por ejemplo, Material=CAVITAT en outer TD.
        nuevo_model = AllplanBasisElements.ModelElement3D(
            model_element.GetCommonProperties(), nuevo_brep
        )
        try:
            src_attrs = (
                model_element.GetAttributes()
                if hasattr(model_element, "GetAttributes")
                else None
            )
            if src_attrs:
                nuevo_model.SetAttributes(src_attrs)
        except Exception:
            pass
        # print(f"  Escalado BREP: {longitud_actual:.2f}mm → {nueva_longitud:.2f}mm (factor: {factor_escala:.3f})")
        return nuevo_model

    def _get_center_from_vertices(self, brep):
        """
        Calcula el centro geométrico promediando todos los vértices del BRep3D.
        Soluciona el error de firma de MinMax3D.
        """
        def _extract_vertices_debug(_brep, _tag="center"):
            """Compatibilidad con firmas distintas de GetVertices según runtime."""
            try:
                raw = _brep.GetVertices()
            except Exception as ex:
                print(f"[SANEAMIENTO][DEBUG][VERTICES][{_tag}] GetVertices() exception: {ex}")
                return 1, []

            # Firma habitual: (error, vertices)
            if isinstance(raw, tuple):
                if len(raw) == 2:
                    err, verts = raw
                    print(
                        f"[SANEAMIENTO][DEBUG][VERTICES][{_tag}] tuple2 err={err} "
                        f"verts_len={len(verts) if verts else 0}"
                    )
                    return err, verts
                if len(raw) >= 3:
                    err = raw[0]
                    verts = raw[-1]
                    print(
                        f"[SANEAMIENTO][DEBUG][VERTICES][{_tag}] tuple{len(raw)} err={err} "
                        f"using_last_as_vertices len={len(verts) if verts else 0} "
                        f"types={[type(x).__name__ for x in raw]}"
                    )
                    return err, verts

            # Firma rara: devuelve directamente lista de vértices.
            if isinstance(raw, list):
                print(
                    f"[SANEAMIENTO][DEBUG][VERTICES][{_tag}] list_only "
                    f"verts_len={len(raw)}"
                )
                return 0, raw

            print(
                f"[SANEAMIENTO][DEBUG][VERTICES][{_tag}] unexpected_return "
                f"type={type(raw).__name__} value={raw}"
            )
            return 1, []

        # Extraer los vértices del BRep (robusto + debug).
        error, vertices = _extract_vertices_debug(brep, "get_center")

        if error != 0 or not vertices:
            # Fallback en caso de que no haya vértices (poco probable)
            return AllplanGeo.Point3D(0, 0, 0)

        # Sumatoria de coordenadas
        sum_x = sum(v.X for v in vertices)
        sum_y = sum(v.Y for v in vertices)
        sum_z = sum(v.Z for v in vertices)
        n = len(vertices)

        return AllplanGeo.Point3D(sum_x / n, sum_y / n, sum_z / n)

    def _align_saneamiento_tube_along_segment(
        self,
        model_element,
        p_line_start: AllplanGeo.Point3D,
        v_unit: AllplanGeo.Vector3D,
    ):
        """
        Tras colocar el tubo en el centro del tramo, desplaza a lo largo del eje del
        segmento para que la proyección del sólido sobre esa recta empiece en
        p_line_start. Así se corrige el desfase típico de tubos con anillo/flecha
        asimétricos (p. ej. Pluvial tricapa V) donde el centroide no coincide con el
        eje útil entre el primer y el último punto de la polilínea.
        """
        try:
            brep = model_element.GetGeometryObject()
            raw_vertices = brep.GetVertices()
            if isinstance(raw_vertices, tuple):
                if len(raw_vertices) == 2:
                    err, vertices = raw_vertices
                elif len(raw_vertices) >= 3:
                    err, vertices = raw_vertices[0], raw_vertices[-1]
                    print(
                        f"[SANEAMIENTO][DEBUG][VERTICES][align_tube] tuple{len(raw_vertices)} "
                        f"err={err} using_last_as_vertices"
                    )
                else:
                    err, vertices = 1, []
            elif isinstance(raw_vertices, list):
                err, vertices = 0, raw_vertices
            else:
                err, vertices = 1, []
            if err != 0 or not vertices:
                return model_element
            vx, vy, vz = v_unit.X, v_unit.Y, v_unit.Z
            sx, sy, sz = p_line_start.X, p_line_start.Y, p_line_start.Z
            projections = []
            for v in vertices:
                t = (v.X - sx) * vx + (v.Y - sy) * vy + (v.Z - sz) * vz
                projections.append(t)
            t_min = min(projections)
            if abs(t_min) < 1e-4:
                return model_element
            shift = -t_min
            brep_moved = AllplanGeo.Move(
                brep, AllplanGeo.Vector3D(vx * shift, vy * shift, vz * shift)
            )
            nuevo = AllplanBasisElements.ModelElement3D(
                model_element.GetCommonProperties(), brep_moved
            )
            try:
                src_attrs = (
                    model_element.GetAttributes()
                    if hasattr(model_element, "GetAttributes")
                    else None
                )
                if src_attrs:
                    nuevo.SetAttributes(src_attrs)
            except Exception:
                pass
            return nuevo
        except Exception:
            return model_element

    def obtener_rotacion_codo(self, v_salida, eps=1e-6):
        """
        Devuelve el ángulo de rotación del codo en grados
        respecto al primer codo (base).
        """
        v_base = AllplanGeo.Vector3D(0, 1, 0)

        dot = v_base.X * v_salida.X + v_base.Y * v_salida.Y
        cross_z = v_base.X * v_salida.Y - v_base.Y * v_salida.X

        # math.atan2 devuelve el ángulo exacto del giro entre los dos vectores
        angulo_rad = math.atan2(cross_z, dot)
        angulo_deg = math.degrees(angulo_rad)

        # Limpieza de precisión decimal para valores casi exactos (25, 30, 45, 90, etc.)
        if abs(angulo_deg - round(angulo_deg)) < eps:
            angulo_deg = float(round(angulo_deg))

        return angulo_deg

    def _aplicar_transformacion(
        self,
        model_element,
        segment_data,
        rotation_angle=0,
        elem_type="conducto",
        custom_position=None,
        next_seg=None,
        prev_seg=None,
        custom_yaw_deg: float | None = None,
        custom_mirror_x_local: bool = False,
        preserve_local_offset: bool = False,
    ) -> AllplanBasisElements.ModelElement3D:
        """
        Aplica transformaciones separando lógica horizontal (XY) y vertical (ZX/Pitch).
        """
        prop = model_element.GetCommonProperties()
        brep = model_element.GetGeometryObject()

        def _build_model_with_source_attrs(transformed_brep):
            nuevo_model = AllplanBasisElements.ModelElement3D(prop, transformed_brep)
            try:
                src_attrs = (
                    model_element.GetAttributes()
                    if hasattr(model_element, "GetAttributes")
                    else None
                )
                if src_attrs:
                    nuevo_model.SetAttributes(src_attrs)
            except Exception:
                pass
            return nuevo_model

        # 1. POSICIONAMIENTO INICIAL
        # Determinamos el punto de inserción (vértice o centro)
        p_destino = custom_position if custom_position else segment_data.start

        # 2. NORMALIZACIÓN (ORIGEN 0,0,0)
        # Para conductos rectos normalizamos al centro, pero codos, TES y manguitos
        # ya vienen centrados desde su propio modelador (IS/TD) y debemos conservar
        # ese origen para mantener la alineación y el encaje en nodo.
        if elem_type not in ("codo_90", "te", "manguito") and not preserve_local_offset:
            centro = self._get_center_from_vertices(brep)
            if (
                abs(centro.X) < 1e-9
                and abs(centro.Y) < 1e-9
                and abs(centro.Z) < 1e-9
                and elem_type in ("codo_45", "codo_90")
            ):
                print(
                    f"[SANEAMIENTO][DEBUG][CENTER] zero_center elem_type={elem_type} "
                    f"preserve_local_offset={preserve_local_offset}"
                )
            brep = AllplanGeo.Move(
                brep, AllplanGeo.Vector3D(-centro.X, -centro.Y, -centro.Z)
            )

        # tub_pvc_tricapa_f_40 (Fecal Ø40): el tramo largo va en Z local. El resto del
        # conducto asume eje largo en X antes del yaw (Rot Z = angulo_xy).
        # tub_pvc_tricapa_p_110 / tricapa_v / tub_pvc_basic_f_25 ya dejan el eje en X.
        if getattr(self, "element_type_core", None) == "tubo_saneamiento":
            try:
                err_v, verts = brep.GetVertices()
                if err_v == 0 and verts:
                    xs = [v.X for v in verts]
                    ys = [v.Y for v in verts]
                    zs = [v.Z for v in verts]
                    dx = max(xs) - min(xs)
                    dy = max(ys) - min(ys)
                    dz = max(zs) - min(zs)
                    _extents = ((dx, 0), (dy, 1), (dz, 2))
                    _longest, _axis_idx = max(_extents, key=lambda t: t[0])
                    if _axis_idx == 2 and _longest > 1e-3:
                        # Igual que tub_pvc_tricapa_v._build_tube: +90° Y lleva el eje Z del
                        # prisma al eje +X (donde el yaw en Z alinea con la polilínea).
                        axis_y = AllplanGeo.Line3D(
                            AllplanGeo.Point3D(0, 0, 0),
                            AllplanGeo.Point3D(0, 1, 0),
                        )
                        mat_z_to_x = AllplanGeo.Matrix3D()
                        mat_z_to_x.SetRotation(
                            axis_y, AllplanGeo.Angle(math.radians(90))
                        )
                        brep = AllplanGeo.Transform(brep, mat_z_to_x)
                        # tub_pvc_tricapa_f_40 (Ø40) rota 180° en X en el script *antes* de este
                        # giro; tricapa_v aplica Ry(90) en build y *después* 180° en X.
                        # Con solo Ry(90) el anillo queda en el extremo opuesto al de tricapa_v.
                        # Espejo en X invierte el sentido del eje longitudinal local.
                        mat_flip_x = AllplanGeo.Matrix3D()
                        mat_flip_x.SetScaling(-1.0, 1.0, 1.0)
                        brep = AllplanGeo.Transform(brep, mat_flip_x)
            except Exception:
                pass

        # ==========================================
        # PARTE 1: TRANSFORMACIONES LOCALES (ROLL)
        # ==========================================
        if abs(rotation_angle) > 0.015:
            matriz_roll = AllplanGeo.Matrix3D()
            eje_x_local = AllplanGeo.Line3D(
                AllplanGeo.Point3D(0, 0, 0), AllplanGeo.Point3D(1, 0, 0)
            )
            matriz_roll.SetRotation(
                eje_x_local, AllplanGeo.Angle.FromDeg(rotation_angle)
            )
            brep = AllplanGeo.Transform(brep, matriz_roll)

        # Manguito reductor: invertir orientación local (como fontaneria.py)
        # para el caso 25->20 usando el mismo modelo base 20-25.
        if elem_type == "manguito" and custom_mirror_x_local:
            try:
                mirror_x = AllplanGeo.Matrix3D()
                mirror_x.SetScaling(-1, 1, 1)
                brep = AllplanGeo.Transform(brep, mirror_x)
            except Exception:
                pass

        # ==========================================
        # PARTE 2a: TE saneamiento Y45/Y110 — orientación Saneamiento_old (BIF40 / D110-D110).
        # (Sin mirrors/planos de fontanería/te_orientation.)
        # ==========================================
        if elem_type == "te" and getattr(
            self, "element_type_core", None
        ) == "tubo_saneamiento":
            te_key_old = (
                round(p_destino.X, 3),
                round(p_destino.Y, 3),
                round(p_destino.Z, 3),
            )
            te_old = getattr(self, "te_nodes", {}).get(te_key_old, None)
            if te_old:
                main_dir = te_old.get("main_dir_3d")
                branch_dir = te_old.get("branch_dir_3d")
                if (
                    isinstance(main_dir, (list, tuple))
                    and isinstance(branch_dir, (list, tuple))
                    and len(main_dir) == 3
                    and len(branch_dir) == 3
                ):
                    mv = (
                        float(main_dir[0]),
                        float(main_dir[1]),
                        float(main_dir[2]),
                    )
                    bv = (
                        float(branch_dir[0]),
                        float(branch_dir[1]),
                        float(branch_dir[2]),
                    )
                    if te_old.get("use_saneamiento_old_d40_orientation"):
                        from .bifurcacion_old_d40_orientacion import (
                            try_apply_old_d40_bif_transform,
                        )

                        brep_old = try_apply_old_d40_bif_transform(
                            brep,
                            p_destino.X,
                            p_destino.Y,
                            p_destino.Z,
                            mv,
                            bv,
                            extra_dx=BIF_Y40_PLACEMENT_OFFSET_X_MM,
                            extra_dy=BIF_Y40_PLACEMENT_OFFSET_Y_MM,
                            extra_dz=BIF_Y40_PLACEMENT_OFFSET_Z_MM,
                        )
                        if brep_old is not None:
                            return _build_model_with_source_attrs(brep_old)
                    if te_old.get("use_saneamiento_old_d110_pluvial_orientation"):
                        from .bifurcacion_old_d40_orientacion import (
                            try_apply_old_d110_d110_bif_transform,
                        )

                        brep_110 = try_apply_old_d110_d110_bif_transform(
                            brep,
                            p_destino.X,
                            p_destino.Y,
                            p_destino.Z,
                            mv,
                            bv,
                            extra_dx=BIF_Y110_PLUVIAL_PLACEMENT_OFFSET_X_MM,
                            extra_dy=BIF_Y110_PLUVIAL_PLACEMENT_OFFSET_Y_MM,
                            extra_dz=BIF_Y110_PLUVIAL_PLACEMENT_OFFSET_Z_MM,
                        )
                        if brep_110 is not None:
                            return _build_model_with_source_attrs(brep_110)

        # ==========================================
        # PARTE 2: LÓGICA VERTICAL (PITCH / ZX)
        # ==========================================
        # TE: aplicar mirrors/rotación/elevación como en fontaneria.py
        if elem_type == "te" and custom_yaw_deg is not None:
            te_params = getattr(self, "te_nodes", {}).get(
                (round(p_destino.X, 3), round(p_destino.Y, 3), round(p_destino.Z, 3)),
                None,
            )
            if te_params:
                # Debug TE: por defecto ON (hasta estabilizar orientación XZ/YZ)
                debug_te = str(os.getenv("AGUA_DEBUG_TE", "1")).strip() not in (
                    "",
                    "0",
                    "false",
                    "False",
                )
                debug_te_pos = str(os.getenv("AGUA_DEBUG_TE_POS", "1")).strip() not in (
                    "",
                    "0",
                    "false",
                    "False",
                )
                ang = float(te_params.get("ang_rad", 0.0) or 0.0)
                plane = str(te_params.get("plane", "XY") or "XY")
                main_dir_3d = te_params.get("main_dir_3d", None)
                branch_dir_3d = te_params.get("branch_dir_3d", None)
                offset_perp_local = float(
                    te_params.get("offset_perp_local", 0.0) or 0.0
                )
                need_mx = bool(te_params.get("need_mirror_x_local", False))
                need_my = bool(te_params.get("need_mirror_y_local", False))
                branch_elevated = bool(te_params.get("branch_elevated", False))
                need_mz = bool(te_params.get("need_mirror_z_local", False))
                model_mirror_x = bool(te_params.get("model_mirror_x", False))
                di_in = int(round(float(te_params.get("d_main_in", 0) or 0)))
                di_out = int(round(float(te_params.get("d_main_out", 0) or 0)))
                di_branch = int(round(float(te_params.get("d_branch", 0) or 0)))

                # Casos de TE mixta en XY (portado práctico de fontaneria):
                # cuando el troncal cambia de diámetro y la rama coincide con uno
                # de los dos diámetros del troncal (casos 25-25-20 / 25-20-20),
                # forzamos mirror en Y para que las bocas coincidan con los tramos.
                if (
                    plane == "XY"
                    and not branch_elevated
                    and di_in != di_out
                    and di_branch in (di_in, di_out)
                ):
                    need_mx = False
                    need_my = True
                    if debug_te:
                        print(
                            "[AGUA][TE] FIX ORIENTACION XY mixta: di_in!=di_out y di_branch en (di_in,di_out) -> mirror_y_local=True"
                        )

                if debug_te_pos:
                    try:
                        _e, _verts = brep.GetVertices()
                        if _verts:
                            minx = min(v.X for v in _verts)
                            miny = min(v.Y for v in _verts)
                            minz = min(v.Z for v in _verts)
                            maxx = max(v.X for v in _verts)
                            maxy = max(v.Y for v in _verts)
                            maxz = max(v.Z for v in _verts)
                            cx = (minx + maxx) * 0.5
                            cy = (miny + maxy) * 0.5
                            cz = (minz + maxz) * 0.5
                            print(
                                "[DBG TE POS] BREP_LOCAL bbox_min=(%.3f,%.3f,%.3f) bbox_max=(%.3f,%.3f,%.3f) bbox_center=(%.3f,%.3f,%.3f)"
                                % (minx, miny, minz, maxx, maxy, maxz, cx, cy, cz)
                            )
                        print(
                            "[DBG TE POS] APPLY_MOVE world_node=(%.3f,%.3f,%.3f) (Move after transforms)"
                            % (p_destino.X, p_destino.Y, p_destino.Z)
                        )
                    except Exception:
                        pass

                if debug_te:
                    print(
                        "[DBG TE] APPLY node=(%.3f,%.3f,%.3f) plane=%s ang=%.1f° mx=%s my=%s mz=%s elevated=%s offset_perp=%.2f"
                        % (
                            round(p_destino.X, 3),
                            round(p_destino.Y, 3),
                            round(p_destino.Z, 3),
                            plane,
                            math.degrees(ang),
                            str(need_mx),
                            str(need_my),
                            str(need_mz),
                            str(branch_elevated),
                            offset_perp_local,
                        )
                    )
                    print(
                        "[DBG TE] MODEL_FLAGS model_mirror_x=%s di_in=%s di_out=%s di_branch=%s"
                        % (
                            str(model_mirror_x),
                            str(di_in),
                            str(di_out),
                            str(di_branch),
                        )
                    )

                mat = AllplanGeo.Matrix3D()
                # Mirrors locales como en fontaneria: SIEMPRE antes de rotaciones (independiente del plano)
                if need_mx:
                    mirror_mat = AllplanGeo.Matrix3D()
                    mirror_mat.SetScaling(1, -1, 1)
                    mat = mat * mirror_mat
                if need_my:
                    mirror_mat = AllplanGeo.Matrix3D()
                    mirror_mat.SetScaling(-1, -1, 1)
                    mat = mat * mirror_mat

                # Desplazamiento local perpendicular al troncal (offset de centrado)
                if abs(offset_perp_local) > 1e-3 and plane == "XY":
                    # En XY, el eje perpendicular al troncal (X) es el eje Y local.
                    brep = AllplanGeo.Move(
                        brep, AllplanGeo.Vector3D(0.0, offset_perp_local, 0.0)
                    )

                # Caso especial robusto: troncal casi vertical (Z). La orientación por plano es ambigua,
                # así que alineamos X local -> troncal (3D) y luego giramos alrededor del troncal para
                # alinear Y local -> rama. Esto evita inversiones en el caso (Z + rama ±Y).
                try:
                    if (
                        isinstance(main_dir_3d, (list, tuple))
                        and isinstance(branch_dir_3d, (list, tuple))
                        and len(main_dir_3d) == 3
                        and len(branch_dir_3d) == 3
                    ):
                        mx, my, mz = (
                            float(main_dir_3d[0]),
                            float(main_dir_3d[1]),
                            float(main_dir_3d[2]),
                        )
                        bx, by, bz = (
                            float(branch_dir_3d[0]),
                            float(branch_dir_3d[1]),
                            float(branch_dir_3d[2]),
                        )

                        mnorm = math.sqrt(mx * mx + my * my + mz * mz)
                        bnorm = math.sqrt(bx * bx + by * by + bz * bz)
                        if mnorm > 1e-9 and bnorm > 1e-9:
                            mx, my, mz = mx / mnorm, my / mnorm, mz / mnorm
                            bx, by, bz = bx / bnorm, by / bnorm, bz / bnorm

                            if abs(mx) < 0.05 and abs(my) < 0.05 and abs(mz) > 0.95:
                                if debug_te:
                                    print(
                                        "[DBG TE] SPECIAL_VERTICAL main=(%.3f,%.3f,%.3f) branch=(%.3f,%.3f,%.3f)"
                                        % (mx, my, mz, bx, by, bz)
                                    )
                                # Secuencia determinista (estable): X local -> ±Z con rotación fija en Y,
                                # luego yaw en Z para alinear +Y local con la proyección de la rama (XY).
                                axis_y = AllplanGeo.Line3D(
                                    AllplanGeo.Point3D(0, 0, 0),
                                    AllplanGeo.Point3D(0, 1, 0),
                                )
                                axis_z = AllplanGeo.Line3D(
                                    AllplanGeo.Point3D(0, 0, 0),
                                    AllplanGeo.Point3D(0, 0, 1),
                                )

                                # X->+Z: rotY(-90°). X->-Z: rotY(+90°).
                                r_main = AllplanGeo.Matrix3D()
                                r_main.SetRotation(
                                    axis_y,
                                    AllplanGeo.Angle(
                                        -math.pi / 2 if mz >= 0 else math.pi / 2
                                    ),
                                )
                                mat = mat * r_main

                                # Yaw TE vertical:
                                # 1) tomar ángulo de la rama en XY respecto al eje X
                                #    (atan2(by, bx)),
                                # 2) aplicar desfase local de -90° del modelo TE.
                                if abs(bx) + abs(by) > 1e-9:
                                    ref_orientation = getattr(
                                        self, "reference_orientation_angle", None
                                    )
                                    theta_branch_xy = math.atan2(by, bx)
                                    theta_base = theta_branch_xy
                                    theta_source = "branch atan2(by,bx)"
                                    if not math.isfinite(theta_base):
                                        theta_base = (
                                            float(ref_orientation)
                                            if ref_orientation is not None
                                            else 0.0
                                        )
                                        theta_source = (
                                            "reference_orientation_angle"
                                            if ref_orientation is not None
                                            else "fallback=0"
                                        )
                                    theta = theta_base - (math.pi / 2.0)
                                    if debug_te:
                                        print(
                                            "[DBG TE] SPECIAL_VERTICAL theta=%.1f° (base=%.1f° source=%s, branch_xy=%.1f°, ref=%s, offset=-90°)"
                                            % (
                                                math.degrees(theta),
                                                math.degrees(theta_base),
                                                theta_source,
                                                math.degrees(theta_branch_xy),
                                                (
                                                    "%.1f°"
                                                    % math.degrees(
                                                        float(ref_orientation)
                                                    )
                                                )
                                                if ref_orientation is not None
                                                else "None",
                                            )
                                        )
                                    r_yaw = AllplanGeo.Matrix3D()
                                    r_yaw.SetRotation(axis_z, AllplanGeo.Angle(theta))
                                    mat = mat * r_yaw

                                if need_mz:
                                    mirror_z_mat = AllplanGeo.Matrix3D()
                                    mirror_z_mat.SetScaling(1, 1, -1)
                                    mat = mat * mirror_z_mat

                                brep = AllplanGeo.Transform(brep, mat)
                                brep = AllplanGeo.Move(
                                    brep,
                                    AllplanGeo.Vector3D(
                                        p_destino.X, p_destino.Y, p_destino.Z
                                    ),
                                )
                                return _build_model_with_source_attrs(brep)
                except Exception:
                    pass

                # --- Plano XY (comportamiento existente) ---
                if plane == "XY":
                    if debug_te:
                        print("[DBG TE] PATH=XY")
                    axis_z = AllplanGeo.Line3D(
                        AllplanGeo.Point3D(0, 0, 0), AllplanGeo.Point3D(0, 0, 1)
                    )

                    rot_mat = AllplanGeo.Matrix3D()
                    rot_mat.SetRotation(axis_z, AllplanGeo.Angle(ang))
                    mat = mat * rot_mat

                    if branch_elevated:
                        if debug_te:
                            print(
                                "[DBG TE] XY branch_elevated: rotate branch -90° + mirror_z=%s"
                                % str(need_mz)
                            )
                        axis_x_rotated = AllplanGeo.Line3D(
                            AllplanGeo.Point3D(0, 0, 0),
                            AllplanGeo.Point3D(math.cos(ang), math.sin(ang), 0),
                        )
                        rot_branch_mat = AllplanGeo.Matrix3D()
                        rot_branch_mat.SetRotation(
                            axis_x_rotated, AllplanGeo.Angle(-math.pi / 2)
                        )
                        mat = mat * rot_branch_mat

                        if need_mz:
                            mirror_z_mat = AllplanGeo.Matrix3D()
                            mirror_z_mat.SetScaling(1, 1, -1)
                            mat = mat * mirror_z_mat

                # --- Plano XZ: preparar XY->XZ y rotar alrededor de Y ---
                elif plane == "XZ":
                    if debug_te:
                        print("[DBG TE] PATH=XZ")
                    axis_x = AllplanGeo.Line3D(
                        AllplanGeo.Point3D(0, 0, 0), AllplanGeo.Point3D(1, 0, 0)
                    )
                    axis_y = AllplanGeo.Line3D(
                        AllplanGeo.Point3D(0, 0, 0), AllplanGeo.Point3D(0, 1, 0)
                    )

                    # Preparación: “acostar” el modelo de XY a XZ (Y local pasa a Z)
                    prep = AllplanGeo.Matrix3D()
                    prep.SetRotation(axis_x, AllplanGeo.Angle(-math.pi / 2))
                    mat = mat * prep

                    rot = AllplanGeo.Matrix3D()
                    rot.SetRotation(axis_y, AllplanGeo.Angle(ang))
                    mat = mat * rot

                    if branch_elevated:
                        trunk_axis = AllplanGeo.Line3D(
                            AllplanGeo.Point3D(0, 0, 0),
                            AllplanGeo.Point3D(math.cos(ang), 0.0, math.sin(ang)),
                        )
                        rot_branch_mat = AllplanGeo.Matrix3D()
                        rot_branch_mat.SetRotation(
                            trunk_axis, AllplanGeo.Angle(-math.pi / 2)
                        )
                        mat = mat * rot_branch_mat

                        if need_mz:
                            mirror_z_mat = AllplanGeo.Matrix3D()
                            mirror_z_mat.SetScaling(1, 1, -1)
                            mat = mat * mirror_z_mat

                # --- Plano YZ: preparar XY->YZ y rotar alrededor de X ---
                elif plane == "YZ":
                    if debug_te:
                        print("[DBG TE] PATH=YZ")
                    axis_z = AllplanGeo.Line3D(
                        AllplanGeo.Point3D(0, 0, 0), AllplanGeo.Point3D(0, 0, 1)
                    )
                    axis_x = AllplanGeo.Line3D(
                        AllplanGeo.Point3D(0, 0, 0), AllplanGeo.Point3D(1, 0, 0)
                    )

                    # Preparación: girar 90° en Z para que X local pase a Y global
                    prep = AllplanGeo.Matrix3D()
                    # Nota: para replicar la mano/convención de fontaneria.py en YZ,
                    # el mapeo correcto es -90° (evita que la TE quede “al lado contrario”).
                    prep.SetRotation(axis_z, AllplanGeo.Angle(-math.pi / 2))
                    mat = mat * prep

                    rot = AllplanGeo.Matrix3D()
                    rot.SetRotation(axis_x, AllplanGeo.Angle(ang))
                    mat = mat * rot

                    if branch_elevated:
                        trunk_axis = AllplanGeo.Line3D(
                            AllplanGeo.Point3D(0, 0, 0),
                            AllplanGeo.Point3D(0.0, math.cos(ang), math.sin(ang)),
                        )
                        rot_branch_mat = AllplanGeo.Matrix3D()
                        rot_branch_mat.SetRotation(
                            trunk_axis, AllplanGeo.Angle(-math.pi / 2)
                        )
                        mat = mat * rot_branch_mat

                        if need_mz:
                            mirror_z_mat = AllplanGeo.Matrix3D()
                            mirror_z_mat.SetScaling(1, 1, -1)
                            mat = mat * mirror_z_mat

                brep = AllplanGeo.Transform(brep, mat)
                brep = AllplanGeo.Move(
                    brep, AllplanGeo.Vector3D(p_destino.X, p_destino.Y, p_destino.Z)
                )
                return _build_model_with_source_attrs(brep)

        # Para codos (45/90), usamos la lógica completa legacy por puntos,
        # y evitamos el pipeline simplificado pitch/yaw de abajo.
        if elem_type in ("codo_90", "codo_45") and next_seg:
            from .elbow_orientation import apply_elbow_transform

            p_prev = getattr(segment_data, "start", None)
            p_mid = getattr(segment_data, "end", None)
            p_next = getattr(next_seg, "end", None)
            ref = getattr(self, "reference_orientation_angle", None)
            if p_prev and p_mid and p_next:
                brep = apply_elbow_transform(
                    brep,
                    p_prev=p_prev,
                    p_mid=p_mid,
                    p_next=p_next,
                    reference_orientation_angle=ref,
                    elbow_kind=elem_type,
                )
                # Traslado final al mundo y retorno (saltamos el resto de rotaciones)
                brep = AllplanGeo.Move(
                    brep, AllplanGeo.Vector3D(p_destino.X, p_destino.Y, p_destino.Z)
                )
                return _build_model_with_source_attrs(brep)

        # Manguito en transición vertical: aplicar la misma prioridad de orientación
        # que en fontaneria (orientación capturada o tramo horizontal previo).
        if elem_type == "manguito" and next_seg:
            p_prev = getattr(segment_data, "start", None)
            p_mid = getattr(segment_data, "end", None)
            p_next = getattr(next_seg, "end", None)
            if p_prev is not None and p_mid is not None and p_next is not None:
                dx = p_next.X - p_prev.X
                dy = p_next.Y - p_prev.Y
                dz = p_next.Z - p_prev.Z
                is_vertical_transition = (
                    abs(dx) < 1e-6 and abs(dy) < 1e-6 and abs(dz) > 1e-6
                )

                if is_vertical_transition:
                    yaw_ref = self._resolve_vertical_rotation_angle(p_prev, p_mid)
                    mat = AllplanGeo.Matrix3D()

                    if abs(yaw_ref) > 1e-6:
                        axis_z = AllplanGeo.Line3D(
                            AllplanGeo.Point3D(0, 0, 0),
                            AllplanGeo.Point3D(0, 0, 1),
                        )
                        mat_z = AllplanGeo.Matrix3D()
                        mat_z.SetRotation(axis_z, AllplanGeo.Angle(yaw_ref))
                        mat = mat_z

                    axis_y = AllplanGeo.Line3D(
                        AllplanGeo.Point3D(0, 0, 0),
                        AllplanGeo.Point3D(0, 1, 0),
                    )
                    angle_y = -math.pi / 2.0 if dz > 0 else math.pi / 2.0
                    mat_y = AllplanGeo.Matrix3D()
                    mat_y.SetRotation(axis_y, AllplanGeo.Angle(angle_y))

                    mat = mat_y * mat if abs(yaw_ref) > 1e-6 else mat_y
                    brep = AllplanGeo.Transform(brep, mat)
                    brep = AllplanGeo.Move(
                        brep, AllplanGeo.Vector3D(p_destino.X, p_destino.Y, p_destino.Z)
                    )
                    return _build_model_with_source_attrs(brep)

        # 2.1. Orientación Base (Poner de pie si el destino es vertical)
        # Si el codo debe ir en vertical, primero rotamos 90° en su eje X local
        if elem_type in ("codo_90", "codo_45") and next_seg:
            angulo_rotacion = (
                segment_data.angulo_z
                if int(segment_data.angulo_z) != 0
                else next_seg.angulo_z
            )
            matriz_vertical = AllplanGeo.Matrix3D()
            eje_x_local = AllplanGeo.Line3D(
                AllplanGeo.Point3D(0, 0, 0), AllplanGeo.Point3D(1, 0, 0)
            )
            # Lo rotamos para que apunte hacia arriba/abajo antes de la rotación final
            matriz_vertical.SetRotation(
                eje_x_local, AllplanGeo.Angle.FromDeg(angulo_rotacion)
            )
            brep = AllplanGeo.Transform(brep, matriz_vertical)

        # 2.2. Inclinación Específica (Pitch)
        angulo_pitch = 0.0
        if elem_type in ["conducto", "conexion", "manguito"]:
            angulo_pitch = segment_data.angulo_z
        elif elem_type in ("codo_90", "codo_45") and next_seg:
            angulo_pitch = -(next_seg.angulo_z + segment_data.angulo_z)
            if int(segment_data.angulo_z) in [90, -90] and int(next_seg.angulo_xy) == 0:
                angulo_pitch = next_seg.angulo_z + segment_data.angulo_z
            elif int(next_seg.angulo_xy) == 180:
                angulo_pitch = next_seg.angulo_xy * 2

        if abs(angulo_pitch) > 0.01:
            matriz_pitch = AllplanGeo.Matrix3D()
            # Eje Y local como pivote de elevación
            eje_y_pitch = AllplanGeo.Line3D(
                AllplanGeo.Point3D(0, 0, 0), AllplanGeo.Point3D(0, 1, 0)
            )
            matriz_pitch.SetRotation(
                eje_y_pitch, AllplanGeo.Angle.FromDeg(-angulo_pitch)
            )
            brep = AllplanGeo.Transform(brep, matriz_pitch)

        # ==========================================
        # PARTE 3: LÓGICA HORIZONTAL (YAW / XY)
        # ==========================================
        angulo_yaw = 0.0
        if elem_type in ["conducto", "conexion", "manguito", "te"]:
            angulo_yaw = (
                float(custom_yaw_deg)
                if custom_yaw_deg is not None
                else segment_data.angulo_xy
            )
            # Port de fontaneria.py para verticales:
            # si el tramo es vertical y no hay yaw explícito, usar orientación capturada
            # (o, en su defecto, el ángulo del tramo previo horizontal).
            if custom_yaw_deg is None:
                try:
                    v = getattr(segment_data, "vector_normalizado", None)
                    is_vertical_seg = (
                        v is not None
                        and abs(v.X) < 1e-6
                        and abs(v.Y) < 1e-6
                        and abs(v.Z) > 1e-6
                    )
                    if is_vertical_seg:
                        prev_start = getattr(prev_seg, "start", None)
                        prev_end = getattr(prev_seg, "end", None)
                        # Heredar yaw del tramo horizontal anterior cuando exista.
                        # Si no existe, mantener fallback actual.
                        p_ref_start = (
                            prev_start
                            if prev_start is not None and prev_end is not None
                            else getattr(segment_data, "start", None)
                        )
                        p_ref_end = (
                            prev_end
                            if prev_start is not None and prev_end is not None
                            else getattr(segment_data, "end", None)
                        )
                        ref_yaw = self._resolve_vertical_rotation_angle(
                            p_ref_start,
                            p_ref_end,
                        )
                        if abs(ref_yaw) > 1e-6:
                            angulo_yaw = math.degrees(ref_yaw)
                except Exception:
                    pass
        else:
            # AJUSTE ESPECIAL PARA CODOS
            # En el nodo del codo, el tramo de ENTRADA es el segmento actual,
            # y el tramo de SALIDA es el siguiente segmento.
            v_entrada = segment_data.vector_normalizado
            v_salida = next_seg.vector_normalizado  # type: ignore

            # Inversión de cara (Flip) si el giro es a la derecha
            cross_z = v_entrada.X * v_salida.Y - v_entrada.Y * v_salida.X
            if cross_z < 0:
                m_flip = AllplanGeo.Matrix3D()
                m_flip.Rotation(
                    AllplanGeo.Line3D(
                        AllplanGeo.Point3D(0, 0, 0), AllplanGeo.Point3D(1, 0, 0)
                    ),
                    AllplanGeo.Angle.FromDeg(180),
                )
                brep = AllplanGeo.Transform(brep, m_flip)

            # Ángulo basado en la dirección de salida
            angulo_yaw = self.obtener_rotacion_codo(v_salida)

        # Aplicar rotación horizontal final
        matriz_yaw = AllplanGeo.Matrix3D()
        eje_z_global = AllplanGeo.Line3D(
            AllplanGeo.Point3D(0, 0, 0), AllplanGeo.Point3D(0, 0, 1)
        )
        matriz_yaw.Rotation(eje_z_global, AllplanGeo.Angle.FromDeg(angulo_yaw))
        brep = AllplanGeo.Transform(brep, matriz_yaw)

        # ==========================================
        # PARTE 4: AJUSTES DE ALINEACIÓN Y TRASLACIÓN
        # ==========================================
        if elem_type == "codo_90":
            # Alineamos el codo con la bisectriz para que encaje con los recortes
            v_bisector = AllplanGeo.Vector3D(
                v_entrada.X - v_salida.X,
                v_entrada.Y - v_salida.Y,
                v_entrada.Z - v_salida.Z,
            )
            v_bisector.Normalize()
            dist_ajuste = (self.offset_codo / 2.0) - 2.3
            brep = AllplanGeo.Move(brep, v_bisector * dist_ajuste)

        # Traslado a la coordenada real en el espacio Allplan
        brep = AllplanGeo.Move(
            brep, AllplanGeo.Vector3D(p_destino.X, p_destino.Y, p_destino.Z)
        )

        return _build_model_with_source_attrs(brep)

    def process(self, segments, default_attrs=None, segment_cuts=None) -> list:
        """
        Procesa los segmentos y ubica conductos y codos con soporte
        para pendientes verticales (Pitch). Sin conexiones.

        segment_cuts: opcional dict {seg_idx: {"start": mm, "end": mm}} con recortes
        por codo/manguito (véase vertex_utils.compute_segment_cuts_for_path).
        Si se omite o está vacío, se calculan aquí (evita desincronía con el hook).
        """
        result_list = []
        element_index = 0
        num_seg = len(segments)
        from .vertex_utils import compute_segment_cuts_for_path, is_90_deg_turn, is_straight_turn

        if not segment_cuts:
            segment_cuts = compute_segment_cuts_for_path(segments)
        else:
            segment_cuts = {
                int(k): {
                    "start": float(v.get("start", 0.0)),
                    "end": float(v.get("end", 0.0)),
                }
                for k, v in segment_cuts.items()
            }

        # Detección de giros (90° y 45°)

        # info de TE: opcional, se puede inyectar desde fuera
        te_nodes = getattr(self, "te_nodes", {}) or {}
        inserted_te_keys = set()
        cross_path_elbows = getattr(self, "cross_path_elbows", {}) or {}
        inserted_cross_path_elbows = set()
        cross_path_manguitos = getattr(self, "cross_path_manguitos", {}) or {}
        inserted_cross_path_manguitos = set()
        debug_te_pos = str(os.getenv("AGUA_DEBUG_TE_POS", "1")).strip() not in (
            "",
            "0",
            "false",
            "False",
        )

        def _build_aux_seg_data(p_start, p_end):
            """Construye un objeto mínimo compatible con _aplicar_transformacion(codo)."""
            obj = type("AuxSegData", (), {})()
            obj.start = p_start
            obj.end = p_end
            dx = p_end.X - p_start.X
            dy = p_end.Y - p_start.Y
            dz = p_end.Z - p_start.Z
            ln = math.sqrt(dx * dx + dy * dy + dz * dz)
            if ln > 1e-9:
                obj.vector_normalizado = AllplanGeo.Vector3D(dx / ln, dy / ln, dz / ln)
            else:
                obj.vector_normalizado = AllplanGeo.Vector3D(0.0, 0.0, 0.0)
            obj.angulo_xy = math.degrees(math.atan2(dy, dx)) if ln > 1e-9 else 0.0
            obj.angulo_z = 0.0
            return obj

        def _xy_turn_angle_deg(p1, p2, p3) -> float | None:
            """Ángulo interior XY en el vértice p2, en rango [0, 180]."""
            try:
                v1x = p2.X - p1.X
                v1y = p2.Y - p1.Y
                v2x = p3.X - p2.X
                v2y = p3.Y - p2.Y
                n1 = math.hypot(v1x, v1y)
                n2 = math.hypot(v2x, v2y)
                if n1 < 1e-9 or n2 < 1e-9:
                    return None
                a1 = math.degrees(math.atan2(v1y, v1x))
                a2 = math.degrees(math.atan2(v2y, v2x))
                diff = abs((a2 - a1) % 360.0)
                if diff > 180.0:
                    diff = 360.0 - diff
                return float(diff)
            except Exception:
                return None

        def _turn_angle_3d_deg(p1, p2, p3) -> float | None:
            """Ángulo 3D entre tramos en p2, en rango [0, 180]."""
            try:
                v1x = p2.X - p1.X
                v1y = p2.Y - p1.Y
                v1z = p2.Z - p1.Z
                v2x = p3.X - p2.X
                v2y = p3.Y - p2.Y
                v2z = p3.Z - p2.Z
                n1 = math.sqrt(v1x * v1x + v1y * v1y + v1z * v1z)
                n2 = math.sqrt(v2x * v2x + v2y * v2y + v2z * v2z)
                if n1 < 1e-9 or n2 < 1e-9:
                    return None
                dot = (v1x * v2x + v1y * v2y + v1z * v2z) / (n1 * n2)
                dot = max(-1.0, min(1.0, dot))
                return float(math.degrees(math.acos(dot)))
            except Exception:
                return None

        def _is_45_deg_turn_legacy(p_prev, p_curr, p_next) -> bool:
            """
            Port literal del criterio de Saneamiento_old._is_45_deg_turn:
            - ángulo ~45° o ~135° (complemento) con tolerancia,
            - valida composición diagonal por componentes no nulas.
            """
            if not (p_prev and p_curr and p_next):
                return False
            eps = 1e-6
            v1 = (
                p_curr.X - p_prev.X,
                p_curr.Y - p_prev.Y,
                p_curr.Z - p_prev.Z,
            )
            v2 = (
                p_next.X - p_curr.X,
                p_next.Y - p_curr.Y,
                p_next.Z - p_curr.Z,
            )
            if (
                abs(v1[0]) < eps
                and abs(v1[1]) < eps
                and abs(v1[2]) < eps
            ) or (
                abs(v2[0]) < eps
                and abs(v2[1]) < eps
                and abs(v2[2]) < eps
            ):
                return False

            len1 = math.sqrt(v1[0] * v1[0] + v1[1] * v1[1] + v1[2] * v1[2])
            len2 = math.sqrt(v2[0] * v2[0] + v2[1] * v2[1] + v2[2] * v2[2])
            if len1 < eps or len2 < eps:
                return False

            v1_norm = (v1[0] / len1, v1[1] / len1, v1[2] / len1)
            v2_norm = (v2[0] / len2, v2[1] / len2, v2[2] / len2)
            dot_product = (
                v1_norm[0] * v2_norm[0]
                + v1_norm[1] * v2_norm[1]
                + v1_norm[2] * v2_norm[2]
            )
            dot_product = max(-1.0, min(1.0, dot_product))
            angle_deg = math.degrees(math.acos(dot_product))
            tolerance = 5.0
            is_45_deg = (
                abs(angle_deg - 45.0) < tolerance
                or abs(angle_deg - 135.0) < tolerance
            )

            def _count_non_zero_components(v):
                return sum(1 for comp in v if abs(comp) > eps)

            v1_non_zero = _count_non_zero_components(v1)
            v2_non_zero = _count_non_zero_components(v2)
            has_diagonal_components = (
                (v1_non_zero >= 2 and v2_non_zero >= 2)
                or (v1_non_zero == 1 and v2_non_zero == 1)
                or (v1_non_zero == 1 and v2_non_zero == 2)
                or (v1_non_zero == 2 and v2_non_zero == 1)
            )
            return is_45_deg and has_diagonal_components

        def _get_turn_fitting_type(p1, p2, p3):
            """Devuelve 'codo_90', 'codo_45' o None según el giro y templates disponibles."""
            if not (p1 and p2 and p3):
                return None

            # Evaluación principal por ángulo 3D (port legacy).
            ang3d = _turn_angle_3d_deg(p1, p2, p3)
            if ang3d is not None:
                if abs(ang3d) <= 1.0 or abs(ang3d - 180.0) <= 1.0:
                    return None
                if _is_45_deg_turn_legacy(p1, p2, p3) and "codo_45" in self.templates:
                    return "codo_45"
                if abs(ang3d - 90.0) <= 10.0 and "codo_90" in self.templates:
                    return "codo_90"

            # Importante: decidir por ángulo real en planta para no confundir
            # un 45° con 90° por lógica de "eje dominante".
            ang = _xy_turn_angle_deg(p1, p2, p3)
            if ang is not None:
                if abs(ang - 45.0) <= 7.5 and "codo_45" in self.templates:
                    return "codo_45"
                if abs(ang - 90.0) <= 7.5 and "codo_90" in self.templates:
                    return "codo_90"

            # Fallback final: detector heredado.
            if is_90_deg_turn(p1, p2, p3) and "codo_90" in self.templates:
                return "codo_90"
            return None

        def _is_double45_vertex(p_prev, p_curr, p_next) -> bool:
            """True si el vértice se resolverá como 90° sin cambio de plano -> 2x45."""
            try:
                turn = _get_turn_fitting_type(p_prev, p_curr, p_next)
                if turn != "codo_90" or "codo_45" not in self.templates:
                    return False

                seg1_vert = (
                    abs(p_curr.X - p_prev.X) < 1e-6
                    and abs(p_curr.Y - p_prev.Y) < 1e-6
                    and abs(p_curr.Z - p_prev.Z) > 1e-6
                )
                seg2_vert = (
                    abs(p_next.X - p_curr.X) < 1e-6
                    and abs(p_next.Y - p_curr.Y) < 1e-6
                    and abs(p_next.Z - p_curr.Z) > 1e-6
                )
                is_plane_change = (seg1_vert and not seg2_vert) or (
                    seg2_vert and not seg1_vert
                )
                return not is_plane_change
            except Exception:
                return False

        def _segment_diameter_int(seg_idx: int):
            info = getattr(segments[seg_idx], "info", None)
            diam = getattr(info, "diameter", None) if info is not None else None
            if isinstance(diam, (list, tuple)) and diam:
                diam = diam[0]
            if diam is None:
                return None
            try:
                return int(round(float(diam)))
            except Exception:
                return None

        def _segment_is_fecal(seg_idx: int) -> bool:
            info = getattr(segments[seg_idx], "info", None)
            raw = getattr(info, "system", None) if info is not None else None
            txt = str(raw or "").strip().lower()
            return txt.startswith("fecal")

        def _is_single_codo90_vertex(
            p_prev, p_curr, p_next, seg_idx_for_diam: int, diam_target: int
        ) -> bool:
            """True si el vértice es codo_90 real del diámetro indicado."""
            try:
                if _is_double45_vertex(p_prev, p_curr, p_next):
                    return False
                if _get_turn_fitting_type(p_prev, p_curr, p_next) != "codo_90":
                    return False

                diam = _segment_diameter_int(seg_idx_for_diam)
                return diam == diam_target
            except Exception:
                return False

        def _is_single_codo45_vertex(
            p_prev, p_curr, p_next, seg_idx_for_diam: int, diam_target: int
        ) -> bool:
            """True si el vértice es codo_45 individual del diámetro indicado."""
            try:
                if _is_double45_vertex(p_prev, p_curr, p_next):
                    return False
                if _get_turn_fitting_type(p_prev, p_curr, p_next) != "codo_45":
                    return False

                diam = _segment_diameter_int(seg_idx_for_diam)
                return diam == diam_target
            except Exception:
                return False

        for i, seg_item in enumerate(segments):
            seg = seg_item.data
            v_unit = seg.vector_normalizado

            # -------------------------------------------------------
            # 1. DETERMINAR RECORTES (Offsets por codo + recortes por fitting)
            # -------------------------------------------------------
            offset_inicio = 0.0
            offset_final = 0.0

            if i > 0:
                # offset inicio si en el vértice start del segmento actual hay codo
                p_prev = getattr(segments[i - 1].data, "start", None)
                p_curr = getattr(segments[i - 1].data, "end", None)
                p_next = getattr(seg, "end", None)
                if _get_turn_fitting_type(p_prev, p_curr, p_next):
                    offset_inicio = self.offset_codo
                # trim_out para 2x45: recorta el arranque del tramo saliente del vértice.
                if _is_double45_vertex(p_prev, p_curr, p_next):
                    cuts = segment_cuts.setdefault(i, {"start": 0.0, "end": 0.0})
                    diam = _segment_diameter_int(i)
                    cuts["start"] = float(cuts.get("start", 0.0)) + (
                        DOUBLE45_110_TRIM_OUT_MM
                        if diam == 110
                        else (DOUBLE45_40_TRIM_OUT_MM if diam == 40 else DOUBLE45_TRIM_OUT_MM)
                    )
                # trim_out para codo_90 real Ø25/Ø40.
                if _is_single_codo90_vertex(p_prev, p_curr, p_next, i, 25):
                    cuts = segment_cuts.setdefault(i, {"start": 0.0, "end": 0.0})
                    cuts["start"] = float(cuts.get("start", 0.0)) + CODO90_25_TRIM_OUT_MM
                if _is_single_codo90_vertex(p_prev, p_curr, p_next, i, 40):
                    cuts = segment_cuts.setdefault(i, {"start": 0.0, "end": 0.0})
                    cuts["start"] = float(cuts.get("start", 0.0)) + CODO90_40_TRIM_OUT_MM
                if _is_single_codo90_vertex(p_prev, p_curr, p_next, i, 110):
                    cuts = segment_cuts.setdefault(i, {"start": 0.0, "end": 0.0})
                    trim_out_110 = (
                        CODO90_110_FECAL_TRIM_OUT_MM
                        if _segment_is_fecal(i)
                        else CODO90_110_TRIM_OUT_MM
                    )
                    cuts["start"] = float(cuts.get("start", 0.0)) + trim_out_110
                # trim_out para codo_45 individual Ø25/Ø40.
                if _is_single_codo45_vertex(p_prev, p_curr, p_next, i, 25):
                    cuts = segment_cuts.setdefault(i, {"start": 0.0, "end": 0.0})
                    cuts["start"] = float(cuts.get("start", 0.0)) + CODO45_25_TRIM_OUT_MM
                if _is_single_codo45_vertex(p_prev, p_curr, p_next, i, 40):
                    cuts = segment_cuts.setdefault(i, {"start": 0.0, "end": 0.0})
                    cuts["start"] = float(cuts.get("start", 0.0)) + CODO45_40_TRIM_OUT_MM
                if _is_single_codo45_vertex(p_prev, p_curr, p_next, i, 110):
                    cuts = segment_cuts.setdefault(i, {"start": 0.0, "end": 0.0})
                    cuts["start"] = float(cuts.get("start", 0.0)) + CODO45_110_TRIM_OUT_MM

            if i < num_seg - 1:
                # offset final si en el vértice end del segmento actual hay codo
                next_seg = segments[i + 1].data
                p_prev = getattr(seg, "start", None)
                p_curr = getattr(seg, "end", None)
                p_next = getattr(next_seg, "end", None)
                if _get_turn_fitting_type(p_prev, p_curr, p_next):
                    offset_final = self.offset_codo
                # trim_in para 2x45: recorta el final del tramo entrante al vértice.
                if _is_double45_vertex(p_prev, p_curr, p_next):
                    cuts = segment_cuts.setdefault(i, {"start": 0.0, "end": 0.0})
                    diam = _segment_diameter_int(i)
                    cuts["end"] = float(cuts.get("end", 0.0)) + (
                        DOUBLE45_110_TRIM_IN_MM
                        if diam == 110
                        else (DOUBLE45_40_TRIM_IN_MM if diam == 40 else DOUBLE45_TRIM_IN_MM)
                    )
                # trim_in para codo_90 real Ø25/Ø40.
                if _is_single_codo90_vertex(p_prev, p_curr, p_next, i, 25):
                    cuts = segment_cuts.setdefault(i, {"start": 0.0, "end": 0.0})
                    cuts["end"] = float(cuts.get("end", 0.0)) + CODO90_25_TRIM_IN_MM
                if _is_single_codo90_vertex(p_prev, p_curr, p_next, i, 40):
                    cuts = segment_cuts.setdefault(i, {"start": 0.0, "end": 0.0})
                    cuts["end"] = float(cuts.get("end", 0.0)) + CODO90_40_TRIM_IN_MM
                if _is_single_codo90_vertex(p_prev, p_curr, p_next, i, 110):
                    cuts = segment_cuts.setdefault(i, {"start": 0.0, "end": 0.0})
                    trim_in_110 = (
                        CODO90_110_FECAL_TRIM_IN_MM
                        if _segment_is_fecal(i)
                        else CODO90_110_TRIM_IN_MM
                    )
                    cuts["end"] = float(cuts.get("end", 0.0)) + trim_in_110
                # trim_in para codo_45 individual Ø25/Ø40.
                if _is_single_codo45_vertex(p_prev, p_curr, p_next, i, 25):
                    cuts = segment_cuts.setdefault(i, {"start": 0.0, "end": 0.0})
                    cuts["end"] = float(cuts.get("end", 0.0)) + CODO45_25_TRIM_IN_MM
                if _is_single_codo45_vertex(p_prev, p_curr, p_next, i, 40):
                    cuts = segment_cuts.setdefault(i, {"start": 0.0, "end": 0.0})
                    cuts["end"] = float(cuts.get("end", 0.0)) + CODO45_40_TRIM_IN_MM
                if _is_single_codo45_vertex(p_prev, p_curr, p_next, i, 110):
                    cuts = segment_cuts.setdefault(i, {"start": 0.0, "end": 0.0})
                    cuts["end"] = float(cuts.get("end", 0.0)) + CODO45_110_TRIM_IN_MM

            cuts = segment_cuts.get(i, {"start": 0.0, "end": 0.0})
            cut_start = float(cuts.get("start", 0.0))
            cut_end = float(cuts.get("end", 0.0))

            # -------------------------------------------------------
            # 2. CONDUCTO (TRAMO RECTO) - OUTER + INNER (opcional)
            # -------------------------------------------------------
            if self.element_type_core in self.templates:
                longitud_recortada = (
                    seg.longitud_3d - offset_inicio - offset_final - cut_start - cut_end
                )

                if longitud_recortada > 0:
                    # Centro del tramo recortado: desde start + cut_start, mitad del tramo útil
                    dist_al_centro = cut_start + (longitud_recortada / 2.0)
                    p_centro = AllplanGeo.Point3D(
                        seg.start.X + v_unit.X * dist_al_centro,
                        seg.start.Y + v_unit.Y * dist_al_centro,
                        seg.start.Z + v_unit.Z * dist_al_centro,
                    )

                    # Diámetro/distribución por segmento (como fontaneria: no usar último global)
                    seg_info = getattr(seg_item, "info", None)
                    seg_diameter = (
                        getattr(seg_info, "diameter", 20.0)
                        if seg_info is not None
                        else 20.0
                    )
                    if isinstance(seg_diameter, (list, tuple)) and seg_diameter:
                        seg_diameter = seg_diameter[0]
                    seg_dist = (
                        getattr(seg_info, "distribution_type", "IS")
                        if seg_info is not None
                        else "IS"
                    )
                    seg_water = (
                        getattr(seg_info, "water_type", None)
                        if seg_info is not None
                        else None
                    )
                    seg_system = (
                        getattr(seg_info, "system", None) if seg_info is not None else None
                    )
                    seg_dist = "TD" if str(seg_dist).upper() == "TD" else "IS"

                    # Saneamiento: el template viene de tub_pvc_* (p. ej. tricapa_v con anillo).
                    # _get_tubo_models_for_segment normaliza "Fecal"/"Pluvial" a polietile (Agua) y
                    # puede sustituir el BRep por un tubo dinámico sin anillo.
                    if self.element_type_core == "tubo_saneamiento":
                        dynamic_tube_models = []
                    else:
                        dynamic_tube_models = self._get_tubo_models_for_segment(
                            seg_diameter,
                            distribution_type=seg_dist,
                            water_type=seg_water,
                            tube_system=seg_system,
                        )
                    tube_outer_tpl = (
                        dynamic_tube_models[0]
                        if dynamic_tube_models
                        else self.templates[self.element_type_core]
                    )
                    tube_inner_tpl = (
                        dynamic_tube_models[1]
                        if len(dynamic_tube_models) > 1
                        else self.templates.get(f"{self.element_type_core}_inner")
                    )
                    print(
                        f"[AGUA][TUBO] seg={i} diam={seg_diameter} dist={seg_dist} "
                        f"system={seg_system} "
                        f"modelo_outer={'dinamico' if dynamic_tube_models else 'template'}"
                    )

                    # OUTER
                    rebuilt_models = None
                    if (
                        self.element_type_core == "tubo_saneamiento"
                        and self.saneamiento_tube_rebuild is not None
                    ):
                        try:
                            rebuilt_models = self.saneamiento_tube_rebuild(
                                longitud_recortada, seg_info=seg_info
                            )
                        except TypeError:
                            # Compatibilidad con callbacks antiguos (solo length_mm).
                            rebuilt_models = self.saneamiento_tube_rebuild(
                                longitud_recortada
                            )
                        if isinstance(rebuilt_models, (list, tuple)):
                            model_cond = rebuilt_models[0] if rebuilt_models else None
                            # tub_pvc_basic_f_25 no consume LargoTramoMm; su modelo base
                            # sale en L=70 y debe escalarse aquí al largo del tramo.
                            try:
                                seg_d = getattr(seg_info, "diameter", None)
                                if isinstance(seg_d, (list, tuple)) and seg_d:
                                    seg_d = seg_d[0]
                                if int(seg_d) == 25 and model_cond is not None:
                                    model_cond = self.modificar_dimensiones_brep(
                                        model_cond, longitud_recortada
                                    )
                            except Exception:
                                pass
                        else:
                            model_cond = rebuilt_models
                        if model_cond is None:
                            model_cond = self.modificar_dimensiones_brep(
                                tube_outer_tpl, longitud_recortada
                            )
                    else:
                        model_cond = self.modificar_dimensiones_brep(
                            tube_outer_tpl, longitud_recortada
                        )
                    prev_seg_data = segments[i - 1].data if i > 0 else None
                    element = self._aplicar_transformacion(
                        model_cond,
                        seg,
                        custom_position=p_centro,
                        prev_seg=prev_seg_data,
                    )
                    if self.element_type_core == "tubo_saneamiento":
                        p_line_start = AllplanGeo.Point3D(
                            seg.start.X + v_unit.X * (cut_start + offset_inicio),
                            seg.start.Y + v_unit.Y * (cut_start + offset_inicio),
                            seg.start.Z + v_unit.Z * (cut_start + offset_inicio),
                        )
                        element = self._align_saneamiento_tube_along_segment(
                            element, p_line_start, v_unit
                        )

                    result_list.append(
                        {
                            "element": element,
                            "element_type": self.element_type_core,
                            "index": element_index,
                        }
                    )
                    element_index += 1

                    # Copias extra de saneamiento (p.ej. tub_pvc_basic_f_25: i=1,2).
                    if (
                        self.element_type_core == "tubo_saneamiento"
                        and self.saneamiento_extra_templates
                    ):
                        print(
                            f"[SANEAMIENTO][F25][PIPE] seg={i} extras={len(self.saneamiento_extra_templates)} "
                            f"L_recortada={longitud_recortada:.1f}"
                        )
                        for extra_idx, extra_tpl in enumerate(
                            self.saneamiento_extra_templates, start=1
                        ):
                            model_extra = self.modificar_dimensiones_brep(
                                extra_tpl, longitud_recortada
                            )
                            element_extra = self._aplicar_transformacion(
                                model_extra,
                                seg,
                                custom_position=p_centro,
                                prev_seg=prev_seg_data,
                            )
                            p_line_start = AllplanGeo.Point3D(
                                seg.start.X + v_unit.X * (cut_start + offset_inicio),
                                seg.start.Y + v_unit.Y * (cut_start + offset_inicio),
                                seg.start.Z + v_unit.Z * (cut_start + offset_inicio),
                            )
                            element_extra = self._align_saneamiento_tube_along_segment(
                                element_extra, p_line_start, v_unit
                            )
                            if abs(self.saneamiento_extra_world_offset_z_mm) > 1e-9:
                                try:
                                    prev_extra = element_extra
                                    geo_extra = element_extra.GetGeometryObject()
                                    geo_extra = AllplanGeo.Move(
                                        geo_extra,
                                        AllplanGeo.Vector3D(
                                            0.0, 0.0, self.saneamiento_extra_world_offset_z_mm
                                        ),
                                    )
                                    element_extra = AllplanBasisElements.ModelElement3D(
                                        prev_extra.GetCommonProperties(), geo_extra
                                    )
                                    try:
                                        src_attrs = (
                                            prev_extra.GetAttributes()
                                            if hasattr(prev_extra, "GetAttributes")
                                            else None
                                        )
                                        if src_attrs:
                                            element_extra.SetAttributes(src_attrs)
                                    except Exception:
                                        pass
                                except Exception:
                                    pass
                            try:
                                p = element_extra.GetCommonProperties()
                                print(
                                    f"[SANEAMIENTO][F25][PIPE] add extra_idx={extra_idx} "
                                    f"layer={getattr(p, 'Layer', None)} color={getattr(p, 'Color', None)}"
                                )
                            except Exception:
                                print(
                                    f"[SANEAMIENTO][F25][PIPE] add extra_idx={extra_idx} (props n/a)"
                                )
                            result_list.append(
                                {
                                    "element": element_extra,
                                    "element_type": f"{self.element_type_core}_copy_{extra_idx}",
                                    "index": element_index,
                                }
                            )
                            element_index += 1

                    # Saneamiento: extras dinámicos del rebuild por segmento
                    # (flecha y/o copias específicas del modelo seleccionado).
                    if rebuilt_models and isinstance(rebuilt_models, (list, tuple)):
                        dynamic_copy_idx = 0
                        for extra_model in rebuilt_models[1:]:
                            try:
                                extra_geo = extra_model.GetGeometryObject()
                                extra_props = (
                                    extra_model.GetCommonProperties()
                                    if hasattr(extra_model, "GetCommonProperties")
                                    else None
                                )
                                is_arrow_poly = type(extra_geo).__name__ == "Polygon3D"
                                is_arrow_brep = (
                                    type(extra_geo).__name__ == "BRep3D"
                                    and extra_props is not None
                                    and getattr(extra_props, "Color", None) == 27
                                    and getattr(extra_props, "Layer", None) == 40148
                                )
                                if is_arrow_poly or is_arrow_brep:
                                    element_arrow = self._aplicar_transformacion(
                                        extra_model,
                                        seg,
                                        custom_position=p_centro,
                                        prev_seg=prev_seg_data,
                                        preserve_local_offset=True,
                                    )
                                    result_list.append(
                                        {
                                            "element": element_arrow,
                                            "element_type": f"{self.element_type_core}_flecha",
                                            "index": element_index,
                                        }
                                    )
                                    element_index += 1
                                    continue

                                # Resto de BRep extras: tratarlos como copias del tramo.
                                dynamic_copy_idx += 1
                                model_extra = self.modificar_dimensiones_brep(
                                    extra_model, longitud_recortada
                                )
                                element_extra = self._aplicar_transformacion(
                                    model_extra,
                                    seg,
                                    custom_position=p_centro,
                                    prev_seg=prev_seg_data,
                                )
                                if self.element_type_core == "tubo_saneamiento":
                                    p_line_start = AllplanGeo.Point3D(
                                        seg.start.X + v_unit.X * (cut_start + offset_inicio),
                                        seg.start.Y + v_unit.Y * (cut_start + offset_inicio),
                                        seg.start.Z + v_unit.Z * (cut_start + offset_inicio),
                                    )
                                    element_extra = self._align_saneamiento_tube_along_segment(
                                        element_extra, p_line_start, v_unit
                                    )
                                result_list.append(
                                    {
                                        "element": element_extra,
                                        "element_type": f"{self.element_type_core}_copy_dyn_{dynamic_copy_idx}",
                                        "index": element_index,
                                    }
                                )
                                element_index += 1
                            except Exception:
                                continue

                    # INNER opcional: por convenio usamos "<core>_inner"
                    inner_key = f"{self.element_type_core}_inner"
                    if tube_inner_tpl is not None:
                        model_inner = self.modificar_dimensiones_brep(
                            tube_inner_tpl, longitud_recortada
                        )
                        element_inner = self._aplicar_transformacion(
                            model_inner,
                            seg,
                            custom_position=p_centro,
                            prev_seg=prev_seg_data,
                        )
                        if self.element_type_core == "tubo_saneamiento":
                            p_line_start = AllplanGeo.Point3D(
                                seg.start.X + v_unit.X * (cut_start + offset_inicio),
                                seg.start.Y + v_unit.Y * (cut_start + offset_inicio),
                                seg.start.Z + v_unit.Z * (cut_start + offset_inicio),
                            )
                            element_inner = self._align_saneamiento_tube_along_segment(
                                element_inner, p_line_start, v_unit
                            )
                        result_list.append(
                            {
                                "element": element_inner,
                                "element_type": inner_key,
                                "index": element_index,
                            }
                        )
                        element_index += 1

            # -------------------------------------------------------
            # 3. CODO EN EL NODO FINAL DEL SEGMENTO
            # -------------------------------------------------------
            if i < num_seg - 1:
                next_seg = segments[i + 1].data
                p_prev = getattr(seg, "start", None)
                p_curr = getattr(seg, "end", None)
                p_next = getattr(next_seg, "end", None)
                node_key = (
                    (round(p_curr.X, 3), round(p_curr.Y, 3), round(p_curr.Z, 3))
                    if p_curr
                    else None
                )
                te_info_at_node = te_nodes.get(node_key) if node_key else None

                # -------------------------------------------------------
                # 3.A TE (BIFURCACIÓN) EN EL NODO (si aplica)
                # -------------------------------------------------------
                if "te" in self.templates and p_curr:
                    if te_info_at_node and node_key not in inserted_te_keys:
                        inserted_te_keys.add(node_key)
                        center_pt_raw = te_info_at_node.get("center_pt")
                        if (
                            isinstance(center_pt_raw, (tuple, list))
                            and len(center_pt_raw) == 3
                        ):
                            pos_nodo = AllplanGeo.Point3D(
                                float(center_pt_raw[0]),
                                float(center_pt_raw[1]),
                                float(center_pt_raw[2]),
                            )
                        else:
                            # Fallback: conservar comportamiento previo si no hay center_pt.
                            pos_nodo = p_curr
                        yaw = float(te_info_at_node.get("yaw_deg", 0.0) or 0.0)

                        # Selección de TE por diámetro (lógica equivalente a fontaneria.py)
                        te_dist = str(
                            te_info_at_node.get("distribution_type", "IS") or "IS"
                        )
                        te_dist = "TD" if te_dist.upper() == "TD" else "IS"
                        d_main_in = te_info_at_node.get("d_main_in", None)
                        d_main_out = te_info_at_node.get("d_main_out", None)
                        d_branch = te_info_at_node.get("d_branch", None)
                        if d_main_in is None or d_main_out is None or d_branch is None:
                            # Fallback: inferir con segmento actual/siguiente para no romper.
                            try:
                                info_curr = getattr(segments[i], "info", None)
                                info_next = (
                                    getattr(segments[i + 1], "info", None)
                                    if i + 1 < len(segments)
                                    else None
                                )
                                d_main_in = getattr(info_curr, "diameter", 20.0)
                                d_main_out = getattr(info_next, "diameter", d_main_in)
                                d_branch = d_main_in
                            except Exception:
                                d_main_in = d_main_out = d_branch = 20.0

                        mirror_model_x = bool(
                            te_info_at_node.get("model_mirror_x", False)
                            or (
                                (d_main_in is not None and d_main_out is not None)
                                and int(round(float(d_main_in)))
                                < int(round(float(d_main_out)))
                            )
                        )

                        dyn_te_models = self._get_te_models_for_diameters(
                            d_main_in,
                            d_main_out,
                            d_branch,
                            distribution_type=te_dist,
                            mirror_model_x=mirror_model_x,
                        )
                        te_outer_model = (
                            dyn_te_models[0] if dyn_te_models else self.templates["te"]
                        )
                        # Algunos modelos TD de TE mixta se modelan como "inner-only"
                        # y devuelven un único BRep dinámico. En ese caso debe tratarse
                        # como te_inner (con attrs/layer de paleta) y no crear inner template.
                        is_inner_only_te = False
                        try:
                            diam_set = {
                                int(round(float(d_main_in))),
                                int(round(float(d_main_out))),
                                int(round(float(d_branch))),
                            }
                            is_inner_only_te = (
                                te_dist == "TD"
                                and len(dyn_te_models) == 1
                                and len(diam_set) > 1
                            )
                        except Exception:
                            is_inner_only_te = False
                        te_inner_model = (
                            dyn_te_models[1]
                            if len(dyn_te_models) > 1
                            else self.templates.get("te_inner")
                        )
                        print(
                            "[AGUA][TE] node=%s dist=%s di_in=%s di_out=%s di_branch=%s "
                            "modelo_outer=%s elems_dyn=%s"
                            % (
                                str(node_key),
                                te_dist,
                                str(d_main_in),
                                str(d_main_out),
                                str(d_branch),
                                "dinamico" if dyn_te_models else "template",
                                str(len(dyn_te_models)),
                            )
                        )
                        if mirror_model_x:
                            print(
                                "[AGUA][TE] mirror_model_x=True (orden invertido de set_diameters)"
                            )
                        if is_inner_only_te:
                            print(
                                "[AGUA][TE] TE TD inner-only detectada: "
                                "se trata como te_inner y se omite inner template"
                            )

                        if debug_te_pos:
                            try:
                                print(
                                    "[DBG TE POS] CREATE key=%s center_pt=(%.3f,%.3f,%.3f) pos_nodo=(%.3f,%.3f,%.3f) seg_start=(%.3f,%.3f,%.3f) seg_end=(%.3f,%.3f,%.3f) v_unit=(%.3f,%.3f,%.3f) cut_start=%.2f cut_end=%.2f"
                                    % (
                                        str(node_key),
                                        pos_nodo.X,
                                        pos_nodo.Y,
                                        pos_nodo.Z,
                                        pos_nodo.X,
                                        pos_nodo.Y,
                                        pos_nodo.Z,
                                        seg.start.X,
                                        seg.start.Y,
                                        seg.start.Z,
                                        seg.end.X,
                                        seg.end.Y,
                                        seg.end.Z,
                                        v_unit.X,
                                        v_unit.Y,
                                        v_unit.Z,
                                        float(cut_start),
                                        float(cut_end),
                                    )
                                )
                            except Exception:
                                pass
                        element_te = self._aplicar_transformacion(
                            te_outer_model,
                            seg,
                            elem_type="te",
                            custom_position=pos_nodo,
                            custom_yaw_deg=yaw,
                        )
                        result_list.append(
                            {
                                "element": element_te,
                                "element_type": (
                                    "te_inner" if is_inner_only_te else "te"
                                ),
                                "index": element_index,
                            }
                        )
                        element_index += 1

                        # TE inner opcional (TD): mismo nodo y orientación que la outer
                        if is_inner_only_te:
                            te_inner_model = None
                        if te_inner_model is not None:
                            element_te_inner = self._aplicar_transformacion(
                                te_inner_model,
                                seg,
                                elem_type="te",
                                custom_position=pos_nodo,
                                custom_yaw_deg=yaw,
                            )
                            result_list.append(
                                {
                                    "element": element_te_inner,
                                    "element_type": "te_inner",
                                    "index": element_index,
                                }
                            )
                            element_index += 1

                turn_fitting_type = _get_turn_fitting_type(p_prev, p_curr, p_next)
                if (
                    p_prev
                    and p_curr
                    and p_next
                    # Bloquear codo solo si hay TE real en ese nodo (no por clave vacía/placeholder).
                    and not te_info_at_node
                    and turn_fitting_type is not None
                ):
                    pos_nodo = seg.end

                    # Port de Saneamiento_old:
                    # si el giro es 90° y NO es cambio de plano, resolver como 2x45°.
                    # (mantener codo_90 para cambios de plano vertical<->horizontal).
                    use_double_45 = False
                    if turn_fitting_type == "codo_90" and "codo_45" in self.templates:
                        try:
                            dx_prev = p_curr.X - p_prev.X
                            dy_prev = p_curr.Y - p_prev.Y
                            dz_prev = p_curr.Z - p_prev.Z
                            dx_next = p_next.X - p_curr.X
                            dy_next = p_next.Y - p_curr.Y
                            dz_next = p_next.Z - p_curr.Z
                            eps3 = 1e-6
                            seg1_vert = (
                                abs(dx_prev) < eps3
                                and abs(dy_prev) < eps3
                                and abs(dz_prev) > eps3
                            )
                            seg2_vert = (
                                abs(dx_next) < eps3
                                and abs(dy_next) < eps3
                                and abs(dz_next) > eps3
                            )
                            is_plane_change = (seg1_vert and not seg2_vert) or (
                                seg2_vert and not seg1_vert
                            )
                            use_double_45 = not is_plane_change
                            print(
                                f"[SANEAMIENTO][2x45] decision turn={turn_fitting_type} "
                                f"plane_change={is_plane_change} -> use_double_45={use_double_45}"
                            )
                        except Exception:
                            use_double_45 = False

                    if use_double_45:
                        inserted_double_45 = False
                        try:
                            v1 = AllplanGeo.Vector3D(
                                p_curr.X - p_prev.X,
                                p_curr.Y - p_prev.Y,
                                p_curr.Z - p_prev.Z,
                            )
                            v2 = AllplanGeo.Vector3D(
                                p_next.X - p_curr.X,
                                p_next.Y - p_curr.Y,
                                p_next.Z - p_curr.Z,
                            )
                            n1 = math.sqrt(v1.X * v1.X + v1.Y * v1.Y + v1.Z * v1.Z)
                            n2 = math.sqrt(v2.X * v2.X + v2.Y * v2.Y + v2.Z * v2.Z)
                            if n1 > 1e-9 and n2 > 1e-9:
                                v1u = AllplanGeo.Vector3D(v1.X / n1, v1.Y / n1, v1.Z / n1)
                                v2u = AllplanGeo.Vector3D(v2.X / n2, v2.Y / n2, v2.Z / n2)
                                vm = AllplanGeo.Vector3D(
                                    v1u.X + v2u.X,
                                    v1u.Y + v2u.Y,
                                    v1u.Z + v2u.Z,
                                )
                                nm = math.sqrt(vm.X * vm.X + vm.Y * vm.Y + vm.Z * vm.Z)
                                if nm > 1e-9:
                                    vmu = AllplanGeo.Vector3D(
                                        vm.X / nm,
                                        vm.Y / nm,
                                        vm.Z / nm,
                                    )
                                    scale = 1000.0
                                    p_after = AllplanGeo.Point3D(
                                        p_curr.X + vmu.X * scale,
                                        p_curr.Y + vmu.Y * scale,
                                        p_curr.Z + vmu.Z * scale,
                                    )
                                    p_before = AllplanGeo.Point3D(
                                        p_curr.X - vmu.X * scale,
                                        p_curr.Y - vmu.Y * scale,
                                        p_curr.Z - vmu.Z * scale,
                                    )

                                    def _normalize(v):
                                        nv = math.sqrt(v.X * v.X + v.Y * v.Y + v.Z * v.Z)
                                        if nv <= 1e-9:
                                            return AllplanGeo.Vector3D(0.0, 0.0, 0.0)
                                        return AllplanGeo.Vector3D(v.X / nv, v.Y / nv, v.Z / nv)

                                    def _cross(a, b):
                                        return AllplanGeo.Vector3D(
                                            a.Y * b.Z - a.Z * b.Y,
                                            a.Z * b.X - a.X * b.Z,
                                            a.X * b.Y - a.Y * b.X,
                                        )

                                    def _build_local_offset_point(base_pt, a_u, b_u, off_x, off_y, off_z):
                                        # Ejes locales del codo:
                                        # X_local -> bisectriz del giro, Y_local -> lateral, Z_local -> normal del plano del giro.
                                        x_local = _normalize(
                                            AllplanGeo.Vector3D(
                                                a_u.X + b_u.X,
                                                a_u.Y + b_u.Y,
                                                a_u.Z + b_u.Z,
                                            )
                                        )
                                        if (
                                            abs(x_local.X) < 1e-9
                                            and abs(x_local.Y) < 1e-9
                                            and abs(x_local.Z) < 1e-9
                                        ):
                                            x_local = _normalize(b_u)

                                        z_local = _normalize(_cross(a_u, b_u))
                                        if (
                                            abs(z_local.X) < 1e-9
                                            and abs(z_local.Y) < 1e-9
                                            and abs(z_local.Z) < 1e-9
                                        ):
                                            z_local = AllplanGeo.Vector3D(0.0, 0.0, 1.0)

                                        y_local = _normalize(_cross(z_local, x_local))
                                        if (
                                            abs(y_local.X) < 1e-9
                                            and abs(y_local.Y) < 1e-9
                                            and abs(y_local.Z) < 1e-9
                                        ):
                                            y_local = AllplanGeo.Vector3D(1.0, 0.0, 0.0)

                                        return AllplanGeo.Point3D(
                                            base_pt.X
                                            + (x_local.X * off_x)
                                            + (y_local.X * off_y)
                                            + (z_local.X * off_z),
                                            base_pt.Y
                                            + (x_local.Y * off_x)
                                            + (y_local.Y * off_y)
                                            + (z_local.Y * off_z),
                                            base_pt.Z
                                            + (x_local.Z * off_x)
                                            + (y_local.Z * off_y)
                                            + (z_local.Z * off_z),
                                        )

                                    info_curr = getattr(segments[i], "info", None)
                                    turn_diam = (
                                        getattr(info_curr, "diameter", None)
                                        if info_curr is not None
                                        else None
                                    )
                                    if isinstance(turn_diam, (list, tuple)) and turn_diam:
                                        turn_diam = turn_diam[0]
                                    try:
                                        turn_diam = int(round(float(turn_diam)))
                                    except Exception:
                                        turn_diam = 25

                                    if turn_diam == 110:
                                        auto_sep = DOUBLE45_110_AUTO_SEP_MM
                                        trim_in = DOUBLE45_110_TRIM_IN_MM
                                        trim_out = DOUBLE45_110_TRIM_OUT_MM
                                        c1_off = (
                                            DOUBLE45_110_CODO1_OFFSET_X_MM,
                                            DOUBLE45_110_CODO1_OFFSET_Y_MM,
                                            DOUBLE45_110_CODO1_OFFSET_Z_MM,
                                        )
                                        c2_off = (
                                            DOUBLE45_110_CODO2_OFFSET_X_MM,
                                            DOUBLE45_110_CODO2_OFFSET_Y_MM,
                                            DOUBLE45_110_CODO2_OFFSET_Z_MM,
                                        )
                                    elif turn_diam == 40:
                                        auto_sep = DOUBLE45_40_AUTO_SEP_MM
                                        trim_in = DOUBLE45_40_TRIM_IN_MM
                                        trim_out = DOUBLE45_40_TRIM_OUT_MM
                                        c1_off = (
                                            DOUBLE45_40_CODO1_OFFSET_X_MM,
                                            DOUBLE45_40_CODO1_OFFSET_Y_MM,
                                            DOUBLE45_40_CODO1_OFFSET_Z_MM,
                                        )
                                        c2_off = (
                                            DOUBLE45_40_CODO2_OFFSET_X_MM,
                                            DOUBLE45_40_CODO2_OFFSET_Y_MM,
                                            DOUBLE45_40_CODO2_OFFSET_Z_MM,
                                        )
                                    else:
                                        auto_sep = DOUBLE45_AUTO_SEP_MM
                                        trim_in = DOUBLE45_TRIM_IN_MM
                                        trim_out = DOUBLE45_TRIM_OUT_MM
                                        c1_off = (
                                            DOUBLE45_CODO1_OFFSET_X_MM,
                                            DOUBLE45_CODO1_OFFSET_Y_MM,
                                            DOUBLE45_CODO1_OFFSET_Z_MM,
                                        )
                                        c2_off = (
                                            DOUBLE45_CODO2_OFFSET_X_MM,
                                            DOUBLE45_CODO2_OFFSET_Y_MM,
                                            DOUBLE45_CODO2_OFFSET_Z_MM,
                                        )

                                    base_codo_1 = AllplanGeo.Point3D(
                                        p_curr.X - (v1u.X * auto_sep),
                                        p_curr.Y - (v1u.Y * auto_sep),
                                        p_curr.Z - (v1u.Z * auto_sep),
                                    )
                                    base_codo_2 = AllplanGeo.Point3D(
                                        p_curr.X + (v2u.X * auto_sep),
                                        p_curr.Y + (v2u.Y * auto_sep),
                                        p_curr.Z + (v2u.Z * auto_sep),
                                    )

                                    pos_codo_1 = _build_local_offset_point(
                                        base_codo_1, v1u, vmu, c1_off[0], c1_off[1], c1_off[2]
                                    )
                                    pos_codo_2 = _build_local_offset_point(
                                        base_codo_2, vmu, v2u, c2_off[0], c2_off[1], c2_off[2]
                                    )

                                    # Recortes dedicados para composición 90° = 2x45°
                                    # (solo afectan la orientación/encastre de estos codos).
                                    p_prev_trim = AllplanGeo.Point3D(
                                        p_prev.X + (v1u.X * trim_in),
                                        p_prev.Y + (v1u.Y * trim_in),
                                        p_prev.Z + (v1u.Z * trim_in),
                                    )
                                    p_next_trim = AllplanGeo.Point3D(
                                        p_next.X - (v2u.X * trim_out),
                                        p_next.Y - (v2u.Y * trim_out),
                                        p_next.Z - (v2u.Z * trim_out),
                                    )

                                    seg_codo_1 = _build_aux_seg_data(p_prev_trim, p_curr)
                                    next_codo_1 = _build_aux_seg_data(p_curr, p_after)
                                    e1_outer = self._aplicar_transformacion(
                                        self.templates["codo_45"],
                                        seg_codo_1,
                                        elem_type="codo_45",
                                        custom_position=pos_codo_1,
                                        next_seg=next_codo_1,
                                    )
                                    result_list.append(
                                        {
                                            "element": e1_outer,
                                            "element_type": "codo_45",
                                            "index": element_index,
                                        }
                                    )
                                    element_index += 1

                                    seg_codo_2 = _build_aux_seg_data(p_before, p_curr)
                                    next_codo_2 = _build_aux_seg_data(p_curr, p_next_trim)
                                    e2_outer = self._aplicar_transformacion(
                                        self.templates["codo_45"],
                                        seg_codo_2,
                                        elem_type="codo_45",
                                        custom_position=pos_codo_2,
                                        next_seg=next_codo_2,
                                    )
                                    result_list.append(
                                        {
                                            "element": e2_outer,
                                            "element_type": "codo_45",
                                            "index": element_index,
                                        }
                                    )
                                    element_index += 1
                                    inserted_double_45 = True

                                    # Copias opcionales de codo_45 (inner) para ambos.
                                    if "codo_45_inner" in self.templates:
                                        e1_in = self._aplicar_transformacion(
                                            self.templates["codo_45_inner"],
                                            seg_codo_1,
                                            elem_type="codo_45",
                                            custom_position=pos_codo_1,
                                            next_seg=next_codo_1,
                                        )
                                        result_list.append(
                                            {
                                                "element": e1_in,
                                                "element_type": "codo_45_inner",
                                                "index": element_index,
                                            }
                                        )
                                        element_index += 1
                                        e2_in = self._aplicar_transformacion(
                                            self.templates["codo_45_inner"],
                                            seg_codo_2,
                                            elem_type="codo_45",
                                            custom_position=pos_codo_2,
                                            next_seg=next_codo_2,
                                        )
                                        result_list.append(
                                            {
                                                "element": e2_in,
                                                "element_type": "codo_45_inner",
                                                "index": element_index,
                                            }
                                        )
                                        element_index += 1

                                    if "codo_45_inner_2" in self.templates:
                                        e1_in2 = self._aplicar_transformacion(
                                            self.templates["codo_45_inner_2"],
                                            seg_codo_1,
                                            elem_type="codo_45",
                                            custom_position=pos_codo_1,
                                            next_seg=next_codo_1,
                                        )
                                        result_list.append(
                                            {
                                                "element": e1_in2,
                                                "element_type": "codo_45_inner_2",
                                                "index": element_index,
                                            }
                                        )
                                        element_index += 1
                                        e2_in2 = self._aplicar_transformacion(
                                            self.templates["codo_45_inner_2"],
                                            seg_codo_2,
                                            elem_type="codo_45",
                                            custom_position=pos_codo_2,
                                            next_seg=next_codo_2,
                                        )
                                        result_list.append(
                                            {
                                                "element": e2_in2,
                                                "element_type": "codo_45_inner_2",
                                                "index": element_index,
                                            }
                                        )
                                        element_index += 1

                                    # Ya se resolvió el giro 90 como 2x45.
                        except Exception as ex:
                            print(f"[SANEAMIENTO][2x45] ERROR en nodo 90°: {ex}")

                        if inserted_double_45:
                            print("[SANEAMIENTO][2x45] aplicado (90° sin cambio de plano)")
                            continue

                    # Codo exterior (outer)
                    pos_codo = pos_nodo
                    if turn_fitting_type in ("codo_90", "codo_45"):
                        try:
                            info_curr = getattr(segments[i], "info", None)
                            diam = (
                                getattr(info_curr, "diameter", None)
                                if info_curr is not None
                                else None
                            )
                            if isinstance(diam, (list, tuple)) and diam:
                                diam = diam[0]
                            if diam is not None and int(round(float(diam))) in (25, 40, 110):
                                # Offsets de codos Ø25/Ø40/Ø110 aplicados en marco local del giro
                                # para que el ajuste se mantenga en todos los vértices.
                                def _norm(v):
                                    n = math.sqrt(v.X * v.X + v.Y * v.Y + v.Z * v.Z)
                                    if n <= 1e-9:
                                        return AllplanGeo.Vector3D(0.0, 0.0, 0.0)
                                    return AllplanGeo.Vector3D(v.X / n, v.Y / n, v.Z / n)

                                def _cross(a, b):
                                    return AllplanGeo.Vector3D(
                                        a.Y * b.Z - a.Z * b.Y,
                                        a.Z * b.X - a.X * b.Z,
                                        a.X * b.Y - a.Y * b.X,
                                    )

                                v_in = getattr(seg, "vector_normalizado", AllplanGeo.Vector3D(0.0, 0.0, 0.0))
                                v_out = getattr(next_seg, "vector_normalizado", AllplanGeo.Vector3D(0.0, 0.0, 0.0))
                                x_local = _norm(
                                    AllplanGeo.Vector3D(
                                        v_in.X + v_out.X,
                                        v_in.Y + v_out.Y,
                                        v_in.Z + v_out.Z,
                                    )
                                )
                                if abs(x_local.X) < 1e-9 and abs(x_local.Y) < 1e-9 and abs(x_local.Z) < 1e-9:
                                    x_local = _norm(v_out)

                                z_local = _norm(_cross(v_in, v_out))
                                if abs(z_local.X) < 1e-9 and abs(z_local.Y) < 1e-9 and abs(z_local.Z) < 1e-9:
                                    z_local = AllplanGeo.Vector3D(0.0, 0.0, 1.0)

                                y_local = _norm(_cross(z_local, x_local))
                                if abs(y_local.X) < 1e-9 and abs(y_local.Y) < 1e-9 and abs(y_local.Z) < 1e-9:
                                    y_local = AllplanGeo.Vector3D(1.0, 0.0, 0.0)

                                if turn_fitting_type == "codo_90":
                                    if int(round(float(diam))) == 110:
                                        if _segment_is_fecal(i):
                                            off_x = CODO90_110_FECAL_OFFSET_X_MM
                                            off_y = CODO90_110_FECAL_OFFSET_Y_MM
                                            off_z = CODO90_110_FECAL_OFFSET_Z_MM
                                        else:
                                            off_x = CODO90_110_OFFSET_X_MM
                                            off_y = CODO90_110_OFFSET_Y_MM
                                            off_z = CODO90_110_OFFSET_Z_MM
                                    elif int(round(float(diam))) == 40:
                                        off_x = CODO90_40_OFFSET_X_MM
                                        off_y = CODO90_40_OFFSET_Y_MM
                                        off_z = CODO90_40_OFFSET_Z_MM
                                    else:
                                        off_x = CODO90_25_OFFSET_X_MM
                                        off_y = CODO90_25_OFFSET_Y_MM
                                        off_z = CODO90_25_OFFSET_Z_MM
                                else:
                                    if int(round(float(diam))) == 110:
                                        off_x = CODO45_110_OFFSET_X_MM
                                        off_y = CODO45_110_OFFSET_Y_MM
                                        off_z = CODO45_110_OFFSET_Z_MM
                                    elif int(round(float(diam))) == 40:
                                        off_x = CODO45_40_OFFSET_X_MM
                                        off_y = CODO45_40_OFFSET_Y_MM
                                        off_z = CODO45_40_OFFSET_Z_MM
                                    else:
                                        off_x = CODO45_25_OFFSET_X_MM
                                        off_y = CODO45_25_OFFSET_Y_MM
                                        off_z = CODO45_25_OFFSET_Z_MM

                                pos_codo = AllplanGeo.Point3D(
                                    pos_nodo.X
                                    + (x_local.X * off_x)
                                    + (y_local.X * off_y)
                                    + (z_local.X * off_z),
                                    pos_nodo.Y
                                    + (x_local.Y * off_x)
                                    + (y_local.Y * off_y)
                                    + (z_local.Y * off_z),
                                    pos_nodo.Z
                                    + (x_local.Z * off_x)
                                    + (y_local.Z * off_y)
                                    + (z_local.Z * off_z),
                                )
                        except Exception:
                            pos_codo = pos_nodo

                    element_codo_outer = self._aplicar_transformacion(
                        self.templates[turn_fitting_type],
                        seg,
                        # Importante: codo_45 NO debe pasar por el transform especial de 90°.
                        elem_type=turn_fitting_type,
                        custom_position=pos_codo,
                        next_seg=next_seg,
                    )

                    result_list.append(
                        {
                            "element": element_codo_outer,
                            "element_type": turn_fitting_type,
                            "index": element_index,
                        }
                    )
                    element_index += 1

                    # Copias opcionales para codo_45 (misma posición/rotación).
                    if turn_fitting_type == "codo_45":
                        if "codo_45_inner" in self.templates:
                            element_codo_inner = self._aplicar_transformacion(
                                self.templates["codo_45_inner"],
                                seg,
                                elem_type="codo_45",
                                custom_position=pos_codo,
                                next_seg=next_seg,
                            )
                            result_list.append(
                                {
                                    "element": element_codo_inner,
                                    "element_type": "codo_45_inner",
                                    "index": element_index,
                                }
                            )
                            element_index += 1

                        if "codo_45_inner_2" in self.templates:
                            element_codo_inner_2 = self._aplicar_transformacion(
                                self.templates["codo_45_inner_2"],
                                seg,
                                elem_type="codo_45",
                                custom_position=pos_codo,
                                next_seg=next_seg,
                            )
                            result_list.append(
                                {
                                    "element": element_codo_inner_2,
                                    "element_type": "codo_45_inner_2",
                                    "index": element_index,
                                }
                            )
                            element_index += 1

                    # Codo interior (inner) solo para codo_90 real.
                    if turn_fitting_type == "codo_90" and "codo_90_inner" in self.templates:
                        element_codo_inner = self._aplicar_transformacion(
                            self.templates["codo_90_inner"],
                            seg,
                            elem_type="codo_90",
                            custom_position=pos_codo,
                            next_seg=next_seg,
                        )

                        result_list.append(
                            {
                                "element": element_codo_inner,
                                "element_type": "codo_90_inner",
                                "index": element_index,
                            }
                        )
                        element_index += 1

                    # Segunda copia opcional para codo_90 (misma posición/rotación).
                    if turn_fitting_type == "codo_90" and "codo_90_inner_2" in self.templates:
                        element_codo_inner_2 = self._aplicar_transformacion(
                            self.templates["codo_90_inner_2"],
                            seg,
                            elem_type="codo_90",
                            custom_position=pos_codo,
                            next_seg=next_seg,
                        )
                        result_list.append(
                            {
                                "element": element_codo_inner_2,
                                "element_type": "codo_90_inner_2",
                                "index": element_index,
                            }
                        )
                        element_index += 1

                # Manguito en vértice colineal (0° o 180°)
                # En fontaneria se crea siempre en tramos rectos, incluso si no hay cambio de diámetro.
                if True:
                    # Si este nodo es una TE, NO crear manguito (se muestra la TE).
                    if p_curr:
                        if node_key in te_nodes:
                            continue

                    # Regla:
                    # - Crear si el tramo es colineal (dot ~ ±1)
                    # - O si hay cambio de diámetro entre segmentos consecutivos (aunque el dot no sea perfecto por pendientes/ruido)
                    def _get_seg_diam(_seg_item):
                        try:
                            info = getattr(_seg_item, "info", None)
                            d = (
                                getattr(info, "diameter", None)
                                if info is not None
                                else None
                            )
                            if isinstance(d, (list, tuple)) and d:
                                return float(d[0])
                            if d is None:
                                return None
                            return float(d)
                        except Exception:
                            return None

                    d_curr = _get_seg_diam(segments[i])
                    d_next = _get_seg_diam(segments[i + 1])
                    diam_change = (
                        d_curr is not None
                        and d_next is not None
                        and abs(float(d_curr) - float(d_next)) > 1e-6
                    )

                    v1 = seg.vector_normalizado
                    v2 = next_seg.vector_normalizado
                    dot = AllplanGeo.Vector3D.DotProduct(v1, v2)
                    # colineal si dot ~ 1 (mismo sentido) o dot ~ -1 (sentido opuesto)
                    is_colinear = abs(abs(dot) - 1.0) < 0.01

                    if is_colinear or diam_change:
                        pos_nodo = seg.end
                        # Distribución local del nodo (IS/TD): tomar del tramo actual;
                        # si falta, usar el siguiente; fallback IS.
                        dist_type = "IS"
                        try:
                            info_curr = getattr(segments[i], "info", None)
                            info_next = (
                                getattr(segments[i + 1], "info", None)
                                if i + 1 < len(segments)
                                else None
                            )
                            dist_raw = (
                                getattr(info_curr, "distribution_type", None)
                                or getattr(info_next, "distribution_type", None)
                                or "IS"
                            )
                            dist_type = "TD" if str(dist_raw).upper() == "TD" else "IS"
                        except Exception:
                            dist_type = "IS"

                        print(
                            "[AGUA][MANGUITO] node=(%.3f,%.3f,%.3f) seg=%s->%s "
                            "dot=%.4f colinear=%s diam_change=%s d_curr=%s d_next=%s dist=%s"
                            % (
                                pos_nodo.X,
                                pos_nodo.Y,
                                pos_nodo.Z,
                                str(i),
                                str(i + 1),
                                float(dot),
                                str(is_colinear),
                                str(diam_change),
                                str(d_curr),
                                str(d_next),
                                dist_type,
                            )
                        )

                        # Elegir modelo de manguito por PAR DE DIÁMETROS (port de fontaneria).
                        dyn_models = self._get_manguito_models_for_diameters(
                            d_curr if d_curr is not None else 20.0,
                            d_next if d_next is not None else 20.0,
                            distribution_type=dist_type,
                        )
                        manguito_outer_model = (
                            dyn_models[0] if dyn_models else self.templates.get("manguito")
                        )
                        if manguito_outer_model is None:
                            print(
                                "[AGUA][MANGUITO] sin modelo para nodo colineal: "
                                f"d_curr={d_curr} d_next={d_next} dist={dist_type}"
                            )
                            continue
                        # Reductor TD (p.ej. 25-20) puede venir como único BRep "inner".
                        # En ese caso NO debemos tratarlo como outer ni crear inner template extra.
                        is_inner_only_reducer = (
                            dist_type == "TD"
                            and len(dyn_models) == 1
                            and d_curr is not None
                            and d_next is not None
                            and int(round(float(d_curr))) != int(round(float(d_next)))
                        )
                        print(
                            f"[AGUA][MANGUITO] modelo_outer={'dinamico' if dyn_models else 'template'} "
                            f"elems_dyn={len(dyn_models)}"
                        )
                        if is_inner_only_reducer:
                            print(
                                "[AGUA][MANGUITO] reductor TD inner-only detectado: "
                                "se trata como manguito_inner y se omite inner template"
                            )

                        # Reductores: mirror local para invertir sentido según flujo.
                        # Port de lógica legacy:
                        # - 25->20: invertir
                        # - 25->40: invertir (base del reductor 40->25)
                        need_mirror_x = False
                        try:
                            if d_curr is not None and d_next is not None:
                                di1 = int(round(float(d_curr)))
                                di2 = int(round(float(d_next)))
                                if {di1, di2} == {20, 25} and di1 > di2:
                                    need_mirror_x = True
                                if {di1, di2} == {25, 40} and di1 < di2:
                                    need_mirror_x = True
                                if {di1, di2} == {40, 110} and di1 < di2:
                                    need_mirror_x = True
                        except Exception:
                            need_mirror_x = False
                        if need_mirror_x:
                            print(
                                f"[AGUA][MANGUITO] mirror_x_local=True (caso {int(di1)}->{int(di2)})"
                            )

                        # Offsets en marco local: Tap 40<->25 y reductor conjunto 110<->40.
                        pos_manguito = pos_nodo
                        try:
                            if d_curr is not None and d_next is not None:
                                pair_m = {
                                    int(round(float(d_curr))),
                                    int(round(float(d_next))),
                                }
                                if pair_m == {25, 40}:
                                    off_x = (
                                        -TAPRED_40_25_OFFSET_X_MM
                                        if need_mirror_x
                                        else TAPRED_40_25_OFFSET_X_MM
                                    )
                                    pos_manguito = _manguito_bisector_offset_point(
                                        pos_nodo,
                                        seg,
                                        next_seg,
                                        off_x,
                                        TAPRED_40_25_OFFSET_Y_MM,
                                        TAPRED_40_25_OFFSET_Z_MM,
                                    )
                                elif pair_m == {40, 110}:
                                    rx, ry, rz = _reduct_110_40_offsets_mm()
                                    off_x = -rx if need_mirror_x else rx
                                    pos_manguito = _manguito_bisector_offset_point(
                                        pos_nodo,
                                        seg,
                                        next_seg,
                                        off_x,
                                        ry,
                                        rz,
                                    )
                                    print(
                                        "[AGUA][MANGUITO] offset reductor 110↔40 "
                                        f"local_xyz=({off_x:.2f},{ry:.2f},{rz:.2f}) "
                                        f"mirror_x={need_mirror_x}"
                                    )
                        except Exception:
                            pos_manguito = pos_nodo

                        element_manguito = self._aplicar_transformacion(
                            manguito_outer_model,
                            seg,
                            elem_type="manguito",
                            custom_position=pos_manguito,
                            next_seg=next_seg,
                            custom_mirror_x_local=need_mirror_x,
                        )
                        result_list.append(
                            {
                                "element": element_manguito,
                                "element_type": (
                                    "manguito_inner"
                                    if is_inner_only_reducer
                                    else "manguito"
                                ),
                                "index": element_index,
                            }
                        )
                        element_index += 1

                        # TD opcional: manguito inner (si existe en modelo dinámico o templates)
                        manguito_inner_model = None
                        if is_inner_only_reducer:
                            manguito_inner_model = None
                        elif len(dyn_models) > 1:
                            manguito_inner_model = dyn_models[1]
                        elif "manguito_inner" in self.templates:
                            manguito_inner_model = self.templates["manguito_inner"]

                        if manguito_inner_model is not None:
                            print(
                                "[AGUA][MANGUITO] creando inner "
                                f"(fuente={'dinamico' if len(dyn_models) > 1 else 'template'})"
                            )
                            element_manguito_inner = self._aplicar_transformacion(
                                manguito_inner_model,
                                seg,
                                elem_type="manguito",
                                custom_position=pos_manguito,
                                next_seg=next_seg,
                                custom_mirror_x_local=need_mirror_x,
                            )
                            result_list.append(
                                {
                                    "element": element_manguito_inner,
                                    "element_type": "manguito_inner",
                                    "index": element_index,
                                }
                            )
                            element_index += 1

            # -------------------------------------------------------
            # 3.C CODO EN NODO COMPARTIDO ENTRE PATHS (grado=2)
            # -------------------------------------------------------
            if "codo_90" in self.templates:
                for at_start in (False, True):
                    cp_info = cross_path_elbows.get((i, at_start))
                    if not cp_info:
                        continue
                    node_key_cp = cp_info.get("node_key")
                    other_pt = cp_info.get("other_point")
                    if not node_key_cp or not other_pt:
                        continue
                    if node_key_cp in te_nodes or node_key_cp in inserted_cross_path_elbows:
                        continue

                    if at_start:
                        node_pt = getattr(seg, "start", None)
                        away_pt = getattr(seg, "end", None)
                    else:
                        node_pt = getattr(seg, "end", None)
                        away_pt = getattr(seg, "start", None)
                    if not node_pt or not away_pt:
                        continue

                    seg_for_elbow = (
                        _build_aux_seg_data(away_pt, node_pt) if at_start else seg
                    )
                    next_for_elbow = _build_aux_seg_data(node_pt, other_pt)

                    element_codo_outer = self._aplicar_transformacion(
                        self.templates["codo_90"],
                        seg_for_elbow,
                        elem_type="codo_90",
                        custom_position=node_pt,
                        next_seg=next_for_elbow,
                    )
                    result_list.append(
                        {
                            "element": element_codo_outer,
                            "element_type": "codo_90",
                            "index": element_index,
                        }
                    )
                    element_index += 1

                    if "codo_90_inner" in self.templates:
                        element_codo_inner = self._aplicar_transformacion(
                            self.templates["codo_90_inner"],
                            seg_for_elbow,
                            elem_type="codo_90",
                            custom_position=node_pt,
                            next_seg=next_for_elbow,
                        )
                        result_list.append(
                            {
                                "element": element_codo_inner,
                                "element_type": "codo_90_inner",
                                "index": element_index,
                            }
                        )
                        element_index += 1

                    inserted_cross_path_elbows.add(node_key_cp)
                    break

            # -------------------------------------------------------
            # 3.D MANGUITO EN NODO COMPARTIDO ENTRE PATHS (grado=2 colineal)
            # -------------------------------------------------------
            if True:
                for at_start in (False, True):
                    cp_info = cross_path_manguitos.get((i, at_start))
                    if not cp_info:
                        continue
                    node_key_cp = cp_info.get("node_key")
                    other_pt = cp_info.get("other_point")
                    if not node_key_cp or not other_pt:
                        continue
                    if (
                        node_key_cp in te_nodes
                        or node_key_cp in inserted_cross_path_manguitos
                    ):
                        continue

                    if at_start:
                        node_pt = getattr(seg, "start", None)
                        away_pt = getattr(seg, "end", None)
                    else:
                        node_pt = getattr(seg, "end", None)
                        away_pt = getattr(seg, "start", None)
                    if not node_pt or not away_pt:
                        continue

                    seg_for_conn = (
                        _build_aux_seg_data(away_pt, node_pt) if at_start else seg
                    )
                    next_for_conn = _build_aux_seg_data(node_pt, other_pt)

                    def _get_seg_diam(_seg_item):
                        try:
                            info = getattr(_seg_item, "info", None)
                            d = getattr(info, "diameter", None) if info is not None else None
                            if isinstance(d, (list, tuple)) and d:
                                return float(d[0])
                            if d is None:
                                return None
                            return float(d)
                        except Exception:
                            return None

                    d_curr = _get_seg_diam(seg_item)
                    d_next = cp_info.get("other_diameter", d_curr)
                    if isinstance(d_next, (list, tuple)) and d_next:
                        d_next = d_next[0]
                    if d_next is None:
                        d_next = d_curr
                    dist_type = "IS"
                    try:
                        info_curr = getattr(seg_item, "info", None)
                        dist_raw = getattr(info_curr, "distribution_type", None) or "IS"
                        dist_type = "TD" if str(dist_raw).upper() == "TD" else "IS"
                    except Exception:
                        dist_type = "IS"

                    dyn_models = self._get_manguito_models_for_diameters(
                        d_curr if d_curr is not None else 20.0,
                        d_next if d_next is not None else 20.0,
                        distribution_type=dist_type,
                    )
                    manguito_outer_model = (
                        dyn_models[0] if dyn_models else self.templates.get("manguito")
                    )
                    if manguito_outer_model is None:
                        print(
                            "[AGUA][MANGUITO] sin modelo cross-path: "
                            f"d_curr={d_curr} d_next={d_next} dist={dist_type}"
                        )
                        continue
                    is_inner_only_reducer = False
                    need_mirror_x = False
                    try:
                        if d_curr is not None and d_next is not None:
                            di1 = int(round(float(d_curr)))
                            di2 = int(round(float(d_next)))
                            if {di1, di2} == {20, 25} and di1 > di2:
                                need_mirror_x = True
                            if {di1, di2} == {25, 40} and di1 < di2:
                                need_mirror_x = True
                            if {di1, di2} == {40, 110} and di1 < di2:
                                need_mirror_x = True
                    except Exception:
                        need_mirror_x = False

                    pos_manguito = node_pt
                    try:
                        if d_curr is not None and d_next is not None:
                            pair_m = {
                                int(round(float(d_curr))),
                                int(round(float(d_next))),
                            }
                            if pair_m == {25, 40}:
                                off_x = (
                                    -TAPRED_40_25_OFFSET_X_MM
                                    if need_mirror_x
                                    else TAPRED_40_25_OFFSET_X_MM
                                )
                                pos_manguito = _manguito_bisector_offset_point(
                                    node_pt,
                                    seg_for_conn,
                                    next_for_conn,
                                    off_x,
                                    TAPRED_40_25_OFFSET_Y_MM,
                                    TAPRED_40_25_OFFSET_Z_MM,
                                )
                            elif pair_m == {40, 110}:
                                rx, ry, rz = _reduct_110_40_offsets_mm()
                                off_x = -rx if need_mirror_x else rx
                                pos_manguito = _manguito_bisector_offset_point(
                                    node_pt,
                                    seg_for_conn,
                                    next_for_conn,
                                    off_x,
                                    ry,
                                    rz,
                                )
                                print(
                                    "[AGUA][MANGUITO] offset reductor 110↔40 (cross) "
                                    f"local_xyz=({off_x:.2f},{ry:.2f},{rz:.2f}) "
                                    f"mirror_x={need_mirror_x}"
                                )
                    except Exception:
                        pos_manguito = node_pt

                    element_manguito = self._aplicar_transformacion(
                        manguito_outer_model,
                        seg_for_conn,
                        elem_type="manguito",
                        custom_position=pos_manguito,
                        next_seg=next_for_conn,
                        custom_mirror_x_local=need_mirror_x,
                    )
                    result_list.append(
                        {
                            "element": element_manguito,
                            "element_type": (
                                "manguito_inner" if is_inner_only_reducer else "manguito"
                            ),
                            "index": element_index,
                        }
                    )
                    element_index += 1

                    manguito_inner_model = None
                    if len(dyn_models) > 1:
                        manguito_inner_model = dyn_models[1]
                    elif "manguito_inner" in self.templates:
                        manguito_inner_model = self.templates["manguito_inner"]

                    if manguito_inner_model is not None:
                        element_manguito_inner = self._aplicar_transformacion(
                            manguito_inner_model,
                            seg_for_conn,
                            elem_type="manguito",
                            custom_position=pos_manguito,
                            next_seg=next_for_conn,
                            custom_mirror_x_local=need_mirror_x,
                        )
                        result_list.append(
                            {
                                "element": element_manguito_inner,
                                "element_type": "manguito_inner",
                                "index": element_index,
                            }
                        )
                        element_index += 1

                    inserted_cross_path_manguitos.add(node_key_cp)
                    break

        return result_list
